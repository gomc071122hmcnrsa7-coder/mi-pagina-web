import PiePagina from "../componentes/PiePagina";
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import API from "../api/api";
import imagenCurso from "../utils/imagenCurso";

const mostrar = valor => valor === null || valor === undefined || valor === "" ? "Por confirmar" : valor;

function DetalleCurso() {
    const { idCurso } = useParams();
    const [filas, setFilas] = useState([]);
    const [estado, setEstado] = useState("cargando");
    const [intento, setIntento] = useState(0);

    useEffect(() => {
        const controller = new AbortController();
        setEstado("cargando");
        setFilas([]);
        window.scrollTo(0, 0);
        API.get("cursos-completos/", { signal: controller.signal })
            .then(({ data }) => {
                if (controller.signal.aborted) return;
                setFilas(data.filter(curso => String(curso.id_curso) === idCurso));
                setEstado("listo");
            })
            .catch(() => {
                if (!controller.signal.aborted) setEstado("error");
            });
        return () => controller.abort();
    }, [idCurso, intento]);

    const curso = filas[0];
    const grupos = [...new Map(filas.filter(fila => fila.id_grupo != null).map(fila => [fila.id_grupo, fila])).values()];

    return (
        <div className="montreal-con-pie" style={{ backgroundColor: "#f5f5f5", minHeight: "100vh", color: "#1a1a1a" }}>
            <header className="bg-dark text-white py-4">
                <div className="container d-flex justify-content-between align-items-center gap-3 flex-wrap">
                    <Link to="/" className="text-white text-decoration-none fs-4 fw-bold">Institución Montreal</Link>
                    <Link to="/" className="btn btn-outline-light rounded-pill">← Volver al inicio</Link>
                </div>
            </header>
            <main className="container py-5">
                {estado === "cargando" && <p role="status">Cargando información del curso…</p>}
                {estado === "error" && (
                    <div role="alert">
                        <p>No se pudo cargar la información del curso.</p>
                        <button className="btn btn-dark" onClick={() => setIntento(valor => valor + 1)}>Reintentar</button>
                    </div>
                )}
                {estado === "listo" && !curso && <h1 className="h3">Curso no encontrado o no disponible.</h1>}
                {estado === "listo" && curso && (
                    <>
                        <section className="card border-0 shadow-sm p-4 p-md-5 mb-4" style={{ borderRadius: "18px" }}>
                            <img
                                src={imagenCurso(curso.nombre_curso)}
                                alt={`Ilustración del curso ${curso.nombre_curso}`}
                                className="img-fluid align-self-center rounded-3 mb-4"
                                width="640"
                                height="360"
                                style={{ width: "100%", maxWidth: "640px", height: "auto" }}
                            />
                            <h1 className="fw-bold">{curso.nombre_curso}</h1>
                            <h2 className="h5 mt-4">Descripción del curso</h2>
                            <p className="text-muted" style={{ whiteSpace: "pre-wrap" }}>{curso.descripcion || "Descripción por confirmar."}</p>
                            <dl className="row mt-3 mb-0">
                                <div className="col-sm-4"><dt>Duración</dt><dd>{curso.duracion_horas != null ? `${curso.duracion_horas} horas` : "Por confirmar"}</dd></div>
                                <div className="col-sm-4"><dt>Costo</dt><dd>{curso.costo != null && curso.costo !== "" ? `$${Number(curso.costo).toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "Por confirmar"}</dd></div>
                                <div className="col-sm-4"><dt>Nivel</dt><dd>{mostrar(curso.nivel)}</dd></div>
                            </dl>
                        </section>
                        <section aria-labelledby="grupos-titulo">
                            <h2 id="grupos-titulo" className="h3 mb-4">Grupos y horarios</h2>
                            {!grupos.length && <p>Los grupos y horarios están por confirmar.</p>}
                            {grupos.map(grupo => (
                                <article key={grupo.id_grupo} className="card border-0 shadow-sm p-4 mb-3">
                                    <h3 className="h5">{mostrar(grupo.nombre_grupo)}</h3>
                                    <p><strong>Docente:</strong> {mostrar([grupo.nombre_docente, grupo.apellido_paterno].filter(Boolean).join(" "))}</p>
                                    <p><strong>Periodo:</strong> {mostrar(grupo.nombre_periodo)}</p>
                                    <div className="table-responsive">
                                        <table className="table mb-0">
                                            <caption>Horarios de {mostrar(grupo.nombre_grupo)}</caption>
                                            <thead><tr>{["Día", "Inicio", "Fin", "Aula", "Ubicación"].map(titulo => <th scope="col" key={titulo}>{titulo}</th>)}</tr></thead>
                                            <tbody>{filas.filter(fila => fila.id_grupo === grupo.id_grupo).map((fila, indice) => (
                                                <tr key={indice}>
                                                    <td>{mostrar(fila.nombre_dia)}</td><td>{mostrar(fila.hora_inicio)}</td><td>{mostrar(fila.hora_fin)}</td>
                                                    <td>{mostrar(fila.nombre_aula)}</td><td>{mostrar(fila.ubicacion)}</td>
                                                </tr>
                                            ))}</tbody>
                                        </table>
                                    </div>
                                </article>
                            ))}
                        </section>
                        <Link to="/registro" className="btn btn-dark rounded-pill mt-4 px-4">Registrarme</Link>
                    </>
                )}
            </main>
            <PiePagina />
        </div>
    );
}

export default DetalleCurso;
