from django.http import JsonResponse
from django.views.decorators.http import require_GET
from .acceso import requiere_rol
from . import models as m


@require_GET
@requiere_rol('Docente')
def datos_docente(request):
    docente = m.Docentes.objects.filter(id_usuario=request.usuario_panel, estado=1).first()
    if not docente:
        return JsonResponse({'mensaje': 'No hay un perfil docente activo vinculado a esta cuenta.'}, status=403)
    grupos = m.Grupos.objects.filter(id_docente=docente, estado=1).select_related('id_curso', 'id_periodo')
    inscripciones = m.Inscripciones.objects.filter(id_grupo__in=grupos, estado=1).select_related('id_alumno', 'id_grupo')
    nombre = lambda alumno: ' '.join(filter(None, [alumno.nombre, alumno.apellido_paterno, alumno.apellido_materno]))
    return JsonResponse({'nombre': nombre(docente), 'secciones': {
        'Cursos y grupos': [{'Curso': g.id_curso.nombre_curso, 'Grupo': g.nombre_grupo, 'Periodo': g.id_periodo.nombre_periodo, 'Cupo': g.cupo_maximo} for g in grupos],
        'Alumnos': [{'Alumno': nombre(i.id_alumno), 'Matrícula': i.id_alumno.matricula, 'Grupo': i.id_grupo.nombre_grupo} for i in inscripciones],
        'Horarios': [{'Grupo': h.id_grupo.nombre_grupo, 'Día': h.id_dia.nombre_dia, 'Inicio': h.hora_inicio, 'Fin': h.hora_fin, 'Aula': h.id_aula.nombre_aula}
                     for h in m.Horarios.objects.filter(id_grupo__in=grupos, estado=1).select_related('id_grupo', 'id_dia', 'id_aula')],
        'Evaluaciones': [{'Evaluación': e.nombre_evaluacion, 'Grupo': e.id_grupo.nombre_grupo, 'Tipo': e.tipo_evaluacion, 'Porcentaje': e.porcentaje, 'Fecha': e.fecha}
                         for e in m.Evaluaciones.objects.filter(id_grupo__in=grupos, estado=1).select_related('id_grupo')],
        'Calificaciones': [{'Alumno': nombre(c.id_inscripcion.id_alumno), 'Grupo': c.id_inscripcion.id_grupo.nombre_grupo, 'Evaluación': c.id_evaluacion.nombre_evaluacion, 'Calificación': c.calificacion}
                           for c in m.Calificaciones.objects.filter(id_inscripcion__in=inscripciones, estado=1).select_related('id_inscripcion__id_alumno', 'id_inscripcion__id_grupo', 'id_evaluacion')],
        'Asistencias': [{'Alumno': nombre(a.id_inscripcion.id_alumno), 'Grupo': a.id_inscripcion.id_grupo.nombre_grupo, 'Fecha': a.fecha, 'Estado': a.estado}
                        for a in m.Asistencias.objects.filter(id_inscripcion__in=inscripciones).select_related('id_inscripcion__id_alumno', 'id_inscripcion__id_grupo')],
    }})







import json
from datetime import date
from decimal import Decimal, InvalidOperation

from django.db import transaction
from django.http import JsonResponse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from . import models as m
from .acceso import requiere_rol


def _respuesta(mensaje, status=400):
    return JsonResponse({"success": False, "mensaje": mensaje}, status=status)


def _leer_json(request):
    try:
        return json.loads(request.body or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None


def _fecha(valor):
    return date.fromisoformat(str(valor))


def _decimal(valor):
    numero = Decimal(str(valor))
    if not numero.is_finite():
        raise ValueError("El número no es válido.")
    return numero


def _docente_y_grupos(request):
    docente = m.Docentes.objects.filter(
        id_usuario=request.usuario_panel,
        estado=1
    ).first()

    if not docente:
        return None, None

    grupos = m.Grupos.objects.filter(
        id_docente=docente,
        estado=1
    )

    return docente, grupos


@csrf_exempt
@require_http_methods(["GET", "POST", "PUT", "DELETE"])
@requiere_rol("Docente")
def crud_docente(request, seccion, registro_id=None):
    if request.method != 'GET' and (request.method == 'POST') != (registro_id is None):
        return _respuesta('Operación no válida para esta dirección.', 405)
    docente, grupos = _docente_y_grupos(request)

    if not docente:
        return _respuesta(
            "No hay un perfil docente activo vinculado a esta cuenta.",
            403
        )

    seccion = seccion.lower()
    secciones_validas = {
        "alumnos", "asistencias", "evaluaciones", "calificaciones"
    }

    if seccion not in secciones_validas:
        return _respuesta("Sección no permitida.", 404)

    inscripciones = m.Inscripciones.objects.filter(
        id_grupo__in=grupos,
        estado=1
    )

    # -------------------- CONSULTAR --------------------
    if request.method == "GET":
        opciones = {}
        grupos_opciones = [
            {
                "id_grupo": grupo.id_grupo,
                "nombre_grupo": grupo.nombre_grupo,
                "curso": grupo.id_curso.nombre_curso,
                "periodo": grupo.id_periodo.nombre_periodo,
            }
            for grupo in grupos.select_related("id_curso", "id_periodo")
        ]

        if seccion == "alumnos":
            datos = [
                {
                    "id_inscripcion": i.id_inscripcion,
                    "id_alumno": i.id_alumno_id,
                    "nombre": " ".join(filter(None, [
                        i.id_alumno.nombre,
                        i.id_alumno.apellido_paterno,
                        i.id_alumno.apellido_materno
                    ])),
                    "matricula": i.id_alumno.matricula,
                    "id_grupo": i.id_grupo_id,
                    "grupo": i.id_grupo.nombre_grupo,
                    "observaciones": i.observaciones
                }
                for i in inscripciones.select_related(
                    "id_alumno", "id_grupo"
                )
            ]
            opciones = {
                "alumnos": [
                    {
                        "id_alumno": alumno.id_alumno,
                        "nombre": " ".join(filter(None, [
                            alumno.nombre,
                            alumno.apellido_paterno,
                            alumno.apellido_materno
                        ])),
                        "matricula": alumno.matricula,
                    }
                    for alumno in m.Alumnos.objects.filter(estado=1).order_by(
                        "apellido_paterno", "apellido_materno", "nombre"
                    )
                ],
                "grupos": grupos_opciones,
            }

        elif seccion == "asistencias":
            registros = m.Asistencias.objects.filter(
                id_inscripcion__in=inscripciones
            ).select_related("id_inscripcion__id_alumno",
                             "id_inscripcion__id_grupo")

            datos = [
                {
                    "id_asistencia": a.id_asistencia,
                    "id_inscripcion": a.id_inscripcion_id,
                    "alumno": " ".join(filter(None, [
                        a.id_inscripcion.id_alumno.nombre,
                        a.id_inscripcion.id_alumno.apellido_paterno,
                        a.id_inscripcion.id_alumno.apellido_materno
                    ])),
                    "matricula": a.id_inscripcion.id_alumno.matricula,
                    "grupo": a.id_inscripcion.id_grupo.nombre_grupo,
                    "fecha": a.fecha,
                    "estado": a.estado,
                    "observaciones": a.observaciones
                }
                for a in registros
            ]
            opciones = {
                "inscripciones": [
                    {
                        "id_inscripcion": inscripcion.id_inscripcion,
                        "alumno": " ".join(filter(None, [
                            inscripcion.id_alumno.nombre,
                            inscripcion.id_alumno.apellido_paterno,
                            inscripcion.id_alumno.apellido_materno
                        ])),
                        "matricula": inscripcion.id_alumno.matricula,
                        "grupo": inscripcion.id_grupo.nombre_grupo,
                    }
                    for inscripcion in inscripciones.select_related(
                        "id_alumno", "id_grupo"
                    )
                ],
            }

        elif seccion == "evaluaciones":
            opciones = {"grupos": grupos_opciones}
            registros = m.Evaluaciones.objects.filter(
                id_grupo__in=grupos,
                estado=1
            ).select_related("id_grupo")

            datos = [
                {
                    "id_evaluacion": e.id_evaluacion,
                    "id_grupo": e.id_grupo_id,
                    "grupo": e.id_grupo.nombre_grupo,
                    "nombre_evaluacion": e.nombre_evaluacion,
                    "tipo_evaluacion": e.tipo_evaluacion,
                    "porcentaje": e.porcentaje,
                    "fecha": e.fecha
                }
                for e in registros
            ]

        else:
            registros = m.Calificaciones.objects.filter(
                id_inscripcion__in=inscripciones,
                id_evaluacion__id_grupo__in=grupos,
                estado=1
            ).select_related(
                "id_inscripcion__id_alumno",
                "id_inscripcion__id_grupo",
                "id_evaluacion"
            )

            datos = [
                {
                    "id_calificacion": c.id_calificacion,
                    "id_inscripcion": c.id_inscripcion_id,
                    "id_evaluacion": c.id_evaluacion_id,
                    "alumno": " ".join(filter(None, [
                        c.id_inscripcion.id_alumno.nombre,
                        c.id_inscripcion.id_alumno.apellido_paterno,
                        c.id_inscripcion.id_alumno.apellido_materno
                    ])),
                    "matricula": c.id_inscripcion.id_alumno.matricula,
                    "grupo": c.id_inscripcion.id_grupo.nombre_grupo,
                    "evaluacion": c.id_evaluacion.nombre_evaluacion,
                    "calificacion": c.calificacion,
                    "observaciones": c.observaciones
                }
                for c in registros
            ]
            opciones = {
                "inscripciones": [
                    {
                        "id_inscripcion": inscripcion.id_inscripcion,
                        "alumno": " ".join(filter(None, [
                            inscripcion.id_alumno.nombre,
                            inscripcion.id_alumno.apellido_paterno,
                            inscripcion.id_alumno.apellido_materno
                        ])),
                        "matricula": inscripcion.id_alumno.matricula,
                        "id_grupo": inscripcion.id_grupo_id,
                        "grupo": inscripcion.id_grupo.nombre_grupo,
                    }
                    for inscripcion in inscripciones.select_related(
                        "id_alumno", "id_grupo"
                    )
                ],
                "evaluaciones": [
                    {
                        "id_evaluacion": evaluacion.id_evaluacion,
                        "id_grupo": evaluacion.id_grupo_id,
                        "grupo": evaluacion.id_grupo.nombre_grupo,
                        "nombre": evaluacion.nombre_evaluacion,
                    }
                    for evaluacion in m.Evaluaciones.objects.filter(
                        id_grupo__in=grupos, estado=1
                    ).select_related("id_grupo")
                ],
            }

        return JsonResponse({
            "success": True,
            "datos": datos,
            "opciones": opciones,
        })

    # -------------------- RECIBIR DATOS --------------------
    datos = _leer_json(request)
    if datos is None or not isinstance(datos, dict):
        return _respuesta("Envía un objeto JSON válido.")

    try:
        with transaction.atomic():

            # -------------------- ALUMNOS / INSCRIPCIONES --------------------
            if seccion == "alumnos":
                if request.method == "POST":
                    alumno = m.Alumnos.objects.filter(
                        pk=datos.get("id_alumno"), estado=1
                    ).first()

                    grupo = grupos.filter(
                        pk=datos.get("id_grupo")
                    ).first()

                    if not alumno or not grupo:
                        return _respuesta(
                            "El alumno o el grupo no existe, está inactivo "
                            "o no pertenece a este docente."
                        )

                    if inscripciones.filter(
                        id_alumno=alumno, id_grupo=grupo
                    ).exists():
                        return _respuesta(
                            "El alumno ya tiene una inscripción activa en ese grupo."
                        )

                    inscripcion = m.Inscripciones.objects.create(
                        id_alumno=alumno,
                        id_grupo=grupo,
                        fecha_inscripcion=date.today(),
                        estado=1,
                        observaciones=datos.get("observaciones", "")
                    )

                    return JsonResponse({
                        "success": True,
                        "mensaje": "Alumno inscrito correctamente.",
                        "id": inscripcion.id_inscripcion
                    }, status=201)

                registro = inscripciones.filter(
                    pk=registro_id
                ).first()

                if not registro:
                    return _respuesta("Inscripción no encontrada.", 404)

                if request.method == "PUT":
                    alumno_anterior = registro.id_alumno_id
                    grupo_anterior = registro.id_grupo_id
                    if "id_alumno" in datos:
                        alumno = m.Alumnos.objects.filter(
                            pk=datos["id_alumno"], estado=1
                        ).first()
                        if not alumno:
                            return _respuesta("El alumno no existe o está inactivo.")
                        registro.id_alumno = alumno

                    if "id_grupo" in datos:
                        grupo = grupos.filter(
                            pk=datos["id_grupo"]
                        ).first()
                        if not grupo:
                            return _respuesta(
                                "El grupo no pertenece a este docente."
                            )
                        registro.id_grupo = grupo

                    if inscripciones.filter(
                        id_alumno=registro.id_alumno,
                        id_grupo=registro.id_grupo
                    ).exclude(pk=registro.pk).exists():
                        return _respuesta(
                            "El alumno ya tiene una inscripción activa en ese grupo."
                        )

                    if "observaciones" in datos:
                        registro.observaciones = datos["observaciones"]

                    if (registro.id_alumno_id != alumno_anterior or registro.id_grupo_id != grupo_anterior) and (
                        m.Calificaciones.objects.filter(id_inscripcion=registro).exists()
                        or m.Asistencias.objects.filter(id_inscripcion=registro).exists()
                        or m.Pagos.objects.filter(id_inscripcion=registro).exists()
                    ):
                        return _respuesta('La inscripción tiene historial. Conserva el alumno y grupo; puedes editar sus observaciones.')
                    registro.save()
                    return JsonResponse({
                        "success": True,
                        "mensaje": "Inscripción actualizada."
                    })

                registro.estado = 0
                registro.save(update_fields=["estado"])
                return JsonResponse({
                    "success": True,
                    "mensaje": "Inscripción desactivada."
                })

            # -------------------- ASISTENCIAS --------------------
            if seccion == "asistencias":
                if request.method in ('POST', 'PUT') and 'estado' in datos and datos['estado'] not in {'Presente', 'Ausente', 'Justificada', 'Retardo'}:
                    return _respuesta('Selecciona un estado de asistencia válido.')
                if request.method == "POST":
                    inscripcion = inscripciones.filter(
                        pk=datos.get("id_inscripcion")
                    ).first()

                    if not inscripcion:
                        return _respuesta(
                            "La inscripción no pertenece a un grupo activo tuyo."
                        )

                    if not datos.get("fecha") or not datos.get("estado"):
                        return _respuesta(
                            "La fecha y el estado de asistencia son obligatorios."
                        )

                    if m.Asistencias.objects.filter(id_inscripcion=inscripcion, fecha=_fecha(datos['fecha'])).exists():
                        return _respuesta('Ya existe una asistencia para este alumno en esa fecha.')
                    asistencia = m.Asistencias.objects.create(
                        id_inscripcion=inscripcion,
                        fecha=_fecha(datos["fecha"]),
                        estado=str(datos["estado"])[:20],
                        observaciones=datos.get("observaciones", "")
                    )

                    return JsonResponse({
                        "success": True,
                        "mensaje": "Asistencia registrada.",
                        "id": asistencia.id_asistencia
                    }, status=201)

                asistencia = m.Asistencias.objects.filter(
                    pk=registro_id,
                    id_inscripcion__in=inscripciones
                ).first()

                if not asistencia:
                    return _respuesta("Asistencia no encontrada.", 404)

                if request.method == "PUT":
                    if 'id_inscripcion' in datos and str(datos['id_inscripcion']) != str(asistencia.id_inscripcion_id):
                        return _respuesta('No puedes cambiar el alumno de una asistencia registrada.')
                    if "fecha" in datos:
                        asistencia.fecha = _fecha(datos["fecha"])
                    if "estado" in datos:
                        asistencia.estado = str(datos["estado"])[:20]
                    if "observaciones" in datos:
                        asistencia.observaciones = datos["observaciones"]

                    if m.Asistencias.objects.filter(id_inscripcion=asistencia.id_inscripcion, fecha=asistencia.fecha).exclude(pk=asistencia.pk).exists():
                        return _respuesta('Ya existe una asistencia para este alumno en esa fecha.')
                    asistencia.save()
                    return JsonResponse({
                        "success": True,
                        "mensaje": "Asistencia actualizada."
                    })

                asistencia.delete()
                return JsonResponse({
                    "success": True,
                    "mensaje": "Asistencia eliminada."
                })

            # -------------------- EVALUACIONES --------------------
            if seccion == "evaluaciones":
                if request.method in ('POST', 'PUT') and 'nombre_evaluacion' in datos:
                    datos['nombre_evaluacion'] = str(datos['nombre_evaluacion'] or '').strip()
                    if not datos['nombre_evaluacion'] or len(datos['nombre_evaluacion']) > 100:
                        return _respuesta('Escribe un nombre de evaluación de entre 1 y 100 caracteres.')
                if request.method == "POST":
                    grupo = grupos.filter(
                        pk=datos.get("id_grupo")
                    ).first()

                    nombre = datos.get("nombre_evaluacion")
                    if not grupo or not nombre:
                        return _respuesta(
                            "Selecciona un grupo propio y escribe el nombre "
                            "de la evaluación."
                        )

                    porcentaje = datos.get("porcentaje")
                    if porcentaje not in (None, ""):
                        porcentaje = _decimal(porcentaje)
                        if porcentaje < 0 or porcentaje > 100:
                            return _respuesta(
                                "El porcentaje debe estar entre 0 y 100."
                            )
                    else:
                        porcentaje = None

                    evaluacion = m.Evaluaciones.objects.create(
                        id_grupo=grupo,
                        nombre_evaluacion=str(nombre)[:100],
                        tipo_evaluacion=datos.get("tipo_evaluacion"),
                        porcentaje=porcentaje,
                        fecha=_fecha(datos["fecha"]) if datos.get("fecha") else None,
                        estado=1
                    )

                    return JsonResponse({
                        "success": True,
                        "mensaje": "Evaluación creada.",
                        "id": evaluacion.id_evaluacion
                    }, status=201)

                evaluacion = m.Evaluaciones.objects.filter(
                    pk=registro_id, id_grupo__in=grupos, estado=1
                ).first()

                if not evaluacion:
                    return _respuesta("Evaluación no encontrada.", 404)

                if request.method == "PUT":
                    if "id_grupo" in datos:
                        grupo = grupos.filter(pk=datos["id_grupo"]).first()
                        if not grupo:
                            return _respuesta(
                                "El grupo no pertenece a este docente."
                            )
                        evaluacion.id_grupo = grupo

                    if "nombre_evaluacion" in datos:
                        evaluacion.nombre_evaluacion = str(
                            datos["nombre_evaluacion"]
                        )[:100]
                    if "tipo_evaluacion" in datos:
                        evaluacion.tipo_evaluacion = datos["tipo_evaluacion"]
                    if "porcentaje" in datos:
                        valor = datos["porcentaje"]
                        evaluacion.porcentaje = (
                            _decimal(valor) if valor not in ("", None) else None
                        )
                        if evaluacion.porcentaje is not None and not (
                            0 <= evaluacion.porcentaje <= 100
                        ):
                            return _respuesta(
                                "El porcentaje debe estar entre 0 y 100."
                            )
                    if "fecha" in datos:
                        evaluacion.fecha = (
                            _fecha(datos["fecha"]) if datos["fecha"] else None
                        )

                    if m.Calificaciones.objects.filter(id_evaluacion=evaluacion).exclude(id_inscripcion__id_grupo_id=evaluacion.id_grupo_id).exists():
                        return _respuesta('No puedes mover a otro grupo una evaluación con calificaciones registradas.')
                    evaluacion.save()
                    return JsonResponse({
                        "success": True,
                        "mensaje": "Evaluación actualizada."
                    })

                evaluacion.estado = 0
                evaluacion.save(update_fields=["estado"])
                return JsonResponse({
                    "success": True,
                    "mensaje": "Evaluación desactivada."
                })

            # -------------------- CALIFICACIONES --------------------
            if seccion == "calificaciones":
                if request.method == "POST":
                    inscripcion = inscripciones.filter(
                        pk=datos.get("id_inscripcion")
                    ).first()
                    evaluacion = m.Evaluaciones.objects.filter(
                        pk=datos.get("id_evaluacion"),
                        id_grupo__in=grupos,
                        estado=1
                    ).first()

                    if (
                        not inscripcion or not evaluacion
                        or inscripcion.id_grupo_id != evaluacion.id_grupo_id
                    ):
                        return _respuesta(
                            "La inscripción y la evaluación deben pertenecer "
                            "al mismo grupo asignado a este docente."
                        )

                    if datos.get("calificacion") in (None, ""):
                        return _respuesta("La calificación es obligatoria.")

                    calificacion = _decimal(datos["calificacion"])
                    if not 0 <= calificacion <= 100:
                        return _respuesta(
                            "La calificación debe estar entre 0 y 100."
                        )

                    if m.Calificaciones.objects.filter(
                        id_inscripcion=inscripcion,
                        id_evaluacion=evaluacion,
                        estado=1
                    ).exists():
                        return _respuesta(
                            "Ya existe una calificación para esa evaluación y ese alumno."
                        )

                    registro = m.Calificaciones.objects.create(
                        id_inscripcion=inscripcion,
                        id_evaluacion=evaluacion,
                        calificacion=calificacion,
                        observaciones=datos.get("observaciones", ""),
                        fecha_registro=timezone.now(),
                        estado=1
                    )

                    return JsonResponse({
                        "success": True,
                        "mensaje": "Calificación registrada.",
                        "id": registro.id_calificacion
                    }, status=201)

                registro = m.Calificaciones.objects.filter(
                    pk=registro_id,
                    id_inscripcion__in=inscripciones,
                    id_evaluacion__id_grupo__in=grupos,
                    estado=1
                ).first()

                if not registro:
                    return _respuesta("Calificación no encontrada.", 404)

                if request.method == "PUT":
                    nueva_inscripcion = inscripciones.filter(
                        pk=datos.get(
                            "id_inscripcion", registro.id_inscripcion_id
                        )
                    ).first()

                    nueva_evaluacion = m.Evaluaciones.objects.filter(
                        pk=datos.get(
                            "id_evaluacion", registro.id_evaluacion_id
                        ),
                        id_grupo__in=grupos,
                        estado=1
                    ).first()

                    if (
                        not nueva_inscripcion or not nueva_evaluacion
                        or nueva_inscripcion.id_grupo_id
                        != nueva_evaluacion.id_grupo_id
                    ):
                        return _respuesta(
                            "La inscripción y la evaluación deben pertenecer "
                            "al mismo grupo propio."
                        )

                    if m.Calificaciones.objects.filter(
                        id_inscripcion=nueva_inscripcion,
                        id_evaluacion=nueva_evaluacion,
                        estado=1
                    ).exclude(pk=registro.pk).exists():
                        return _respuesta(
                            "Ya existe una calificación para esa evaluación y ese alumno."
                        )

                    if "calificacion" in datos:
                        valor = _decimal(datos["calificacion"])
                        if not 0 <= valor <= 100:
                            return _respuesta(
                                "La calificación debe estar entre 0 y 100."
                            )
                        registro.calificacion = valor

                    registro.id_inscripcion = nueva_inscripcion
                    registro.id_evaluacion = nueva_evaluacion

                    if "observaciones" in datos:
                        registro.observaciones = datos["observaciones"]

                    registro.save()
                    return JsonResponse({
                        "success": True,
                        "mensaje": "Calificación actualizada."
                    })

                registro.estado = 0
                registro.save(update_fields=["estado"])
                return JsonResponse({
                    "success": True,
                    "mensaje": "Calificación desactivada."
                })

    except (ValueError, TypeError, InvalidOperation):
        return _respuesta("Revisa las fechas y los valores numéricos enviados.")
    except Exception:
        # El detalle técnico queda en el registro del servidor.
        import logging
        logging.getLogger(__name__).exception("Error en CRUD del docente")
        return _respuesta("No se pudo completar la operación.", 400)
