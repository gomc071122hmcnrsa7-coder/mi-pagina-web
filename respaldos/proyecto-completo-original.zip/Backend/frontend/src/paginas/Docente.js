export { default } from "./DocenteAsignaciones";


