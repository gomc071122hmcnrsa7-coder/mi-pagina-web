import json
from io import BytesIO
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from django.core import signing
from django.http import Http404, JsonResponse
from django.test import SimpleTestCase, RequestFactory

from .acceso import _normalizar_rol
from .panel_alumno import alumno_autenticado, archivo_material, mis_cursos


class RolTests(SimpleTestCase):
    def test_alumnos_se_normaliza_como_alumno(self):
        self.assertEqual(_normalizar_rol('Alumnos'), 'alumno')
        self.assertEqual(_normalizar_rol('Alumno'), 'alumno')


class PanelAlumnoTests(SimpleTestCase):
    def setUp(self):
        catalogo = patch('bibliotecaapp.panel_alumno.cursos_disponibles', return_value=[])
        catalogo.start()
        self.addCleanup(catalogo.stop)
        self.factory = RequestFactory()
        self.alumno = SimpleNamespace(pk=7, nombre='Ana', matricula='M007')
        self.token = signing.dumps({'id_usuario': 42}, salt='panel-alumno')

    def request(self, path='/api/alumno/mis-cursos/'):
        return self.factory.get(path, HTTP_AUTHORIZATION=f'Bearer {self.token}')

    def test_sin_token_no_accede(self):
        response = mis_cursos(self.factory.get('/api/alumno/mis-cursos/'))
        self.assertEqual(response.status_code, 401)

    def test_token_alterado_no_accede(self):
        self.token += 'alterado'
        self.assertEqual(mis_cursos(self.request()).status_code, 401)

    def test_token_vencido_no_accede(self):
        with patch('django.core.signing.time.time', return_value=1):
            self.token = signing.dumps({'id_usuario': 42}, salt='panel-alumno')
        self.assertEqual(mis_cursos(self.request()).status_code, 401)

    @patch('bibliotecaapp.panel_alumno.Alumnos.objects.filter')
    def test_identidad_procede_del_token_no_del_parametro(self, alumnos):
        alumnos.return_value.first.return_value = self.alumno
        view = alumno_autenticado(lambda request: JsonResponse({'id': request.alumno.pk}))
        response = view(self.request('/?id_alumno=999'))
        self.assertEqual(json.loads(response.content)['id'], 7)
        self.assertEqual(alumnos.call_args.kwargs, {
            'id_usuario_id': 42,
            'estado': 1,
            'id_usuario__estado': 1,
        })
        filtro_rol = alumnos.call_args.args[0]
        self.assertEqual(filtro_rol.connector, 'OR')
        self.assertEqual(
            [lookup for lookup, _ in filtro_rol.children],
            [
                'id_usuario__id_rol__nombre_rol__iexact',
                'id_usuario__id_rol__nombre_rol__iexact',
            ],
        )
        self.assertEqual(response['Cache-Control'], 'private, no-store')

    @patch('bibliotecaapp.panel_alumno.completar_perfil_alumno', return_value=None)
    @patch('bibliotecaapp.panel_alumno.Alumnos.objects.filter')
    def test_sin_perfil_activo_no_accede(self, alumnos, completar):
        alumnos.return_value.first.return_value = None
        self.assertEqual(mis_cursos(self.request()).status_code, 403)

    @patch('bibliotecaapp.panel_alumno.Inscripciones.objects.filter')
    @patch('bibliotecaapp.panel_alumno.Alumnos.objects.filter')
    def test_sin_inscripciones_devuelve_lista_vacia(self, alumnos, inscripciones):
        alumnos.return_value.first.return_value = self.alumno
        inscripciones.return_value.select_related.return_value.order_by.return_value = []
        response = mis_cursos(self.request())
        self.assertEqual(json.loads(response.content)['cursos'], [])
        inscripciones.assert_called_once_with(id_alumno=self.alumno, estado=1)

    @patch('bibliotecaapp.panel_alumno.get_object_or_404')
    @patch('bibliotecaapp.panel_alumno.Inscripciones.objects.filter')
    @patch('bibliotecaapp.panel_alumno.Alumnos.objects.filter')
    def test_no_descarga_material_de_otro_curso(self, alumnos, inscripciones, material):
        alumnos.return_value.first.return_value = self.alumno
        material.return_value = SimpleNamespace(curso_id=12)
        inscripciones.return_value.filter.return_value.exists.return_value = False
        with self.assertRaises(Http404):
            archivo_material(self.request(), 99)
        inscripciones.return_value.filter.assert_called_once_with(id_grupo__id_curso_id=12)
        self.assertTrue(material.call_args.kwargs['publicado'])

    @patch('bibliotecaapp.panel_alumno.get_object_or_404')
    @patch('bibliotecaapp.panel_alumno.Inscripciones.objects.filter')
    @patch('bibliotecaapp.panel_alumno.Alumnos.objects.filter')
    def test_descarga_y_consulta_pdf(self, alumnos, inscripciones, material):
        alumnos.return_value.first.return_value = self.alumno
        inscripciones.return_value.filter.return_value.exists.return_value = True
        archivo = MagicMock()
        archivo.name = 'materiales/guia.pdf'
        archivo.open.side_effect = lambda modo: BytesIO(b'%PDF-1.4 ejemplo')
        material.return_value = SimpleNamespace(curso_id=12, archivo=archivo)
        for query, disposition in [('', 'attachment'), ('?ver=1', 'inline')]:
            response = archivo_material(self.request('/archivo/' + query), 99)
            self.assertTrue(response['Content-Disposition'].startswith(disposition))
            self.assertEqual(b''.join(response.streaming_content), b'%PDF-1.4 ejemplo')
            response.close()

    @patch('bibliotecaapp.panel_alumno.MaterialCurso.objects.filter')
    @patch('bibliotecaapp.panel_alumno.Horarios.objects.filter')
    @patch('bibliotecaapp.panel_alumno.Inscripciones.objects.filter')
    @patch('bibliotecaapp.panel_alumno.Alumnos.objects.filter')
    def test_horarios_corresponden_al_grupo_inscrito(self, alumnos, inscripciones, horarios, materiales):
        alumnos.return_value.first.return_value = self.alumno
        curso = SimpleNamespace(pk=12, nombre_curso='Inglés', descripcion='Curso', duracion_horas=20, nivel='Inicial')
        grupo = SimpleNamespace(nombre_grupo='A', id_curso=curso,
            id_docente=SimpleNamespace(nombre='Luis', apellido_paterno='Pérez', apellido_materno=None),
            id_periodo=SimpleNamespace(nombre_periodo='2026', fecha_inicio='2026-10-01', fecha_fin='2026-12-01'))
        inscripciones.return_value.select_related.return_value.order_by.return_value = [SimpleNamespace(pk=8, id_grupo=grupo)]
        horarios.return_value.select_related.return_value.order_by.return_value = []
        materiales.return_value = []
        with patch('bibliotecaapp.panel_alumno.Calificaciones.objects.filter') as notas, \
             patch('bibliotecaapp.panel_alumno.Pagos.objects.filter') as pagos, \
             patch('bibliotecaapp.panel_alumno.Asistencias.objects.filter') as asistencias, \
             patch('bibliotecaapp.panel_alumno.Evaluaciones.objects.filter') as evaluaciones:
            notas.return_value.select_related.return_value = []
            for consulta in [pagos, asistencias, evaluaciones]:
                consulta.return_value.values.return_value = []
            response = mis_cursos(self.request())
        horarios.assert_called_once_with(id_grupo=grupo, estado=1)
        materiales.assert_called_once_with(curso=curso, publicado=True)
        self.assertEqual(json.loads(response.content)['cursos'][0]['grupo'], 'A')
