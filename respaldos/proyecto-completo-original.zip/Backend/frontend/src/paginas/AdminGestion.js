import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../api/api";
import { escucharCambiosDocente } from "../api/cambiosDocente";
import SelectorRelacion from "../componentes/SelectorRelacion";
import { buscar, mismo, opcionesRelacion, textoRegistro, valorTabla } from "./adminDatos";
import "./Admin.css";

const hoy = () => { const f = new Date(); return `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, "0")}-${String(f.getDate()).padStart(2, "0")}`; };

function Icono({ tipo = "tabla", ...props }) {
    const trazos = {
        tabla: "M4 4h16v16H4zM4 10h16M10 10v10",
        personas: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M16 3a4 4 0 0 1 0 8M22 21v-2a4 4 0 0 0-3-3.87M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0",
        libro: "M12 5v16M12 5C8 2 4 3 2 4v15c3-1 7-1 10 2 3-3 7-3 10-2V4c-3-1-7-2-10 1",
        calendario: "M4 5h16v16H4zM8 3v4M16 3v4M4 11h16M8 15h2M14 15h2",
        agregar: "M12 5v14M5 12h14",
        actualizar: "M20 7a9 9 0 0 0-15-1L3 8m0-5v5h5M4 17a9 9 0 0 0 15 1l2-2m0 5v-5h-5",
        buscar: "M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0",
        salir: "M9 21H3V3h6M9 12h12m-5-5 5 5-5 5",
        editar: "m16 3 5 5-12 12H4v-5zM13 6l5 5",
        eliminar: "M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7",
    };
    return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><path d={trazos[tipo] || trazos.tabla} /></svg>;
}
const iconoSeccion = clave => ["usuarios", "alumnos", "docentes", "padres", "familias"].includes(clave) ? "personas" : ["horarios", "periodos", "dias", "asistencias"].includes(clave) ? "calendario" : ["cursos", "evaluaciones", "calificaciones"].includes(clave) ? "libro" : "tabla";
const gruposMenu = { usuarios: "Comunidad", cursos: "Organización académica", inscripciones: "Seguimiento", periodos: "Catálogos" };

export default function AdminGestion() {
    const navigate = useNavigate();
    const [tablas, setTablas] = useState({});
    const [resumenPagos, setResumenPagos] = useState([]);
    const [seccion, setSeccion] = useState("alumnos");
    const [busqueda, setBusqueda] = useState("");
    const [orden, setOrden] = useState({ campo: "", asc: true });
    const [formulario, setFormulario] = useState(false);
    const [registro, setRegistro] = useState(null);
    const [datos, setDatos] = useState({});
    const [alumnoFiltro, setAlumnoFiltro] = useState("");
    const [errores, setErrores] = useState({});
    const [mensaje, setMensaje] = useState("");
    const [cargando, setCargando] = useState(true);
    const [guardando, setGuardando] = useState(false);
    const config = tablas[seccion];
    const cargar = useCallback(async () => {
        const token = sessionStorage.getItem("token_panel");
        if (!token) { navigate("/login", { replace: true }); return; }
        try {
            const { data } = await API.get("gestion/catalogo/", { headers: { Authorization: `Bearer ${token}` } });
            setTablas(data.tablas);
            setResumenPagos(data.resumen_pagos || []);
        } catch (error) {
            if ([401, 403].includes(error.response?.status)) setTablas({});
            if (error.response?.status === 401) navigate("/login", { replace: true });
            setMensaje(error.response?.data?.mensaje || "No se pudieron cargar los registros. Pulsa Actualizar.");
        } finally { setCargando(false); }
    }, [navigate]);
    useEffect(() => {
        cargar(); const intervalo = setInterval(cargar, 15000); window.addEventListener("focus", cargar);
        const dejarDeEscuchar = escucharCambiosDocente(cargar);
        return () => { dejarDeEscuchar(); clearInterval(intervalo); window.removeEventListener("focus", cargar); };
    }, [cargar]);
    const abrir = (fila = null) => {
        const valores = {};
        config.campos.forEach(c => {
            valores[c.nombre] = fila?.[c.nombre] ?? (c.nombre === "estado" ? (seccion === "asistencias" ? "Presente" : 1) : c.tipo === "date" && ["fecha_inscripcion", "fecha_pago", "fecha"].includes(c.nombre) ? hoy() : "");
        });
        setRegistro(fila); setDatos(valores); setErrores({}); setMensaje("");
        setAlumnoFiltro(buscar(tablas, "inscripciones", fila?.id_inscripcion)?.id_alumno ?? ""); setFormulario(true);
    };
    const cambiar = (campo, valor) => setDatos(actual => ({ ...actual, [campo]: valor, ...(campo === "id_inscripcion" ? { id_evaluacion: "" } : {}) }));
    const guardar = async event => {
        event.preventDefault(); setGuardando(true); setErrores({}); setMensaje("");
        try {
            const { data } = await API.request({ url: `gestion/${seccion}/${registro ? `${registro[config.pk]}/` : ""}`, method: registro ? "PUT" : "POST", data: datos,
                headers: { Authorization: `Bearer ${sessionStorage.getItem("token_panel")}` } });
            setMensaje(data.mensaje); setFormulario(false); await cargar();
        } catch (error) { setErrores(error.response?.data?.errores || {}); setMensaje(error.response?.data?.mensaje || "No se pudieron guardar los cambios."); }
        finally { setGuardando(false); }
    };
    const subirConstancia = async (fila, archivo) => {
        if (!archivo) return;
        setGuardando(true); setMensaje("");
        const cuerpo = new FormData(); cuerpo.append("archivo", archivo);
        try {
            const { data } = await API.post(`gestion/constancias/${fila.id_certificacion}/archivo/`, cuerpo,
                { headers: { Authorization: `Bearer ${sessionStorage.getItem("token_panel")}` } });
            setMensaje(data.mensaje); await cargar();
        } catch (error) { setMensaje(error.response?.data?.mensaje || "No se pudo subir el PDF."); }
        finally { setGuardando(false); }
    };
    const eliminar = async fila => {
        if (!window.confirm("¿Eliminar este registro? Si tiene información relacionada, puedes editarlo y marcarlo como inactivo.")) return;
        setGuardando(true);
        try {
            await API.delete(`gestion/${seccion}/${fila[config.pk]}/`, { headers: { Authorization: `Bearer ${sessionStorage.getItem("token_panel")}` } });
            setMensaje("Registro eliminado."); await cargar();
        } catch (error) { setMensaje(error.response?.data?.mensaje || "No se pudo eliminar el registro."); }
        finally { setGuardando(false); }
    };
    const columnas = (config?.campos || []).filter(c => c.tipo !== "password");
    const alumnoDe = fila => textoRegistro(tablas, "alumnos", buscar(tablas, "alumnos", buscar(tablas, "inscripciones", fila.id_inscripcion)?.id_alumno));
    const filas = [...(config?.registros || [])].filter(r => [...columnas.map(c => valorTabla(tablas, c, r)), ...(seccion === "calificaciones" ? [alumnoDe(r)] : [])].join(" ").toLocaleLowerCase("es").includes(busqueda.toLocaleLowerCase("es")))
        .sort((a, b) => { const c = columnas.find(c => c.nombre === orden.campo) || columnas[0]; return String(c ? valorTabla(tablas, c, a) : "").localeCompare(String(c ? valorTabla(tablas, c, b) : ""), "es", { numeric: true }) * (orden.asc ? 1 : -1); });
    return <div className="administracion">
        <aside className="admin-menu">
            <Link to="/" className="admin-marca"><img src="/montreal.jpeg" alt="Montreal" width="44" height="44" /><span><strong>Montreal</strong><small>Gestión institucional</small></span></Link>
            <div className="admin-menu-titulo">ESPACIO DE ADMINISTRACIÓN</div>
            <nav aria-label="Secciones del administrador">{Object.entries(tablas).map(([clave, tabla]) => <div className="admin-nav-item" key={clave}>
                {gruposMenu[clave] && <p className="admin-nav-grupo">{gruposMenu[clave]}</p>}
                <button disabled={guardando}
                className={`admin-nav-boton ${clave === seccion ? "seleccionado" : ""}`} aria-current={clave === seccion ? "page" : undefined}
                onClick={() => { setSeccion(clave); setFormulario(false); setBusqueda(""); setOrden({ campo: "", asc: true }); setMensaje(""); }}>
                <Icono tipo={iconoSeccion(clave)} /><span>{tabla.titulo}</span><span className="admin-nav-cantidad">{tabla.registros.length}</span></button></div>)}</nav>
            <div className="admin-menu-pie"><span className="admin-avatar" aria-hidden="true">AD</span><div><strong>Administrador</strong><small>Gestión de la institución</small></div>
            <button className="admin-salir" title="Cerrar sesión" aria-label="Cerrar sesión" onClick={() => { sessionStorage.removeItem("token_panel"); sessionStorage.removeItem("token_alumno"); localStorage.removeItem("usuario"); navigate("/login"); }}><Icono tipo="salir" /></button></div>
        </aside>
        <main className="admin-contenido">
            <div className="admin-barra-superior"><span>Administración <span aria-hidden="true">/</span> <strong>{config?.titulo || "Panel principal"}</strong></span><span className="admin-actualizacion">Actualización automática · 15 s</span></div>
            <header className="admin-encabezado">
                <div><span className="admin-sobretitulo">CONTROL INSTITUCIONAL</span><h1>{config?.titulo || "Administración"}</h1><p>Consulta, organiza y administra la información de tu institución.</p></div>
                <div className="admin-acciones"><button className="btn btn-outline-dark" onClick={cargar} disabled={guardando}><Icono tipo="actualizar" />Actualizar</button>{config && <button className="btn btn-dark" onClick={() => abrir()} disabled={guardando}><Icono tipo="agregar" />Insertar registro</button>}</div>
            </header>
            {seccion === "horarios" && <p className="alert alert-info">Un grupo puede tener sesiones en varios d?as. No se permiten horarios activos duplicados ni cruces de grupo, docente o aula en periodos coincidentes.</p>}
            {seccion === "pagos" && <section className="card p-4 mb-4" aria-labelledby="resumen-pagos">
                <h2 id="resumen-pagos" className="h4">Estado de pago por inscripci?n</h2>
                <p>Se compara el costo actual del curso con los abonos activos en MXN. Los pagos en otra moneda o un costo pendiente requieren revisi?n.</p>
                <div className="table-responsive"><table className="table">
                    <thead><tr>{["Alumno", "Curso", "Grupo", "Costo MXN", "Pagado MXN", "Saldo MXN", "Situaci?n"].map(t => <th scope="col" key={t}>{t}</th>)}</tr></thead>
                    <tbody>{resumenPagos.filter(r => `${r.alumno} ${r.curso} ${r.grupo} ${r.situacion}`.toLocaleLowerCase("es").includes(busqueda.toLocaleLowerCase("es"))).map(r => <tr key={r.id_inscripcion}>
                        <td>{r.alumno}</td><td>{r.curso}</td><td>{r.grupo}</td>
                        {[r.costo, r.pagado, r.saldo].map((v, i) => <td key={i}>{v == null ? "Por confirmar" : Number(v).toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>)}
                        <td><strong>{r.situacion}</strong></td>
                    </tr>)}</tbody>
                </table></div>
                {!resumenPagos.length && <p>No hay inscripciones activas.</p>}
            </section>}
            {config && <section className="admin-resumen" aria-label="Resumen de la sección">
                <div><span className="admin-resumen-icono"><Icono tipo={iconoSeccion(seccion)} /></span><div><span>Total de registros</span><strong>{config.registros.length}</strong></div><small>{config.titulo}</small></div>
                <div><span className="admin-resumen-icono"><Icono tipo="buscar" /></span><div><span>Resultados visibles</span><strong>{filas.length}</strong></div><small>{busqueda ? "Con el filtro actual" : "Todos los registros"}</small></div>
                <div><span className="admin-resumen-icono"><Icono /></span><div><span>Secciones disponibles</span><strong>{Object.keys(tablas).length}</strong></div><small>Administración centralizada</small></div>
            </section>}
            {mensaje && <div role="status" className="alert alert-info">{mensaje}</div>}{cargando && <p role="status">Cargando tablas y opciones…</p>}
            {formulario && <section className="card admin-formulario p-4 mb-4" aria-labelledby="titulo-formulario">
                <div className="admin-formulario-titulo"><span className="admin-resumen-icono"><Icono tipo={registro ? "editar" : "agregar"} /></span><div><h2 id="titulo-formulario">{registro ? "Editar registro" : "Nuevo registro"}</h2><p>{config.titulo} · Los campos con * son obligatorios.</p></div></div>
                {seccion === "grupos" && <p className="text-muted">Asigna el curso, docente y periodo. Después agrega los días, horas y aula en Horarios.</p>}
                {seccion === "calificaciones" && <p className="text-muted">Selecciona el alumno, su inscripción y una evaluación de ese grupo.</p>}
                <form onSubmit={guardar}><fieldset disabled={guardando}><div className="row g-3">
                    {config.campos.some(c => c.nombre === "id_inscripcion") && <div className="col-md-6">
                        <label htmlFor="alumno-filtro" className="form-label">Alumno {seccion === "calificaciones" ? "*" : "(filtrar inscripciones)"}</label>
                        <SelectorRelacion id="alumno-filtro" value={alumnoFiltro} required={seccion === "calificaciones"}
                            opciones={(tablas.alumnos?.registros || []).map(a => ({ valor: a.id_alumno, texto: textoRegistro(tablas, "alumnos", a) }))}
                            onChange={valor => { setAlumnoFiltro(valor); setDatos(d => ({ ...d, id_inscripcion: "", id_evaluacion: "" })); }} />
                    </div>}
                    {config.campos.map(c => {
                        const opciones = c.relacion ? opcionesRelacion(tablas, seccion, c, datos, registro, alumnoFiltro) : c.opciones || [];
                        const opcionesFijas = !c.relacion && datos[c.nombre] !== "" && !opciones.some(o => mismo(o.valor, datos[c.nombre])) ? [...opciones, { valor: datos[c.nombre], texto: String(datos[c.nombre]) }] : opciones;
                        const requerido = c.requerido && !(registro && c.tipo === "password");
                        return <div className={c.tipo === "textarea" ? "col-12" : "col-md-6"} key={c.nombre}>
                            <label className="form-label" htmlFor={`campo-${c.nombre}`}>{c.etiqueta}{requerido ? " *" : ""}</label>
                            {c.relacion ? <SelectorRelacion id={`campo-${c.nombre}`} value={datos[c.nombre]} required={requerido} opciones={opciones} onChange={valor => cambiar(c.nombre, valor)} /> : c.tipo === "select" ?
                                <select id={`campo-${c.nombre}`} className="form-select" value={datos[c.nombre] ?? ""} required={requerido} onChange={e => cambiar(c.nombre, e.target.value)}><option value="">Selecciona una opción</option>{opcionesFijas.map(o => <option key={o.valor} value={o.valor}>{o.texto}</option>)}</select> : c.tipo === "textarea" ?
                                <textarea id={`campo-${c.nombre}`} className="form-control" rows="3" value={datos[c.nombre] ?? ""} required={requerido} onChange={e => cambiar(c.nombre, e.target.value)} /> :
                                <input id={`campo-${c.nombre}`} className="form-control" type={c.tipo} value={datos[c.nombre] ?? ""} required={requerido} maxLength={c.maxLength} step={c.paso} autoComplete={c.tipo === "password" ? "new-password" : undefined} onChange={e => cambiar(c.nombre, e.target.value)} />}
                            {c.tipo === "password" && registro && <small className="text-muted">Déjala vacía para conservar la contraseña.</small>}
                            {errores[c.nombre] && <p role="alert" className="text-danger mb-0">{[].concat(errores[c.nombre]).join(" ")}</p>}
                        </div>;
                    })}
                </div>{Object.entries(errores).filter(([campo]) => !config.campos.some(c => c.nombre === campo)).map(([campo, error]) => <p role="alert" className="text-danger" key={campo}>{[].concat(error).join(" ")}</p>)}
                <div className="admin-formulario-acciones"><button className="btn btn-outline-secondary" type="button" onClick={() => setFormulario(false)}>Cancelar</button><button className="btn btn-dark" type="submit">{guardando ? "Guardando…" : "Guardar cambios"}</button></div></fieldset></form>
            </section>}
            {config && <section className="card admin-registros" aria-label={`Registros de ${config.titulo}`}>
                <div className="admin-tabla-barra"><div><h2>Listado de {config.titulo.toLocaleLowerCase("es")}</h2><p>Selecciona un encabezado para ordenar los resultados.</p></div>
                <div className="admin-buscador"><label htmlFor="buscar-registros" className="visually-hidden">Buscar por nombre, grupo u otro dato</label><Icono tipo="buscar" /><input id="buscar-registros" placeholder="Buscar por nombre, grupo u otro dato…" className="form-control" type="search" value={busqueda} onChange={e => setBusqueda(e.target.value)} /></div></div>
                <div className="table-responsive admin-tabla-scroll"><table className="table table-hover align-middle"><caption>{filas.length} registros · {config.titulo}</caption>
                    <thead><tr>{seccion === "calificaciones" && <th scope="col">Alumno</th>}{columnas.map(c => <th key={c.nombre} scope="col" aria-sort={orden.campo === c.nombre ? (orden.asc ? "ascending" : "descending") : "none"}>
                        <button className="btn btn-link text-dark text-decoration-none p-0 text-start fw-bold" onClick={() => setOrden(o => ({ campo: c.nombre, asc: o.campo === c.nombre ? !o.asc : true }))}>{c.etiqueta} ↕</button></th>)}<th scope="col">Acciones</th></tr></thead>
                    <tbody>{filas.map(fila => <tr key={fila[config.pk]}>{seccion === "calificaciones" && <td>{alumnoDe(fila)}</td>}{columnas.map(c => <td key={c.nombre}>{c.nombre === "estado" ? <span className={`admin-estado ${mismo(fila[c.nombre], 1) || fila[c.nombre] === "Presente" ? "activo" : "neutro"}`}>{valorTabla(tablas, c, fila)}</span> : valorTabla(tablas, c, fila)}</td>)}<td><div className="admin-fila-acciones">{seccion === "certificaciones" && <label className="btn btn-sm btn-outline-success">Subir PDF<input type="file" accept=".pdf" className="visually-hidden" disabled={guardando} onChange={e => { subirConstancia(fila, e.target.files[0]); e.target.value = ""; }} /></label>}<button className="btn btn-sm btn-outline-dark" onClick={() => abrir(fila)} disabled={guardando}><Icono tipo="editar" />Editar</button><button className="btn btn-sm btn-outline-danger" onClick={() => eliminar(fila)} disabled={guardando}><Icono tipo="eliminar" />Eliminar</button></div></td></tr>)}</tbody>
                </table></div>{!filas.length && <div className="admin-vacio"><Icono tipo="buscar" width="32" height="32" /><h3>{busqueda ? "Sin coincidencias" : "Aún no hay registros"}</h3><p>{busqueda ? "Prueba con otro nombre o elimina el filtro de búsqueda." : "Usa Insertar registro para agregar el primero a esta sección."}</p></div>}
            </section>}
            <footer className="admin-pie"><span>Institución Montreal</span><span>Panel de administración</span></footer>
        </main>
    </div>;
}
