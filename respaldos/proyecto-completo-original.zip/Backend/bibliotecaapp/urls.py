from django.urls import path
from .importar_asistencias import revisar_asistencias, confirmar_asistencias
from .reporte_alumno import descargar_ficha
from .archivos_docente import archivos_docente, descargar_excel
from .constancias import mis_constancias, archivo_constancia, subir_constancia
from .panel_alumno import mis_cursos, archivo_material, inscribirme
from .panel_alumno import cursos_familia, archivo_familia
from .gestion import catalogo, guardar
from .panel_docente import datos_docente
from .panel_docente import crud_docente

from .views import (
    obtener_cursos,
    obtener_cursos_completos,
    crear_inscripcion,
    obtener_alumnos,
    obtener_docentes,
    obtener_grupos,
    obtener_inscripciones,
    obtener_inscripciones_alumno,
    obtener_horarios,
    obtener_usuarios,
    obtener_roles,
    obtener_periodos,
    obtener_aulas,
    obtener_dias,
    obtener_pagos,
    obtener_asistencias,
    obtener_evaluaciones,
    obtener_calificaciones,
    obtener_entidades,
    obtener_certificaciones,
    registro,
    login,

)


urlpatterns = [
    path('docente/asistencias/revisar/', revisar_asistencias),
    path('docente/asistencias/confirmar/', confirmar_asistencias),
    path('gestion/constancias/<int:constancia_id>/archivo/', subir_constancia),
    path('alumno/ficha/<str:formato>/', descargar_ficha),
    path('docente/archivos/', archivos_docente),
    path('docente/archivos/<int:archivo_id>/', descargar_excel),
    path('alumno/constancias/', mis_constancias),
    path('alumno/constancias/<int:constancia_id>/archivo/', archivo_constancia),
    path('gestion/catalogo/', catalogo),
    path('gestion/<str:tabla>/', guardar),
    path('gestion/<str:tabla>/<int:registro_id>/', guardar),
    path('padre/mis-cursos/', cursos_familia),
    path('padre/materiales/<int:material_id>/archivo/', archivo_familia),
    path('docente/datos/', datos_docente),
    path('docente/crud/', crud_docente),
    path('alumno/mis-cursos/', mis_cursos),
    path('alumno/inscribirme/', inscribirme),
    path('alumno/materiales/<int:material_id>/archivo/', archivo_material),

    # =========================================================
    # CONSULTAS
    # =========================================================

    path(
        'cursos/',
        obtener_cursos
    ),

    path(
        'cursos-completos/',
        obtener_cursos_completos
    ),

    path(
        'inscripciones/crear/',
        crear_inscripcion
    ),

    path(
        'alumnos/',
        obtener_alumnos
    ),

    path(
        'docentes/',
        obtener_docentes
    ),

    path(
        'grupos/',
        obtener_grupos
    ),

    path(
        'inscripciones/',
        obtener_inscripciones
    ),

    path(
        'inscripciones/alumno/<int:id_alumno>/',
        obtener_inscripciones_alumno
    ),

    path(
        'horarios/',
        obtener_horarios
    ),

    path(
        'usuarios/',
        obtener_usuarios
    ),

    path(
        'roles/',
        obtener_roles
    ),

    path(
        'periodos/',
        obtener_periodos
    ),

    path(
        'aulas/',
        obtener_aulas
    ),

    path(
        'dias/',
        obtener_dias
    ),

    path(
        'pagos/',
        obtener_pagos
    ),

    path(
        'asistencias/',
        obtener_asistencias
    ),

    path(
        'evaluaciones/',
        obtener_evaluaciones
    ),

    path(
        'calificaciones/',
        obtener_calificaciones
    ),

    path(
        'entidades/',
        obtener_entidades
    ),

    path(
        'certificaciones/',
        obtener_certificaciones
    ),


   # CRUD protegido del panel docente
    path(
    'docente/crud/<str:seccion>/',
    crud_docente,
    ),
   path(
    'docente/crud/<str:seccion>/<int:registro_id>/',
    crud_docente,
    ),

    # =========================================================
    # LOGIN / REGISTRO
    # =========================================================

    path(
        'login/',
        login
    ),

    path(
        'registro/',
        registro
    ),


    # =========================================================
    # CRUD DEL ADMINISTRADOR
    # =========================================================

    # INSERTAR
    path(
        'admin/<str:tabla>/',
        guardar
    ),

    # EDITAR
    path(
        'admin/<str:tabla>/<int:registro_id>/',
        guardar
    ),

    # ELIMINAR
    path(
        'admin/<str:tabla>/<int:registro_id>/eliminar/',
        guardar
    ),

]
