import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../api/api";

import imagenCurso from "../utils/imagenCurso";

function CursosInicio() {
    const [cursos, setCursos] = useState([]);
    const [estado, setEstado] = useState("cargando");
    const [intento, setIntento] = useState(0);

    useEffect(() => {
        const controller = new AbortController();
        setEstado("cargando");
        API.get("cursos-completos/", { signal: controller.signal })
            .then(({ data }) => {
                if (controller.signal.aborted) return;
                // La API devuelve una fila por horario; mostrar una tarjeta por curso.
                setCursos([...new Map(data.map(curso => [curso.id_curso, curso])).values()]);
                setEstado("listo");
            })
            .catch(() => {
                if (!controller.signal.aborted) setEstado("error");
            });
        return () => controller.abort();
    }, [intento]);

    if (estado === "cargando") return <p role="status">Cargando cursos…</p>;
    if (estado === "error") return (
        <div role="alert">
            <p>No se pudieron cargar los cursos.</p>
            <button className="btn btn-outline-dark" onClick={() => setIntento(valor => valor + 1)}>Reintentar</button>
        </div>
    );
    if (!cursos.length) return <p>No hay cursos disponibles por el momento.</p>;

    return (
        <div className="row g-4">
            {cursos.map(curso => (
                <div className="col-md-4" key={curso.id_curso}>
                    <article className="card border-0 shadow h-100" style={{ borderRadius: "18px", overflow: "hidden" }}>
                        <img
                            src={imagenCurso(curso.nombre_curso)}
                            alt={`Ilustración del curso ${curso.nombre_curso}`}
                            className="card-img-top"
                            loading="lazy"
                            width="640"
                            height="360"
                            style={{ height: "200px", objectFit: "cover" }}
                        />
                        <div className="card-body p-4">
                            {curso.nivel && <span className="badge bg-dark mb-2">{curso.nivel}</span>}
                            <h4 className="fw-bold">{curso.nombre_curso}</h4>
                            <p className="text-muted">{curso.descripcion || "Consulta la información de este curso."}</p>
                            <Link className="btn btn-dark rounded-pill stretched-link" to={`/cursos/${curso.id_curso}`}
                                aria-label={`Ver curso: ${curso.nombre_curso}`}>Ver curso →</Link>
                        </div>
                    </article>
                </div>
            ))}
        </div>
    );
}

export default CursosInicio;
