import json
from decimal import Decimal
from django.contrib.auth.hashers import make_password
from django.core.exceptions import ValidationError
from django.db import IntegrityError, models, transaction
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_http_methods
from . import models as m
from .acceso import requiere_rol


TABLAS = {
    'certificaciones': m.Certificaciones, 'entidades': m.EntidadesCertificadoras,
    'usuarios': m.Usuarios, 'alumnos': m.Alumnos, 'docentes': m.Docentes,
    'padres': m.Usuarios, 'familias': m.PadreAlumno, 'cursos': m.Cursos,
    'grupos': m.Grupos, 'horarios': m.Horarios, 'inscripciones': m.Inscripciones,
    'pagos': m.Pagos, 'asistencias': m.Asistencias, 'evaluaciones': m.Evaluaciones,
    'calificaciones': m.Calificaciones, 'periodos': m.Periodos, 'aulas': m.Aulas,
    'dias': m.Dias, 'roles': m.Roles,
}
TITULOS = {'padres': 'Padres de familia', 'familias': 'Padres y alumnos', 'dias': 'Días', 'inscripciones': 'Inscripciones', 'calificaciones': 'Calificaciones'}
ETIQUETAS = {
    'id_usuario': 'Cuenta de acceso', 'id_rol': 'Rol', 'id_alumno': 'Alumno',
    'id_docente': 'Docente', 'id_curso': 'Curso', 'id_grupo': 'Grupo',
    'id_periodo': 'Periodo', 'id_inscripcion': 'Inscripción', 'id_evaluacion': 'Evaluación',
    'id_dia': 'Día', 'id_aula': 'Aula', 'password_hash': 'Contraseña',
    'nombre_usuario': 'Nombre completo', 'email': 'Correo electrónico',
    'padre': 'Padre de familia', 'alumno': 'Alumno', 'matricula': 'Matrícula',
    'calificacion': 'Calificación', 'descripcion': 'Descripción',
}
OPCIONES = {
    'sexo': ['Femenino', 'Masculino', 'Otro'],
    'nivel': ['Inicial', 'Básico', 'Intermedio', 'Avanzado'],
    'metodo_pago': ['Efectivo', 'Transferencia', 'Tarjeta', 'Depósito'],
    'moneda': ['MXN', 'USD'], 'tipo_evaluacion': ['Examen', 'Tarea', 'Proyecto', 'Participación'],
    'parentesco': ['Padre', 'Madre', 'Tutor'],
}
AUTOMATICOS = {'fecha_creacion', 'fecha_registro', 'created_at'}


def etiqueta(campo):
    return ETIQUETAS.get(campo, campo.replace('_', ' ').capitalize())


def registros(tabla):
    qs = TABLAS[tabla].objects.all()
    if tabla == 'padres':
        qs = qs.filter(id_rol__nombre_rol='Padre')
    return qs.order_by(TABLAS[tabla]._meta.pk.name)


def datos_registro(obj):
    return {f.name: getattr(obj, f.attname) for f in obj._meta.fields if f.name != 'password_hash'}


def campos(modelo, tabla):
    resultado = []
    for f in modelo._meta.fields:
        if f.primary_key or f.name in AUTOMATICOS or (tabla == 'padres' and f.name == 'id_rol'):
            continue
        campo = {'nombre': f.name, 'etiqueta': etiqueta(f.name), 'requerido': not f.blank and not f.null, 'tipo': 'text'}
        if f.is_relation:
            campo['relacion'] = 'padres' if f.name == 'padre' else next(k for k, v in TABLAS.items() if v == f.related_model)
            campo['tipo'] = 'select'
        elif isinstance(f, models.DateTimeField):
            campo['tipo'] = 'datetime-local'
        elif isinstance(f, models.DateField):
            campo['tipo'] = 'date'
        elif isinstance(f, models.TimeField):
            campo['tipo'] = 'time'
        elif isinstance(f, (models.IntegerField, models.DecimalField)):
            campo['tipo'] = 'number'
            campo['paso'] = str(10 ** -f.decimal_places) if isinstance(f, models.DecimalField) else '1'
        elif isinstance(f, models.TextField):
            campo['tipo'] = 'textarea'
        if f.name == 'estado':
            campo['tipo'] = 'select'
            campo['opciones'] = ([{'valor': x, 'texto': x} for x in ['Presente', 'Ausente', 'Justificada', 'Retardo']]
                                 if tabla == 'asistencias' else [{'valor': 1, 'texto': 'Activo'}, {'valor': 0, 'texto': 'Inactivo'}])
        elif f.name in OPCIONES:
            campo['tipo'] = 'select'
            campo['opciones'] = [{'valor': x, 'texto': x} for x in OPCIONES[f.name]]
        elif f.name in ('email', 'correo'):
            campo['tipo'] = 'email'
        elif f.name == 'password_hash':
            campo['tipo'] = 'password'
        if f.max_length:
            campo['maxLength'] = f.max_length
        resultado.append(campo)
    if tabla == 'calificaciones':
        resultado.sort(key=lambda c: {'id_inscripcion': 0, 'id_evaluacion': 1}.get(c['nombre'], 2))
    return resultado


@require_GET
@requiere_rol('Administrador')
def catalogo(request):
    return JsonResponse({'resumen_pagos': resumen_pagos(), 'tablas': {tabla: {
        'titulo': TITULOS.get(tabla, tabla.capitalize()), 'pk': modelo._meta.pk.name,
        'campos': campos(modelo, tabla), 'registros': [datos_registro(obj) for obj in registros(tabla)],
    } for tabla, modelo in TABLAS.items()}})


def resumen_pagos():
    resultado = []
    for inscripcion in m.Inscripciones.objects.filter(estado=1).select_related('id_alumno', 'id_grupo__id_curso'):
        costo = inscripcion.id_grupo.id_curso.costo
        pagos = list(m.Pagos.objects.filter(id_inscripcion=inscripcion, estado=1))
        total = sum((p.monto for p in pagos if p.moneda == 'MXN'), Decimal('0'))
        revisar = costo is None or costo < 0 or any(p.moneda != 'MXN' or p.monto < 0 for p in pagos)
        saldo = None if revisar else max(costo - total, Decimal('0'))
        resultado.append({'id_inscripcion': inscripcion.pk,
            'alumno': ' '.join(filter(None, [inscripcion.id_alumno.nombre, inscripcion.id_alumno.apellido_paterno, inscripcion.id_alumno.apellido_materno])),
            'curso': inscripcion.id_grupo.id_curso.nombre_curso, 'grupo': inscripcion.id_grupo.nombre_grupo,
            'costo': costo, 'pagado': total, 'saldo': saldo,
            'situacion': 'Por revisar' if revisar else 'Completo' if saldo == 0 else 'Incompleto'})
    return resultado


def validar_relaciones(obj):
    for modelo, campo, maximo in [(m.Calificaciones, 'calificacion', 100), (m.Evaluaciones, 'porcentaje', 100), (m.Pagos, 'monto', None)]:
        if isinstance(obj, modelo):
            valor = getattr(obj, campo)
            if valor is not None and (not valor.is_finite() or valor < 0 or (maximo is not None and valor > maximo)):
                raise ValidationError({campo: 'Ingresa un valor válido mayor o igual a cero' + (' y menor o igual a 100.' if maximo else '.')})
    if isinstance(obj, m.Asistencias):
        if obj.estado not in ('Presente', 'Ausente', 'Justificada', 'Retardo'):
            raise ValidationError({'estado': 'Selecciona un estado de asistencia válido.'})
        if m.Asistencias.objects.filter(id_inscripcion=obj.id_inscripcion, fecha=obj.fecha).exclude(pk=obj.pk).exists():
            raise ValidationError({'fecha': 'Ya existe una asistencia para ese alumno y fecha.'})
    if isinstance(obj, m.Pagos) and obj.moneda not in ('MXN', 'USD'):
        raise ValidationError({'moneda': 'Selecciona MXN o USD.'})
    if isinstance(obj, (m.Alumnos, m.Docentes)) and obj.id_usuario_id:
        rol = 'Alumno' if isinstance(obj, m.Alumnos) else 'Docente'
        nombre_rol = obj.id_usuario.id_rol.nombre_rol.strip().casefold()
        rol_correcto = nombre_rol in {'alumno', 'alumnos'} if rol == 'Alumno' else nombre_rol == rol.casefold()
        if not rol_correcto:
            raise ValidationError({'id_usuario': f'Selecciona una cuenta con rol {rol}.'})
    if isinstance(obj, m.PadreAlumno) and obj.padre.id_rol.nombre_rol != 'Padre':
        raise ValidationError({'padre': 'Selecciona una cuenta de padre de familia.'})
    if isinstance(obj, m.Usuarios) and obj.pk:
        nombre_rol = obj.id_rol.nombre_rol.strip().casefold()
        es_alumno = nombre_rol in {'alumno', 'alumnos'}
        if m.Alumnos.objects.filter(id_usuario=obj).exists() and not es_alumno:
            raise ValidationError({'id_rol': 'Esta cuenta está vinculada a un alumno.'})
        if m.Docentes.objects.filter(id_usuario=obj).exists() and obj.id_rol.nombre_rol != 'Docente':
            raise ValidationError({'id_rol': 'Esta cuenta está vinculada a un docente.'})
        if m.PadreAlumno.objects.filter(padre=obj).exists() and obj.id_rol.nombre_rol != 'Padre':
            raise ValidationError({'id_rol': 'Esta cuenta tiene alumnos vinculados como padre.'})
    if isinstance(obj, m.Calificaciones):
        if obj.id_evaluacion.id_grupo_id != obj.id_inscripcion.id_grupo_id:
            raise ValidationError({'id_evaluacion': 'La evaluación debe pertenecer al grupo de la inscripción del alumno.'})
        if m.Calificaciones.objects.filter(id_evaluacion=obj.id_evaluacion, id_inscripcion=obj.id_inscripcion).exclude(pk=obj.pk).exists():
            raise ValidationError({'id_evaluacion': 'Este alumno ya tiene calificación para esa evaluación.'})
    if isinstance(obj, m.Inscripciones) and obj.estado == 1:
        if m.Inscripciones.objects.filter(id_alumno=obj.id_alumno, id_grupo=obj.id_grupo, estado=1).exclude(pk=obj.pk).exists():
            raise ValidationError({'id_alumno': 'El alumno ya está inscrito en este grupo.'})
    if isinstance(obj, m.Horarios):
        if obj.hora_fin <= obj.hora_inicio:
            raise ValidationError({'hora_fin': 'La hora final debe ser posterior a la inicial.'})
        if obj.estado == 1:
            # Serializar altas del mismo día para que dos envíos no eludan la validación.
            m.Dias.objects.select_for_update().get(pk=obj.id_dia_id)
            if m.Horarios.objects.filter(id_grupo=obj.id_grupo, id_dia=obj.id_dia,
                    hora_inicio=obj.hora_inicio, hora_fin=obj.hora_fin, estado=1).exclude(pk=obj.pk).exists():
                raise ValidationError({'hora_inicio': 'Este grupo ya tiene registrado ese día y horario.'})
            cruces = m.Horarios.objects.filter(id_dia=obj.id_dia, estado=1, hora_inicio__lt=obj.hora_fin, hora_fin__gt=obj.hora_inicio,
                id_grupo__id_periodo__fecha_inicio__lte=obj.id_grupo.id_periodo.fecha_fin,
                id_grupo__id_periodo__fecha_fin__gte=obj.id_grupo.id_periodo.fecha_inicio).exclude(pk=obj.pk)
            if cruces.filter(models.Q(id_grupo=obj.id_grupo) | models.Q(id_aula=obj.id_aula) | models.Q(id_grupo__id_docente=obj.id_grupo.id_docente)).exists():
                raise ValidationError({'hora_inicio': 'El grupo, docente o aula ya tiene un horario que se cruza.'})
    if isinstance(obj, m.Grupos) and obj.pk:
        for horario in m.Horarios.objects.filter(id_grupo=obj, estado=1):
            if m.Horarios.objects.filter(id_grupo__id_docente=obj.id_docente, estado=1, id_dia=horario.id_dia,
                    hora_inicio__lt=horario.hora_fin, hora_fin__gt=horario.hora_inicio,
                    id_grupo__id_periodo__fecha_inicio__lte=obj.id_periodo.fecha_fin,
                    id_grupo__id_periodo__fecha_fin__gte=obj.id_periodo.fecha_inicio).exclude(id_grupo=obj).exists():
                raise ValidationError({'id_docente': 'El docente tiene un horario que se cruza con este grupo.'})
    if isinstance(obj, m.Periodos) and obj.fecha_fin < obj.fecha_inicio:
        raise ValidationError({'fecha_fin': 'La fecha final debe ser posterior o igual a la inicial.'})
    if isinstance(obj, m.Evaluaciones) and obj.pk:
        if m.Calificaciones.objects.filter(id_evaluacion=obj).exclude(id_inscripcion__id_grupo_id=obj.id_grupo_id).exists():
            raise ValidationError({'id_grupo': 'Hay calificaciones vinculadas al grupo anterior.'})
    if isinstance(obj, m.Inscripciones) and obj.pk:
        if m.Calificaciones.objects.filter(id_inscripcion=obj).exclude(id_evaluacion__id_grupo_id=obj.id_grupo_id).exists():
            raise ValidationError({'id_grupo': 'Hay calificaciones de evaluaciones del grupo anterior.'})


@csrf_exempt
@require_http_methods(['POST', 'PUT', 'DELETE'])
@requiere_rol('Administrador')
def guardar(request, tabla, registro_id=None):
    if tabla not in TABLAS:
        return JsonResponse({'mensaje': 'Tabla no disponible.'}, status=404)
    if (request.method == 'POST') != (registro_id is None):
        return JsonResponse({'mensaje': 'Operación no válida para esta dirección.'}, status=405)
    modelo = TABLAS[tabla]
    obj = get_object_or_404(registros(tabla), pk=registro_id) if registro_id else modelo()
    try:
        with transaction.atomic():
            if request.method == 'DELETE':
                if not registro_id:
                    return JsonResponse({'mensaje': 'Selecciona un registro.'}, status=400)
                if isinstance(obj, m.Usuarios) and obj.pk == request.usuario_panel.pk:
                    raise ValidationError('No puedes eliminar tu propia cuenta.')
                obj.delete()
            else:
                datos = json.loads(request.body)
                if not isinstance(datos, dict):
                    raise ValidationError('El formulario no es válido.')
                for campo in campos(modelo, tabla):
                    nombre = campo['nombre']
                    if nombre not in datos:
                        continue
                    f = modelo._meta.get_field(nombre)
                    valor = datos[nombre]
                    if nombre == 'password_hash':
                        if not valor and registro_id:
                            continue
                        if not valor:
                            raise ValidationError({'password_hash': 'Ingresa una contraseña.'})
                        valor = make_password(valor)
                    if valor == '' and f.null:
                        valor = None
                    if f.is_relation:
                        setattr(obj, f.attname, valor)
                    else:
                        setattr(obj, nombre, f.to_python(valor))
                if tabla == 'padres':
                    obj.id_rol = m.Roles.objects.get(nombre_rol='Padre')
                if not registro_id:
                    for f in modelo._meta.fields:
                        if f.name in AUTOMATICOS:
                            setattr(obj, f.name, timezone.now())
                if isinstance(obj, m.Usuarios) and obj.pk == request.usuario_panel.pk and (obj.estado != 1 or obj.id_rol.nombre_rol != 'Administrador'):
                    raise ValidationError('No puedes desactivar ni cambiar el rol de tu propia cuenta.')
                obj.full_clean()
                validar_relaciones(obj)
                obj.save()
        return JsonResponse({'mensaje': 'Registro eliminado.' if request.method == 'DELETE' else 'Cambios guardados.', 'id': obj.pk})
    except ValidationError as error:
        return JsonResponse({'mensaje': 'Revisa los campos del formulario.', 'errores': error.message_dict if hasattr(error, 'message_dict') else {'formulario': error.messages}}, status=400)
    except IntegrityError:
        return JsonResponse({'mensaje': 'Hay datos duplicados o registros relacionados. Revisa las relaciones; puedes desactivar el registro si necesitas conservar su historial.'}, status=400)
    except (ValueError, TypeError):
        return JsonResponse({'mensaje': 'Revisa el formato de los datos.'}, status=400)
