import { columnasAlumno, valorAlumno, fechaTabla, horaTabla } from "./alumnoTablas";
import PiePagina from "../componentes/PiePagina";
import ConstanciasAlumno from "../componentes/ConstanciasAlumno";
import DescargarFichaAlumno from "../componentes/DescargarFichaAlumno";
import PuntajesAlumno from "../componentes/PuntajesAlumno";
import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams, useLocation } from "react-router-dom";
import API from "../api/api";
import imagenCurso from "../utils/imagenCurso";
import "./Alumno.css";
import { notificarCambiosDocente as notificarAdministrador } from "../api/cambiosDocente";

const dato = valor => valor === null || valor === undefined || valor === "" ? "Por confirmar" : valor;

function InscripcionCurso({ curso, inscribiendo, onInscribir }) {
    const [grupoId, setGrupoId] = useState("");
    const [errorGrupo, setErrorGrupo] = useState("");
    const disponibles = curso.grupos.filter(g => !g.inscrito && g.lugares !== 0);
    const grupo = disponibles.find(g => String(g.id) === grupoId) || (disponibles.length === 1 ? disponibles[0] : null);
    return <div className="border-top pt-3 mt-3">
        {!!disponibles.length && <>
            <label htmlFor={`grupo-curso-${curso.id}`} className="form-label fw-semibold">Selecciona tu grupo</label>
            <select id={`grupo-curso-${curso.id}`} className="form-select mb-2" value={grupo ? String(grupo.id) : ""} disabled={inscribiendo !== null} onChange={e => { setGrupoId(e.target.value); setErrorGrupo(""); }}>
                <option value="">Selecciona un grupo</option>
                {disponibles.map(g => <option key={g.id} value={g.id}>{g.nombre} · {g.periodo} · {g.docente}</option>)}
            </select>
            {grupo && <div className="small mb-3">
                <p className="mb-1">Docente: {grupo.docente}</p>
                {grupo.horarios.length ? <ul className="mb-1">{grupo.horarios.map((h, i) => <li key={i}>{h.dia} {horaTabla(h.inicio)}–{horaTabla(h.fin)} · Aula: {dato(h.aula)}</li>)}</ul> : <p>Horario por asignar.</p>}
                {grupo.lugares !== null && <p className="mb-1">Lugares disponibles: {grupo.lugares}</p>}
            </div>}
        </>}
        {!disponibles.length && <p className="small">{curso.grupos.some(g => g.inscrito) ? "Ya tienes una inscripción en este curso. No hay otros grupos con cupo." : "Por el momento no hay grupos con cupo para inscribirte."}</p>}
        {errorGrupo && <p role="alert" className="text-danger">{errorGrupo}</p>}
        <button type="button" className="btn btn-success w-100" disabled={!disponibles.length || inscribiendo !== null} onClick={() => {
            if (!grupo) {
                setErrorGrupo("Selecciona el grupo en el que deseas inscribirte.");
                document.getElementById(`grupo-curso-${curso.id}`)?.focus();
                return;
            }
            onInscribir(grupo);
        }}>
            {grupo && inscribiendo === grupo.id ? "Guardando inscripción…" : "Inscribirme"}
        </button>
    </div>;
}

function Alumno({ familia = false }) {
    const tokenClave = familia ? "token_panel" : "token_alumno";
    const apiRol = familia ? "padre" : "alumno";
    const navigate = useNavigate();
    const location = useLocation();
    const { idCurso } = useParams();
    const [datos, setDatos] = useState(null);
    const [seleccion, setSeleccion] = useState(location.state?.inscripcionExitosa ?? null);
    const [estado, setEstado] = useState("cargando");
    const [mensaje, setMensaje] = useState("");
    const [intento, setIntento] = useState(0);
    const [archivoActivo, setArchivoActivo] = useState(null);
    const [vista, setVista] = useState(null);
    const urls = useRef(new Set());
    const [verCatalogo, setVerCatalogo] = useState(false);
    const [inscribiendo, setInscribiendo] = useState(null);
    const [avisoInscripcion, setAvisoInscripcion] = useState("");
    const [inscripcionExitosa, setInscripcionExitosa] = useState(Boolean(location.state?.inscripcionExitosa));

    const inscribirme = async grupo => {
        if (inscribiendo !== null) return;
        setInscribiendo(grupo.id);
        setAvisoInscripcion("");
        setInscripcionExitosa(false);
        try {
            const { data } = await API.post("alumno/inscribirme/", { id_grupo: grupo.id }, {
                headers: { Authorization: `Bearer ${sessionStorage.getItem(tokenClave)}` },
            });
            notificarAdministrador();
            cerrarVista();
            setVerCatalogo(false);
            setInscripcionExitosa(true);
            navigate("/alumno", { replace: true, state: { inscripcionExitosa: data.id_inscripcion } });
            setSeleccion(data.id_inscripcion);
            setAvisoInscripcion("");
            setIntento(i => i + 1);
        } catch (error) {
            if (error.response?.status === 401) navigate("/login", { replace: true });
            setAvisoInscripcion(error.response?.data?.mensaje || "No se pudo completar la inscripción. Intenta nuevamente.");
        } finally { setInscribiendo(null); }
    };

    useEffect(() => {
        const creadas = urls.current;
        return () => creadas.forEach(url => URL.revokeObjectURL(url));
    }, []);

    useEffect(() => {
        const token = sessionStorage.getItem(tokenClave);
        if (!token) { navigate("/login", { replace: true }); return; }
        const controller = new AbortController();
        setEstado("cargando");
        let pendiente = false;
        const cargar = () => {
        if (pendiente) return;
        pendiente = true;
        API.get(`${apiRol}/mis-cursos/`, { signal: controller.signal, headers: { Authorization: `Bearer ${token}` } })
            .then(({ data }) => {
                if (controller.signal.aborted) return;
                setDatos(data);
                setSeleccion(actual => data.cursos.some(c => c.id_inscripcion === actual) ? actual : data.cursos[0]?.id_inscripcion ?? null);
                setEstado("listo");
            })
            .catch(error => {
                if (controller.signal.aborted) return;
                if (error.response?.status === 401) {
                    sessionStorage.removeItem(tokenClave);
                    navigate("/login", { replace: true });
                    return;
                }
                setMensaje(error.response?.data?.mensaje || "No se pudieron cargar tus cursos. Intenta nuevamente.");
                setEstado("error");
            }).finally(() => { pendiente = false; });
        };
        cargar();
        const intervalo = setInterval(cargar, 15000);
        window.addEventListener("focus", cargar);
        return () => { controller.abort(); clearInterval(intervalo); window.removeEventListener("focus", cargar); };
    }, [intento, navigate, tokenClave, apiRol]);

    const cerrarVista = () => {
        if (vista) { URL.revokeObjectURL(vista.url); urls.current.delete(vista.url); }
        setVista(null);
    };

    const abrirArchivo = async (material, consultar) => {
        setArchivoActivo(material.id);
        setMensaje("");
        cerrarVista();
        try {
            const { data } = await API.get(`${apiRol}/materiales/${material.id}/archivo/`, {
                params: consultar ? { ver: 1 } : {}, responseType: "blob",
                headers: { Authorization: `Bearer ${sessionStorage.getItem(tokenClave)}` },
            });
            const url = URL.createObjectURL(data);
            urls.current.add(url);
            const tipo = data.type.split(";")[0];
            if (consultar && ["application/pdf", "text/plain", "image/png", "image/jpeg", "audio/mpeg", "video/mp4"].includes(tipo)) {
                setVista({ url, tipo, titulo: material.titulo });
            } else {
                const enlace = document.createElement("a");
                enlace.href = url;
                enlace.download = material.archivo;
                document.body.appendChild(enlace);
                enlace.click();
                enlace.remove();
                setTimeout(() => { URL.revokeObjectURL(url); urls.current.delete(url); }, 1000);
                if (consultar) setMensaje("Este formato se descarga para abrirlo en tu dispositivo.");
            }
        } catch (error) {
            if (error.response?.status === 401) {
                sessionStorage.removeItem(tokenClave);
                navigate("/login", { replace: true });
            } else {
                setMensaje("No se pudo abrir el archivo. Puede que ya no esté disponible o que tu inscripción haya cambiado.");
            }
        } finally { setArchivoActivo(null); }
    };

    const mostrarCatalogo = !familia && (!!idCurso || !datos?.cursos.length || verCatalogo);
    const curso = datos?.cursos.find(item => item.id_inscripcion === seleccion);

    return (
        <div className={`montreal-con-pie ${familia ? "" : "pagina-alumno"}`} style={familia ? { minHeight: "100vh", background: "#f5f5f5" } : undefined}>
            <header className="bg-dark text-white py-4">
                <div className="container d-flex flex-wrap align-items-center justify-content-between gap-3">
                    <div className="d-flex align-items-center gap-3">
                        <img src={`${process.env.PUBLIC_URL}/montreal.jpeg`} alt="Institución Montreal" width="60" height="60" className="rounded bg-white" style={{ objectFit: "contain" }} />
                        <div><h1 className="h4 mb-0">{familia ? "Panel de padres de familia" : "Mi espacio de aprendizaje"}</h1><small>Institución Montreal</small></div>
                    </div>
                    <div className="d-flex gap-2">
                        <Link to="/" className="btn btn-outline-light">Inicio</Link>
                        <button className="btn btn-light" onClick={() => {
                            sessionStorage.removeItem("token_alumno"); sessionStorage.removeItem("token_panel"); localStorage.removeItem("usuario"); navigate("/login", { replace: true });
                        }}>Cerrar sesión</button>
                    </div>
                </div>
            </header>
            <main className="container py-4">
                {inscripcionExitosa && <div className="alert alert-success" role="status">
                    <strong>Inscripción exitosa.</strong> Tu inscripción quedó guardada. Aquí puedes consultar tu curso y tu información académica.
                </div>}
                {estado === "cargando" && <p role="status">Cargando tus cursos y horarios…</p>}
                {estado === "error" && <div role="alert" className="alert alert-danger"><p>{mensaje}</p><button className="btn btn-dark" onClick={() => setIntento(i => i + 1)}>Reintentar</button></div>}
                {estado === "listo" && <>
                    <h2 className="h3">Hola, {datos.alumno.nombre}</h2>
                    {!familia && !mostrarCatalogo && !!datos.cursos.length && <p>Este es tu espacio personal: consulta tus cursos inscritos, calificaciones, docente, grupo, periodo, horarios y aula.</p>}
                    <p className="text-muted">{familia ? "Consulta la información de tus alumnos vinculados." : `Matrícula: ${datos.alumno.matricula}`} · Actualización cada 15 segundos.</p>
                    {avisoInscripcion && <p className="alert alert-info" role="status">{avisoInscripcion}</p>}
                    {!familia && !idCurso && !!datos.cursos.length && <nav className="d-flex gap-2 my-3" aria-label="Cursos del alumno">
                        <button className={`btn ${!verCatalogo ? "btn-success" : "btn-outline-success"}`} aria-pressed={!verCatalogo} onClick={() => setVerCatalogo(false)}>Mis cursos</button>
                        <button className={`btn ${verCatalogo ? "btn-success" : "btn-outline-success"}`} aria-pressed={verCatalogo} onClick={() => setVerCatalogo(true)}>Explorar otros cursos</button>
                    </nav>}
                    {familia && !datos.cursos.length && <p>No hay inscripciones activas de alumnos vinculados a tu cuenta.</p>}
                    {mostrarCatalogo && <section className="my-4" aria-labelledby="catalogo-alumno">
                        {idCurso && <Link to="/alumno" onClick={() => setVerCatalogo(true)} className="btn btn-outline-success mb-3">Volver a los cursos</Link>}
                        {idCurso && !datos.disponibles?.some(item => String(item.id) === idCurso) && <p role="status">Este curso ya no está disponible.</p>}
                        <h3 id="catalogo-alumno" className="h4" style={{ color: "#d9273e" }}>{idCurso ? "Información del curso" : "Cursos disponibles"}</h3>
                        <p>Elige el grupo y revisa sus horarios antes de inscribirte.</p>
                        {!datos.disponibles?.length && <p>No hay cursos disponibles por el momento.</p>}
                        <div className="row g-3">
                            {(datos.disponibles || []).filter(item => !idCurso || String(item.id) === idCurso).map(item => <article className={idCurso ? "col-12" : "col-md-6"} key={item.id}>
                                <div className="card h-100 p-3" style={{ background: "#f0f5e9", borderColor: "#cbdccb" }}>
                                    {idCurso ? <>
                                        <img src={imagenCurso(item.nombre)} alt={item.nombre} className="rounded mb-3" style={{ width: "100%", maxHeight: 300, objectFit: "cover" }} />
                                        <h4 className="h3" style={{ color: "#d9273e" }}>{item.nombre}</h4>
                                        <h5 className="h5 mt-3">Descripción del curso</h5>
                                        <p style={{ whiteSpace: "pre-wrap" }}>{item.descripcion || "Descripción por confirmar."}</p>
                                        <dl className="row mt-3 mb-4">
                                            <div className="col-sm-4"><dt>Duración</dt><dd>{item.duracion_horas != null ? `${item.duracion_horas} horas` : "Por confirmar"}</dd></div>
                                            <div className="col-sm-4"><dt>Costo</dt><dd>{item.costo != null && item.costo !== "" ? `$${Number(item.costo).toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "Por confirmar"}</dd></div>
                                            <div className="col-sm-4"><dt>Nivel</dt><dd>{dato(item.nivel)}</dd></div>
                                        </dl>
                                    </> : <Link to={`/alumno/cursos/${item.id}`} className="text-decoration-none text-dark d-block h-100" aria-label={`Ver información de ${item.nombre}`}>
                                        <img src={imagenCurso(item.nombre)} alt="" className="rounded mb-3" style={{ width: "100%", height: 150, objectFit: "cover" }} />
                                        <h4 className="h5" style={{ color: "#d9273e" }}>{item.nombre}</h4>
                                        <p>{item.descripcion}</p>
                                        <span className="text-success text-decoration-underline">Ver información del curso</span>
                                    </Link>}
                                    {!idCurso && <InscripcionCurso curso={item} inscribiendo={inscribiendo} onInscribir={inscribirme} />}
                                    {idCurso && <>
                                    <h4 className="h4 mt-3" style={{ color: "#d9273e" }}>Grupos y horarios</h4>
                                    {!item.grupos.length && <p>Sin grupos abiertos para inscripción.</p>}
                                    {item.grupos.map(grupo => <div key={grupo.id} className="border-top pt-3 mt-2">
                                        <h5 className="h6">Grupo: {grupo.nombre}</h5>
                                        <p className="mb-1">Docente: {grupo.docente}</p>
                                        <p className="mb-1">Periodo: {grupo.periodo} | {grupo.inicio} - {grupo.fin}</p>
                                        {grupo.horarios.length ? <div className="table-responsive">
                                            <table className="table">
                                                <caption>Horarios de {grupo.nombre}</caption>
                                                <thead><tr>{["Día", "Inicio", "Fin", "Aula", "Ubicación"].map(titulo => <th scope="col" key={titulo}>{titulo}</th>)}</tr></thead>
                                                <tbody>{grupo.horarios.map((h, i) => <tr key={i}>
                                                    <td>{dato(h.dia)}</td><td>{dato(h.inicio?.slice(0, 5))}</td><td>{dato(h.fin?.slice(0, 5))}</td><td>{dato(h.aula)}</td><td>{dato(h.ubicacion)}</td>
                                                </tr>)}</tbody>
                                            </table>
                                        </div> : <p>Horario y aula por asignar.</p>}
                                        {grupo.lugares !== null && <p>Lugares disponibles: {grupo.lugares}</p>}
                                        <button type="button" className="btn btn-success" disabled={inscribiendo !== null || grupo.inscrito || grupo.lugares === 0} onClick={() => inscribirme(grupo)}>
                                            {grupo.inscrito ? "Ya est\u00e1s inscrito" : inscribiendo === grupo.id ? "Inscribiendo..." : grupo.lugares === 0 ? "Sin cupo" : "Inscribirme"}
                                        </button>
                                    </div>)}
                                    </>}
                                </div>
                            </article>)}
                        </div>
                    </section>}
                    <div className="row g-4" hidden={mostrarCatalogo} style={mostrarCatalogo ? { display: "none" } : undefined}>
                        {!!datos.cursos.length && <aside className="col-lg-4" aria-label="Mis cursos">
                            <h3 className="h5">{familia ? "Cursos de mis alumnos" : "Mis cursos"}</h3>
                            {datos.cursos.map(item => <button key={item.id_inscripcion}
                                className={`btn w-100 text-start p-3 mb-2 ${seleccion === item.id_inscripcion ? "btn-dark" : "btn-outline-dark"}`}
                                aria-pressed={seleccion === item.id_inscripcion} disabled={archivoActivo !== null}
                                onClick={() => { setSeleccion(item.id_inscripcion); cerrarVista(); setMensaje(""); }}>
                                <strong className="d-block">{item.nombre_curso}</strong>{item.alumno_nombre && <span className="d-block">{item.alumno_nombre}</span>}<small>Grupo: {item.grupo}</small>
                            </button>)}
                        </aside>}
                        {curso && <div className="col-lg-8">
                            <article className="card border-0 shadow-sm p-4 mb-4">
                                <img src={imagenCurso(curso.nombre_curso)} alt={`Ilustración de ${curso.nombre_curso}`} className="rounded mb-3" style={{ width: "100%", maxHeight: "240px", objectFit: "cover" }} />
                                <h2 className="h3">{curso.nombre_curso}</h2>
                                <p style={{ whiteSpace: "pre-wrap" }}>{dato(curso.descripcion)}</p>
                                <dl className="row mb-0">
                                    <div className="col-sm-6"><dt>Grupo</dt><dd>{curso.grupo}</dd></div>
                                    <div className="col-sm-6"><dt>Docente</dt><dd>{dato(curso.docente)}</dd></div>
                                    <div className="col-sm-6"><dt>Nivel</dt><dd>{dato(curso.nivel)}</dd></div>
                                    <div className="col-sm-6"><dt>Duración</dt><dd>{curso.duracion_horas != null ? `${curso.duracion_horas} horas` : "Por confirmar"}</dd></div>
                                    <div className="col-12"><dt>Periodo</dt><dd>{dato(curso.periodo)} · {fechaTabla(curso.fecha_inicio)} — {fechaTabla(curso.fecha_fin)}</dd></div>
                                </dl>
                            </article>
                            <section className="card border-0 shadow-sm p-4 mb-4" aria-labelledby="mis-horarios">
                                <h3 id="mis-horarios" className="h4">Mis horarios</h3>
                                {!curso.horarios.length ? <p>Tu grupo todavía no tiene horarios asignados.</p> : <div className="table-responsive"><table className="table">
                                    <caption>Horarios del grupo {curso.grupo}</caption>
                                    <thead><tr>{["Día", "Inicio", "Fin", "Aula", "Ubicación"].map(titulo => <th key={titulo} scope="col">{titulo}</th>)}</tr></thead>
                                    <tbody>{curso.horarios.map(h => <tr key={h.id}><td>{h.dia}</td><td>{horaTabla(h.inicio)}</td><td>{horaTabla(h.fin)}</td><td>{dato(h.aula)}</td><td>{dato(h.ubicacion)}</td></tr>)}</tbody>
                                </table></div>}
                            </section>
                            {!familia && <PuntajesAlumno curso={curso} />}
                            {[
                                ["Calificaciones", curso.calificaciones], ["Evaluaciones", curso.evaluaciones],
                                ["Asistencias", curso.asistencias], ["Pagos", curso.pagos],
                            ].map(([titulo, filas]) => <section className="card border-0 shadow-sm p-4 mb-4" key={titulo}>
                                <h3 className="h4">{titulo}</h3>
                                {!Array.isArray(filas) || !filas.length ? <p>No hay registros publicados.</p> : <div className="table-responsive"><table className="table">
                                    <caption>{titulo} del grupo {curso.grupo}</caption>
                                    <thead><tr>{columnasAlumno[titulo].map(([campo, etiqueta]) => <th scope="col" key={campo}>{etiqueta}</th>)}</tr></thead>
                                    <tbody>{filas.map((fila, i) => <tr key={i}>{columnasAlumno[titulo].map(([campo]) => <td key={campo}>{valorAlumno(campo, fila?.[campo], fila || {})}</td>)}</tr>)}</tbody>
                                </table></div>}
                            </section>)}
                            <section className="card border-0 shadow-sm p-4" aria-labelledby="mis-contenidos">
                                <h3 id="mis-contenidos" className="h4">Contenidos y materiales</h3>
                                {!curso.materiales.length && <p>Aún no se han publicado materiales para este curso.</p>}
                                {mensaje && <p role="status" className="alert alert-info">{mensaje}</p>}
                                {curso.materiales.map(material => <article key={material.id} className="border rounded p-3 mb-3">
                                    <h4 className="h5">{material.titulo}</h4>
                                    {material.contenido && <p style={{ whiteSpace: "pre-wrap", overflowWrap: "anywhere" }}>{material.contenido}</p>}
                                    {material.archivo && <><p className="text-muted text-break">{material.archivo}</p><div className="d-flex flex-wrap gap-2">
                                        <button className="btn btn-outline-dark" disabled={archivoActivo !== null} onClick={() => abrirArchivo(material, true)}>Consultar archivo</button>
                                        <button className="btn btn-dark" disabled={archivoActivo !== null} onClick={() => abrirArchivo(material, false)}>Descargar</button>
                                    </div></>}
                                </article>)}
                                {archivoActivo !== null && <p role="status">Cargando archivo…</p>}
                                {vista && <section aria-label="Vista previa del material" className="mt-3">
                                    <div className="d-flex justify-content-between align-items-center gap-2 mb-3"><h4 className="h5 mb-0">{vista.titulo}</h4><button className="btn btn-outline-dark" onClick={cerrarVista}>Cerrar vista</button></div>
                                    {vista.tipo.startsWith("image/") ? <img src={vista.url} alt={vista.titulo} className="img-fluid" /> :
                                        vista.tipo.startsWith("video/") ? <video src={vista.url} controls style={{ width: "100%" }} /> :
                                        vista.tipo.startsWith("audio/") ? <audio src={vista.url} controls style={{ width: "100%" }} /> :
                                        <iframe src={vista.url} title={vista.titulo} style={{ width: "100%", height: "500px", border: "1px solid #ddd" }} />}
                                </section>}
                            </section>
                        </div>}
                    </div>
                </>}
                {!familia && estado === "listo" && !idCurso && <><DescargarFichaAlumno /><ConstanciasAlumno /></>}
            </main>
            <PiePagina />
        </div>
    );
}

export default Alumno;
