const canal = "montreal-cambios-docente";

// Solo se comunica que hay cambios; los datos se consultan con la sesión del administrador.
export function notificarCambiosDocente() {
    if (typeof BroadcastChannel === "undefined") return;
    try {
        const conexion = new BroadcastChannel(canal);
        conexion.postMessage("actualizar");
        conexion.close();
    } catch {
        // La actualización periódica sigue disponible si el navegador bloquea el canal.
    }
}

export function escucharCambiosDocente(actualizar) {
    if (typeof BroadcastChannel === "undefined") return () => {};
    try {
        const conexion = new BroadcastChannel(canal);
        conexion.onmessage = evento => {
            if (evento.data === "actualizar") actualizar();
        };
        return () => conexion.close();
    } catch {
        return () => {};
    }
}
