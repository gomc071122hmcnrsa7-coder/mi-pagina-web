export default function imagenCurso(nombre = "") {
    const tema = (nombre || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const categorias = [
        ["idiomas", /ingles|frances|aleman|italiano|idioma|japones|chino|portugues|espanol/],
        ["tecnologia", /tecnolog|programacion|informatica|computacion|excel|office|software|robotica|digital|web/],
        ["arte", /arte|dibujo|pintura|musica|danza|diseno|fotografia|cultura/],
        ["profesional", /profesional|capacitacion|administracion|negocio|contabilidad|liderazgo|marketing|emprendimiento/],
    ];
    const categoria = categorias.find(([, patron]) => patron.test(tema))?.[0] || "general";
    return `${process.env.PUBLIC_URL}/imagenes/cursos/${categoria}.svg`;
}

