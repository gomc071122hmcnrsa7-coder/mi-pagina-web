# Panel del alumno

- Entrada: `/alumno`; `/cliente` redirige al nuevo panel.
- Iniciar sesión con una cuenta de rol Alumno vinculada a un registro activo de `alumnos`.
- Las inscripciones activas determinan los cursos y grupos visibles. Los horarios pertenecen al grupo inscrito.
- El inicio de sesión entrega un token firmado con vigencia de ocho horas. El servidor obtiene el alumno de ese token, no de un ID enviado desde el navegador. Las sesiones anteriores requieren iniciar sesión nuevamente.

## Materiales

Aplicar la migración con `python manage.py migrate bibliotecaapp`. Crea `materiales_curso`; las tablas existentes están declaradas como no administradas por Django y no se recrean.

En el administrador de Django (`http://localhost:8000/admin/`), entrar con una cuenta de personal de Django y abrir **Materiales de cursos**. Elegir el curso y agregar título, texto y/o archivo; activar **Publicado**. El usuario del panel React de administración es distinto de la cuenta de personal de Django.

Los materiales se comparten entre los grupos del mismo curso. Los archivos se guardan en `Backend/archivos_privados/` y se sirven mediante la API autenticada. No configurar esa carpeta como contenido público del servidor web.

PDF, texto, imágenes, audio MP3 y video MP4 tienen consulta en el navegador. Los formatos de Office y ZIP se descargan para abrirlos en el dispositivo. La disponibilidad de vista previa PDF depende del navegador.

`Contenido1.js` era una interfaz de catálogo e inscripción: no contiene materiales descargables. El panel muestra un estado vacío hasta que se publiquen materiales reales.

## Verificación

Desde la raíz: `venv\Scripts\python.exe Backend/manage.py test bibliotecaapp`.
Desde `Backend/frontend`: `npm run build`.

Las pruebas de acceso del panel cubren tokens inválidos/vencidos, identidad de alumno, inscripción, horarios y entrega de archivos. No sustituyen una auditoría de los endpoints anteriores del sistema.
