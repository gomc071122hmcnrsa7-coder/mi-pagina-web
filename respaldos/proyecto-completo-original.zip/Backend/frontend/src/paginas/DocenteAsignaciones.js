
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../api/api";
import PiePagina from "../componentes/PiePagina";
import ArchivosDocente from "../componentes/ArchivosDocente";
import { notificarCambiosDocente } from "../api/cambiosDocente";
import "./DocenteAsignaciones.css";

export default function DocenteAsignaciones() {
    const navigate = useNavigate();

    const [datos, setDatos] = useState(null);
    const [seccion, setSeccion] = useState("Cursos y grupos");
    const [error, setError] = useState("");
    const [busqueda, setBusqueda] = useState("");
    const [intento, setIntento] = useState(0);
    const [crudDatos, setCrudDatos] = useState([]);
    const [crudOpciones, setCrudOpciones] = useState({});
    const [crudCargando, setCrudCargando] = useState(false);
    const [crudError, setCrudError] = useState("");
    const [crudMensaje, setCrudMensaje] = useState("");
    const [crudFormulario, setCrudFormulario] = useState(null);
    const [crudGuardando, setCrudGuardando] = useState(false);

    const seccionCRUD = ["Alumnos", "Calificaciones", "Asistencias", "Evaluaciones"].includes(seccion);
    const campoIdCRUD = { Alumnos: "id_inscripcion", Calificaciones: "id_calificacion", Asistencias: "id_asistencia", Evaluaciones: "id_evaluacion" }[seccion];
    const slugCRUD = seccion.toLowerCase();

    useEffect(() => {
        const controller = new AbortController();

        const cargar = async () => {
            const token = sessionStorage.getItem("token_panel");

            if (!token) {
                navigate("/login", { replace: true });
                return;
            }

            try {
                const { data } = await API.get("docente/datos/", {
                    signal: controller.signal,
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });

                setDatos(data);
                setError("");

                const nombres = Object.keys(data.secciones || {});

                setSeccion(actual =>
                    nombres.includes(actual)
                        ? actual
                        : nombres[0] || ""
                );

            } catch (e) {
                if (controller.signal.aborted) return;

                if (e.response?.status === 401) {
                    navigate("/login", { replace: true });
                    return;
                }

                setError(
                    e.response?.data?.mensaje ||
                    "No se pudo cargar tu información. Intenta actualizar."
                );
            }
        };

        cargar();

        const intervalo = setInterval(cargar, 15000);
        window.addEventListener("focus", cargar);

        return () => {
            controller.abort();
            clearInterval(intervalo);
            window.removeEventListener("focus", cargar);
        };
    }, [navigate, intento]);

    useEffect(() => {
        if (!seccionCRUD) {
            setCrudFormulario(null);
            return undefined;
        }

        const controller = new AbortController();
        const cargarCRUD = async () => {
            const token = sessionStorage.getItem("token_panel");
            if (!token) {
                navigate("/login", { replace: true });
                return;
            }

            setCrudCargando(true);
            try {
                const { data } = await API.get(`docente/crud/${slugCRUD}/`, {
                    signal: controller.signal,
                    headers: { Authorization: `Bearer ${token}` },
                });
                if (controller.signal.aborted) return;
                setCrudDatos(data.datos || []);
                setCrudOpciones(data.opciones || {});
                setCrudError("");
            } catch (e) {
                if (controller.signal.aborted) return;
                if (e.response?.status === 401) {
                    navigate("/login", { replace: true });
                    return;
                }
                setCrudError(
                    e.response?.data?.mensaje ||
                    "No se pudieron cargar los registros de esta sección."
                );
            } finally {
                if (!controller.signal.aborted) setCrudCargando(false);
            }
        };

        cargarCRUD();
        const intervalo = setInterval(cargarCRUD, 15000);
        window.addEventListener("focus", cargarCRUD);

        return () => {
            controller.abort();
            clearInterval(intervalo);
            window.removeEventListener("focus", cargarCRUD);
        };
    }, [navigate, seccionCRUD, slugCRUD, intento]);

    const iniciarCRUD = registro => {
        setCrudError("");
        setCrudMensaje("");
        if (seccion === "Alumnos") {
            setCrudFormulario(registro
                ? {
                    id: registro.id_inscripcion,
                    id_alumno: String(registro.id_alumno),
                    id_grupo: String(registro.id_grupo),
                    observaciones: registro.observaciones || "",
                }
                : { id_alumno: "", id_grupo: "", observaciones: "" });
        } else if (seccion === "Evaluaciones") {
            setCrudFormulario({
                id: registro?.id_evaluacion,
                id_grupo: registro ? String(registro.id_grupo) : "",
                nombre_evaluacion: registro?.nombre_evaluacion || "",
                tipo_evaluacion: registro?.tipo_evaluacion || "",
                porcentaje: registro?.porcentaje ?? "",
                fecha: registro?.fecha ? String(registro.fecha).slice(0, 10) : "",
            });
        } else if (seccion === "Calificaciones") {
            setCrudFormulario(registro
                ? {
                    id: registro.id_calificacion,
                    id_inscripcion: String(registro.id_inscripcion),
                    id_evaluacion: String(registro.id_evaluacion),
                    calificacion: registro.calificacion ?? "",
                    observaciones: registro.observaciones || "",
                }
                : { id_inscripcion: "", id_evaluacion: "", calificacion: "", observaciones: "" });
        } else {
            setCrudFormulario(registro
                ? {
                    id: registro.id_asistencia,
                    id_inscripcion: String(registro.id_inscripcion),
                    fecha: String(registro.fecha).slice(0, 10),
                    estado: registro.estado || "Presente",
                    observaciones: registro.observaciones || "",
                }
                : {
                    id_inscripcion: "",
                    fecha: new Date().toLocaleDateString("en-CA"),
                    estado: "Presente",
                    observaciones: "",
                });
        }
    };

    const guardarCRUD = async event => {
        event.preventDefault();
        if (!crudFormulario) return;

        const token = sessionStorage.getItem("token_panel");
        const cuerpo = { ...crudFormulario };
        delete cuerpo.id;
        ["id_alumno", "id_grupo", "id_inscripcion", "id_evaluacion"].forEach(campo => {
            if (cuerpo[campo] !== undefined) cuerpo[campo] = Number(cuerpo[campo]);
        });

        setCrudGuardando(true);
        setCrudError("");
        setCrudMensaje("");
        try {
            const url = `docente/crud/${slugCRUD}/${crudFormulario.id ? `${crudFormulario.id}/` : ""}`;
            const respuesta = crudFormulario.id
                ? await API.put(url, cuerpo, { headers: { Authorization: `Bearer ${token}` } })
                : await API.post(url, cuerpo, { headers: { Authorization: `Bearer ${token}` } });
            notificarCambiosDocente();
            setCrudMensaje(respuesta.data.mensaje || "Cambios guardados.");
            setCrudFormulario(null);
            setIntento(valor => valor + 1);
        } catch (e) {
            if (e.response?.status === 401) {
                navigate("/login", { replace: true });
                return;
            }
            setCrudError(e.response?.data?.mensaje || "No se pudo guardar el registro.");
        } finally {
            setCrudGuardando(false);
        }
    };

    const eliminarCRUD = async registro => {
        const id = registro[campoIdCRUD];
        const mensaje = seccion === "Alumnos"
            ? "¿Desactivar la inscripción de este alumno en tu grupo?"
            : seccion === "Calificaciones"
                ? "¿Desactivar esta calificación?"
                : seccion === "Evaluaciones" ? "¿Desactivar esta evaluación? Se conservarán sus calificaciones registradas."
                : "¿Eliminar este registro de asistencia? Esta acción no se puede deshacer.";
        if (!window.confirm(mensaje)) return;

        const token = sessionStorage.getItem("token_panel");
        setCrudGuardando(true);
        setCrudError("");
        setCrudMensaje("");
        try {
            const { data } = await API.delete(`docente/crud/${slugCRUD}/${id}/`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            notificarCambiosDocente();
            setCrudMensaje(data.mensaje || "Registro eliminado.");
            setCrudFormulario(null);
            setIntento(valor => valor + 1);
        } catch (e) {
            if (e.response?.status === 401) {
                navigate("/login", { replace: true });
                return;
            }
            setCrudError(e.response?.data?.mensaje || "No se pudo eliminar el registro.");
        } finally { setCrudGuardando(false); }
    };

    const secciones = datos?.secciones || {};
    const nombresSecciones = Object.keys(secciones);

    const filas = (secciones[seccion] || []).filter(fila =>
        Object.values(fila)
            .join(" ")
            .toLowerCase()
            .includes(busqueda.toLowerCase())
    );

    const iconos = [
        "📚", "👥", "🎓", "📋", "📝",
        "📊", "🕒", "🏫", "📑", "📌"
    ];
    const filasCRUD = crudDatos.filter(fila =>
        Object.values(fila).join(" ").toLowerCase().includes(busqueda.toLowerCase())
    );
    const filasSeccion = seccionCRUD ? filasCRUD : filas;
    const inscripcionesFormulario = crudOpciones.inscripciones || [];
    const grupoInscripcion = inscripcionesFormulario.find(
        opcion => String(opcion.id_inscripcion) === crudFormulario?.id_inscripcion
    )?.id_grupo;
    const evaluacionesFormulario = (crudOpciones.evaluaciones || []).filter(
        opcion => grupoInscripcion && String(opcion.id_grupo) === String(grupoInscripcion)
    );

    return (
        <div className="docente-panel montreal-con-pie">

            <header className="docente-header">
                <div className="docente-header-contenido">

                    <Link to="/" className="docente-marca">
                        <span className="docente-logo">M</span>
                        <span>
                            <strong>UNIDAD MONTREAL</strong>
                            <small>Portal académico</small>
                        </span>
                    </Link>

                    <div className="docente-header-acciones">
                        <Link to="/" className="docente-btn-inicio">
                            Inicio
                        </Link>

                        <button
                            className="docente-btn-salir"
                            onClick={() => {
                                sessionStorage.removeItem("token_panel");
                                localStorage.removeItem("usuario");
                                navigate("/login", { replace: true });
                            }}
                        >
                            ↪ Cerrar sesión
                        </button>
                    </div>
                </div>
            </header>

            <main className="docente-contenido">

                <section className="docente-bienvenida">
                    <div>
                        <span className="docente-etiqueta">
                            PANEL DEL DOCENTE
                        </span>

                        <h1>
                            ¡Bienvenido{datos?.nombre
                                ? `, ${datos.nombre}`
                                : ""}!
                        </h1>

                        <p>
                            Consulta tus asignaciones y administra
                            tu información académica desde un solo lugar.
                        </p>
                    </div>

                    <div className="docente-avatar">
                        🎓
                    </div>
                </section>

                <div className="docente-resumen">
                    <div className="docente-resumen-texto">
                        <span>📂</span>
                        <div>
                            <strong>{nombresSecciones.length}</strong>
                            <p>Secciones disponibles</p>
                        </div>
                    </div>

                    <div className="docente-resumen-texto">
                        <span>📄</span>
                        <div>
                            <strong>{filasSeccion.length}</strong>
                            <p>Registros en esta sección</p>
                        </div>
                    </div>

                    <button
                        className="docente-btn-actualizar"
                        onClick={() => setIntento(i => i + 1)}
                    >
                        ↻ Actualizar información
                    </button>
                </div>

                {error && (
                    <div className="docente-error" role="alert">
                        {error}
                        <button onClick={() => setIntento(i => i + 1)}>
                            Reintentar
                        </button>
                    </div>
                )}

                {!datos && !error && (
                    <div className="docente-cargando" role="status">
                        <span>⏳</span>
                        <p>Cargando tu información académica...</p>
                    </div>
                )}

                {datos && (
                    <div className="docente-layout">

                        <aside className="docente-menu">
                            <h2>MI ESPACIO</h2>

                            <nav aria-label="Secciones del docente">
                                {nombresSecciones.map((nombre, indice) => (
                                    <button
                                        key={nombre}
                                        disabled={crudGuardando}
                                        className={
                                            seccion === nombre
                                                ? "docente-menu-item activo"
                                                : "docente-menu-item"
                                        }
                                        onClick={() => {
                                            setSeccion(nombre);
                                            setBusqueda("");
                                            setCrudFormulario(null);
                                            setCrudDatos([]);
                                            setCrudOpciones({});
                                            setCrudMensaje("");
                                            setCrudError("");
                                        }}
                                    >
                                        <span>
                                            {iconos[indice % iconos.length]}
                                        </span>

                                        <span className="docente-menu-nombre">
                                            {nombre}
                                        </span>

                                        <span className="docente-menu-cantidad">
                                            {(secciones[nombre] || []).length}
                                        </span>
                                    </button>
                                ))}
                            </nav>

                            <div className="docente-menu-ayuda">
                                <span>💡</span>
                                <p>
                                    Selecciona una sección para consultar
                                    tus registros académicos.
                                </p>
                            </div>
                        </aside>

                        <section className="docente-registros">

                            <div className="docente-registros-cabecera">
                                <div>
                                    <span className="docente-etiqueta">
                                        INFORMACIÓN ACADÉMICA
                                    </span>

                                    <h2>{seccion || "Mis asignaciones"}</h2>

                                    <p>
                                        Consulta y busca los registros
                                        disponibles en esta sección.
                                    </p>
                                </div>

                                <span className="docente-seccion-icono">
                                    {iconos[
                                        Math.max(0, nombresSecciones.indexOf(seccion))
                                        % iconos.length
                                    ]}
                                </span>
                            </div>

                            {seccionCRUD ? (
                                <div className="docente-crud">
                                    <div className="docente-crud-acciones">
                                        <div className="docente-busqueda">
                                            <span>⌕</span>
                                            <input
                                                type="search"
                                                aria-label="Buscar registros"
                                                placeholder="Buscar registros..."
                                                value={busqueda}
                                                onChange={e => setBusqueda(e.target.value)}
                                            />
                                            {busqueda && (
                                                <button onClick={() => setBusqueda("")}>Limpiar</button>
                                            )}
                                        </div>
                                        <button
                                            className="docente-crud-nuevo"
                                            disabled={crudGuardando || crudCargando || Boolean(crudError)}
                                            onClick={() => iniciarCRUD(null)}
                                        >
                                            + Nuevo registro
                                        </button>
                                    </div>

                                    {crudError && (
                                        <div className="docente-error" role="alert">{crudError}</div>
                                    )}
                                    {crudMensaje && (
                                        <div className="docente-crud-mensaje" role="status">{crudMensaje}</div>
                                    )}
                                    {crudCargando ? (
                                        <div className="docente-cargando" role="status">
                                            <span>⏳</span><p>Cargando registros...</p>
                                        </div>
                                    ) : !filasSeccion.length ? (
                                        <div className="docente-vacio">
                                            <span>📭</span>
                                            <h3>No hay registros para mostrar</h3>
                                            <p>
                                                {busqueda
                                                    ? "No hay coincidencias con la búsqueda."
                                                    : "Puedes agregar un registro con el botón «Nuevo registro»."}
                                            </p>
                                        </div>
                                    ) : (
                                        <div className="docente-tabla-contenedor">
                                            <table className="docente-tabla">
                                                <thead>
                                                    <tr>
                                                        {(seccion === "Alumnos"
                                                            ? ["Alumno", "Matrícula", "Grupo", "Observaciones"]
                                                            : seccion === "Calificaciones"
                                                                ? ["Alumno", "Matrícula", "Grupo", "Evaluación", "Calificación", "Observaciones"]
                                                                : seccion === "Evaluaciones" ? ["Evaluación", "Grupo", "Tipo", "Porcentaje", "Fecha"]
                                                                : ["Alumno", "Matrícula", "Grupo", "Fecha", "Estado", "Observaciones"]
                                                        ).map(columna => <th scope="col" key={columna}>{columna}</th>)}
                                                        <th scope="col">Acciones</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {filasSeccion.map(fila => (
                                                        <tr key={fila[campoIdCRUD]}>
                                                            {seccion === "Alumnos" ? (
                                                                <>
                                                                    <td>{fila.nombre}</td>
                                                                    <td>{fila.matricula}</td>
                                                                    <td>{fila.grupo}</td>
                                                                    <td>{fila.observaciones || "—"}</td>
                                                                </>
                                                            ) : seccion === "Calificaciones" ? (
                                                                <>
                                                                    <td>{fila.alumno}</td>
                                                                    <td>{fila.matricula}</td>
                                                                    <td>{fila.grupo}</td>
                                                                    <td>{fila.evaluacion}</td>
                                                                    <td>{fila.calificacion ?? "—"}</td>
                                                                    <td>{fila.observaciones || "—"}</td>
                                                                </>
                                                            ) : seccion === "Evaluaciones" ? (
                                                                <><td>{fila.nombre_evaluacion}</td><td>{fila.grupo}</td><td>{fila.tipo_evaluacion || "—"}</td><td>{fila.porcentaje != null ? `${fila.porcentaje}%` : "—"}</td><td>{fila.fecha || "Por confirmar"}</td></>
                                                            ) : (
                                                                <>
                                                                    <td>{fila.alumno}</td>
                                                                    <td>{fila.matricula}</td>
                                                                    <td>{fila.grupo}</td>
                                                                    <td>{fila.fecha}</td>
                                                                    <td>{fila.estado}</td>
                                                                    <td>{fila.observaciones || "—"}</td>
                                                                </>
                                                            )}
                                                            <td>
                                                                <div className="docente-crud-fila-acciones">
                                                                    <button type="button" disabled={crudGuardando} onClick={() => iniciarCRUD(fila)}>Editar</button>
                                                                    <button type="button" disabled={crudGuardando} className="eliminar" onClick={() => eliminarCRUD(fila)}>Eliminar</button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    )}

                                    {crudFormulario && (
                                        <form className="docente-crud-formulario" onSubmit={guardarCRUD}>
                                            <div className="docente-crud-formulario-cabecera">
                                                <h3>{crudFormulario.id ? "Editar registro" : "Agregar registro"}</h3>
                                                <button type="button" disabled={crudGuardando} aria-label="Cerrar formulario" onClick={() => setCrudFormulario(null)}>×</button>
                                            </div>

                                            {seccion === "Alumnos" && (
                                                <>
                                                    <p>Administra la inscripción del alumno en tus grupos. Su cuenta y datos personales se conservan.</p>
                                                    <label>
                                                        Alumno
                                                        <select required value={crudFormulario.id_alumno} onChange={e => setCrudFormulario({ ...crudFormulario, id_alumno: e.target.value })}>
                                                            <option value="">Selecciona un alumno</option>
                                                            {(crudOpciones.alumnos || []).map(alumno => (
                                                                <option key={alumno.id_alumno} value={alumno.id_alumno}>{alumno.nombre} · {alumno.matricula}</option>
                                                            ))}
                                                        </select>
                                                    </label>
                                                    <label>
                                                        Grupo asignado
                                                        <select required value={crudFormulario.id_grupo} onChange={e => setCrudFormulario({ ...crudFormulario, id_grupo: e.target.value })}>
                                                            <option value="">Selecciona un grupo</option>
                                                            {(crudOpciones.grupos || []).map(grupo => (
                                                                <option key={grupo.id_grupo} value={grupo.id_grupo}>{grupo.nombre_grupo} · {grupo.curso}</option>
                                                            ))}
                                                        </select>
                                                    </label>
                                                </>
                                            )}

                                            {seccion === "Calificaciones" && (
                                                <>
                                                    <label>
                                                        Alumno y grupo
                                                        <select required value={crudFormulario.id_inscripcion} onChange={e => setCrudFormulario({ ...crudFormulario, id_inscripcion: e.target.value, id_evaluacion: "" })}>
                                                            <option value="">Selecciona alumno/grupo</option>
                                                            {inscripcionesFormulario.map(opcion => (
                                                                <option key={opcion.id_inscripcion} value={opcion.id_inscripcion}>{opcion.alumno} · {opcion.matricula} · {opcion.grupo}</option>
                                                            ))}
                                                        </select>
                                                    </label>
                                                    <label>
                                                        Evaluación
                                                        <select required value={crudFormulario.id_evaluacion} onChange={e => setCrudFormulario({ ...crudFormulario, id_evaluacion: e.target.value })}>
                                                            <option value="">Selecciona una evaluación</option>
                                                            {evaluacionesFormulario.map(opcion => (
                                                                <option key={opcion.id_evaluacion} value={opcion.id_evaluacion}>{opcion.grupo} · {opcion.nombre}</option>
                                                            ))}
                                                        </select>
                                                    </label>
                                                    <label>
                                                        Calificación (0 a 100)
                                                        <input required type="number" min="0" max="100" step="0.01" value={crudFormulario.calificacion} onChange={e => setCrudFormulario({ ...crudFormulario, calificacion: e.target.value })} />
                                                    </label>
                                                </>
                                            )}

                                            {seccion === "Asistencias" && (
                                                <>
                                                    <label>
                                                        Alumno y grupo
                                                        <select required value={crudFormulario.id_inscripcion} disabled={Boolean(crudFormulario.id)} onChange={e => setCrudFormulario({ ...crudFormulario, id_inscripcion: e.target.value })}>
                                                            <option value="">Selecciona alumno/grupo</option>
                                                            {inscripcionesFormulario.map(opcion => (
                                                                <option key={opcion.id_inscripcion} value={opcion.id_inscripcion}>{opcion.alumno} · {opcion.matricula} · {opcion.grupo}</option>
                                                            ))}
                                                        </select>
                                                    </label>
                                                    <label>
                                                        Fecha
                                                        <input required type="date" value={crudFormulario.fecha} onChange={e => setCrudFormulario({ ...crudFormulario, fecha: e.target.value })} />
                                                    </label>
                                                    <label>
                                                        Estado de asistencia
                                                        <select required value={crudFormulario.estado} onChange={e => setCrudFormulario({ ...crudFormulario, estado: e.target.value })}>
                                                            {["Presente", "Ausente", "Justificada", "Retardo"].map(estado => <option key={estado} value={estado}>{estado}</option>)}
                                                        </select>
                                                    </label>
                                                </>
                                            )}

                                            {seccion === "Evaluaciones" && (
                                                <>
                                                    <label>Grupo asignado
                                                        <select required value={crudFormulario.id_grupo} onChange={e => setCrudFormulario({ ...crudFormulario, id_grupo: e.target.value })}>
                                                            <option value="">Selecciona un grupo</option>
                                                            {(crudOpciones.grupos || []).map(g => <option key={g.id_grupo} value={g.id_grupo}>{g.nombre_grupo} · {g.curso}</option>)}
                                                        </select>
                                                    </label>
                                                    <label>Nombre de la evaluación<input required maxLength={100} value={crudFormulario.nombre_evaluacion} onChange={e => setCrudFormulario({ ...crudFormulario, nombre_evaluacion: e.target.value })} /></label>
                                                    <label>Tipo de evaluación
                                                        <select value={crudFormulario.tipo_evaluacion} onChange={e => setCrudFormulario({ ...crudFormulario, tipo_evaluacion: e.target.value })}>
                                                            <option value="">Selecciona un tipo</option>
                                                            {[...new Set(["Examen", "Tarea", "Proyecto", "Participación", "Práctica", crudFormulario.tipo_evaluacion].filter(Boolean))].map(t => <option key={t} value={t}>{t}</option>)}
                                                        </select>
                                                    </label>
                                                    <label>Porcentaje<input type="number" min="0" max="100" step="0.01" value={crudFormulario.porcentaje} onChange={e => setCrudFormulario({ ...crudFormulario, porcentaje: e.target.value })} /></label>
                                                    <label>Fecha<input type="date" value={crudFormulario.fecha} onChange={e => setCrudFormulario({ ...crudFormulario, fecha: e.target.value })} /></label>
                                                </>
                                            )}
                                            {!["Asistencias", "Evaluaciones"].includes(seccion) && (
                                                <label>
                                                    Observaciones
                                                    <textarea value={crudFormulario.observaciones} onChange={e => setCrudFormulario({ ...crudFormulario, observaciones: e.target.value })} rows="3" />
                                                </label>
                                            )}
                                            {seccion === "Asistencias" && (
                                                <label>
                                                    Observaciones
                                                    <textarea value={crudFormulario.observaciones} onChange={e => setCrudFormulario({ ...crudFormulario, observaciones: e.target.value })} rows="3" />
                                                </label>
                                            )}

                                            <div className="docente-crud-formulario-acciones">
                                                <button type="button" disabled={crudGuardando} className="cancelar" onClick={() => setCrudFormulario(null)}>Cancelar</button>
                                                <button type="submit" disabled={crudGuardando}>
                                                    {crudGuardando ? "Guardando..." : "Guardar"}
                                                </button>
                                            </div>
                                        </form>
                                    )}
                                    <div className="docente-tabla-info">
                                        <span>{filasSeccion.length} registro(s) encontrado(s)</span>
                                        <span>Actualización automática cada 15 s</span>
                                    </div>
                                </div>
                            ) : (
                                <>
                                    <div className="docente-busqueda">
                                        <span>⌕</span>
                                        <input
                                            type="search"
                                            aria-label="Buscar registros"
                                            placeholder="Buscar por nombre, grupo o información..."
                                            value={busqueda}
                                            onChange={e => setBusqueda(e.target.value)}
                                        />
                                        {busqueda && <button onClick={() => setBusqueda("")}>Limpiar</button>}
                                    </div>

                                    <div className="docente-tabla-info">
                                        <span>{filas.length} registro(s) encontrado(s)</span>
                                        <span>Actualización automática cada 15 s</span>
                                    </div>

                                    {!filas.length ? (
                                        <div className="docente-vacio">
                                            <span>📭</span>
                                            <h3>No hay registros para mostrar</h3>
                                            <p>No se encontraron datos en esta sección con la búsqueda actual.</p>
                                        </div>
                                    ) : (
                                        <div className="docente-tabla-contenedor">
                                            <table className="docente-tabla">
                                                <thead>
                                                    <tr>{Object.keys(filas[0]).map(columna => <th scope="col" key={columna}>{columna.replaceAll("_", " ")}</th>)}</tr>
                                                </thead>
                                                <tbody>
                                                    {filas.map((fila, indice) => (
                                                        <tr key={indice}>
                                                            {Object.entries(fila).map(([columna, valor]) => <td key={columna}>{valor ?? "—"}</td>)}
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    )}
                                </>
                            )}

                        </section>
                    </div>
                )}



                {datos && <ArchivosDocente />}
            </main>
            <PiePagina />
        </div>
    );
}
