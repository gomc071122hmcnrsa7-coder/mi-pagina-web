import { useEffect, useState } from "react";
import API from "../api/api";

function MenuPublico() {

    const [cursos, setCursos] = useState([]);

    useEffect(() => {

        API.get("cursos/")
            .then(res => {
                setCursos(res.data);
            })
            .catch(error => {
                console.error(error);
            });

    }, []);

    return (

        <div className="container mt-5">

            <h2 className="text-center">
                Cursos Disponibles
            </h2>

            <div className="row">

                {cursos.map(curso => (

                    <div
                        className="col-md-4"
                        key={curso.id_curso}
                    >

                        <div className="card m-2 shadow">

                            <div className="card-body">

                                <h5>
                                    {curso.nombre_curso}
                                </h5>

                                <p>
                                    {curso.descripcion}
                                </p>

                                <p>
                                    Duración:
                                    {curso.duracion_horas} horas
                                </p>

                                <h4>
                                    ${curso.costo}
                                </h4>

                                <span className="badge bg-success">
                                    {curso.nivel}
                                </span>

                            </div>

                        </div>

                    </div>

                ))}

            </div>

        </div>

    );

}

export default MenuPublico;