from rest_framework import serializers

from .models import (
    Cursos,
    Alumnos,
    Docentes,
    Grupos,
    Inscripciones,
    Horarios,
    Usuarios,
    Roles,
    Periodos,
    Aulas,
    Dias,
    Pagos,
    Asistencias,
    Evaluaciones,
    Calificaciones,
    EntidadesCertificadoras,
    Certificaciones
)

class CursoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cursos
        fields = '__all__'


class AlumnoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Alumnos
        fields = '__all__'


class DocenteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Docentes
        fields = '__all__'


class GrupoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Grupos
        fields = '__all__'


class InscripcionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Inscripciones
        fields = '__all__'

class HorarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Horarios
        fields = '__all__'

class UsuarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Usuarios
        fields = '__all__'


class RolSerializer(serializers.ModelSerializer):
    class Meta:
        model = Roles
        fields = '__all__'


class PeriodoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Periodos
        fields = '__all__'


class AulaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Aulas
        fields = '__all__'


class DiaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dias
        fields = '__all__'


class PagoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Pagos
        fields = '__all__'


class AsistenciaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Asistencias
        fields = '__all__'


class EvaluacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Evaluaciones
        fields = '__all__'


class CalificacionSerializer(serializers.ModelSerializer):
    id_alumno = serializers.IntegerField(source='id_inscripcion.id_alumno_id', read_only=True)
    class Meta:
        model = Calificaciones
        fields = '__all__'


class EntidadCertificadoraSerializer(serializers.ModelSerializer):
    class Meta:
        model = EntidadesCertificadoras
        fields = '__all__'


class CertificacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Certificaciones
        fields = '__all__'
