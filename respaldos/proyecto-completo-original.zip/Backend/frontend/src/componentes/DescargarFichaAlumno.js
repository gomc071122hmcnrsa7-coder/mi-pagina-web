import { useState } from "react";
import API from "../api/api";

export default function DescargarFichaAlumno() {
    const [ocupado, setOcupado] = useState(false);
    const [mensaje, setMensaje] = useState("");
    const descargar = async formato => {
        if (ocupado) return;
        setOcupado(true); setMensaje("");
        try {
            const { data } = await API.get(`alumno/ficha/${formato}/`, {
                headers: { Authorization: `Bearer ${sessionStorage.getItem("token_alumno")}` },
                responseType: "blob",
            });
            const url = URL.createObjectURL(data);
            const enlace = document.createElement("a");
            enlace.href = url; enlace.download = `mi-ficha-academica.${formato}`;
            document.body.appendChild(enlace); enlace.click(); enlace.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
            setMensaje("Tu ficha está lista. La descarga se ha iniciado.");
        } catch (error) {
            setMensaje(error.response?.status === 401 ? "Tu sesión venció. Inicia sesión nuevamente." : "No se pudo generar tu ficha. Intenta nuevamente.");
        } finally { setOcupado(false); }
    };
    return <section className="card p-4 my-4" aria-labelledby="descargar-ficha">
        <h3 className="h4" id="descargar-ficha">Descargar mi información</h3>
        <p>Obtén tu ficha con tus datos personales, cursos inscritos, docente, grupo, periodo, horarios, aulas, calificaciones y asistencias registrados.</p>
        <div className="d-flex flex-wrap gap-2">
            <button className="btn btn-success" disabled={ocupado} onClick={() => descargar("pdf")}>Descargar PDF</button>
            <button className="btn btn-outline-success" disabled={ocupado} onClick={() => descargar("docx")}>Descargar Word</button>
        </div>
        {ocupado && <p role="status" className="mt-2">Generando tu documento…</p>}
        {mensaje && <p role="status" className="mt-2 mb-0">{mensaje}</p>}
    </section>;
}
