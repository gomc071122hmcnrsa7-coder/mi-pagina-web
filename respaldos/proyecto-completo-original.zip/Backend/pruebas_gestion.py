"""Prueba integral aislada: python Backend/pruebas_gestion.py. No usa la base real."""
import os
import json
import unittest
from unittest.mock import patch
from io import BytesIO
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import override_settings

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Backend.settings')
from django.conf import settings
settings.DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': ':memory:'}}
import django
django.setup()

from django.apps import apps
from django.core import signing
from django.db import connection
from django.test import RequestFactory
from django.utils import timezone
from bibliotecaapp import models as m
from bibliotecaapp.gestion import catalogo, guardar, resumen_pagos
from bibliotecaapp.panel_docente import datos_docente, crud_docente
from bibliotecaapp.panel_alumno import cursos_familia, mis_cursos, inscribirme
from bibliotecaapp.views import login, registro
from bibliotecaapp.importar_asistencias import revisar_asistencias, confirmar_asistencias
from bibliotecaapp.reporte_alumno import descargar_ficha
from bibliotecaapp.archivos_docente import archivos_docente, descargar_excel
from bibliotecaapp.constancias import mis_constancias, archivo_constancia, ruta_pdf, subir_constancia
from django.http import Http404


class FlujoGestion(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with connection.schema_editor() as editor:
            for modelo in apps.get_app_config('bibliotecaapp').get_models():
                editor.create_model(modelo)

    def test_asignacion_completa_y_aislamiento(self):
        factory = RequestFactory()
        roles = {nombre: m.Roles.objects.create(nombre_rol=nombre, estado=1) for nombre in ['Administrador', 'Docente', 'Alumno', 'Padre']}
        def usuario(nombre, rol):
            return m.Usuarios.objects.create(nombre_usuario=nombre, email=nombre+'@example.com', password_hash='prueba', id_rol=roles[rol], estado=1, fecha_creacion=timezone.now())
        alta = registro(factory.post('/api/registro/', data=json.dumps({
            'nombre': 'Alumno nuevo', 'correo': 'autoregistro@example.com',
            'password': 'ClavePrueba123!', 'confirmar': 'ClavePrueba123!', 'telefono': '7225720866', 'edad': '20', 'id_rol': roles['Alumno'].pk,
        }), content_type='application/json'))
        self.assertEqual(alta.status_code, 201, alta.content)
        perfil = m.Alumnos.objects.get(id_usuario_id=json.loads(alta.content)['id_usuario'])
        self.assertEqual(perfil.estado, 1)
        self.assertTrue(perfil.matricula)
        from django.contrib.auth.hashers import check_password
        self.assertTrue(check_password('ClavePrueba123!', perfil.id_usuario.password_hash))
        for cambios in [{'password': 'debil', 'confirmar': 'debil'}, {'confirmar': 'OtraClave123!'}, {'correo': 'no-es-correo'}, {'telefono': 'abc'}, {'telefono': '123456789'}, {'telefono': '12345678901'}, {'edad': '-1'}, {'edad': '0'}, {'edad': '51'}, {'edad': '2.5'}]:
            datos_invalidos = {'nombre': 'Prueba', 'correo': 'rechazado@example.com', 'password': 'ClavePrueba123!',
                'confirmar': 'ClavePrueba123!', 'telefono': '7225720866', 'edad': '20', 'id_rol': roles['Alumno'].pk, **cambios}
            antes = m.Usuarios.objects.count()
            rechazo = registro(factory.post('/api/registro/', data=json.dumps(datos_invalidos), content_type='application/json'))
            self.assertEqual(rechazo.status_code, 400, rechazo.content)
            self.assertEqual(m.Usuarios.objects.count(), antes)

        admin = usuario('admin', 'Administrador')
        docente_usuario = usuario('docente', 'Docente')
        otro_docente = usuario('otrodocente', 'Docente')
        alumno_usuario = usuario('alumno', 'Alumno')
        antiguo = usuario('alumno_sin_perfil', 'Alumno')
        token_antiguo = signing.dumps({'id_usuario': antiguo.pk}, salt='panel-alumno')
        def acceder_antiguo():
            return mis_cursos(factory.get('/api/alumno/mis-cursos/', HTTP_AUTHORIZATION='Bearer '+token_antiguo))
        self.assertEqual(acceder_antiguo().status_code, 200)
        self.assertEqual(acceder_antiguo().status_code, 200)
        self.assertEqual(m.Alumnos.objects.filter(id_usuario=antiguo).count(), 1)
        m.Alumnos.objects.filter(id_usuario=antiguo).update(estado=0)
        self.assertEqual(acceder_antiguo().status_code, 403)
        padre = usuario('padre', 'Padre')
        padre_ajeno = usuario('otrofamiliar', 'Padre')
        def peticion(cuenta, metodo='get', datos=None, alumno=False):
            salt = 'panel-alumno' if alumno else 'panel-roles'
            return getattr(factory, metodo)('/api/', data=json.dumps(datos or {}) if metodo != 'get' else None,
                content_type='application/json', HTTP_AUTHORIZATION='Bearer '+signing.dumps({'id_usuario': cuenta.pk}, salt=salt))
        def crear(tabla, datos):
            response = guardar(peticion(admin, 'post', datos), tabla)
            self.assertEqual(response.status_code, 200, response.content)
            return json.loads(response.content)['id']
        cuenta_id = crear('padres', {'nombre_usuario': 'Familiar nuevo', 'email': 'nuevo@example.com', 'password_hash': 'ClaveDePrueba123', 'estado': 1})
        cuenta = m.Usuarios.objects.get(pk=cuenta_id)
        self.assertNotEqual(cuenta.password_hash, 'ClaveDePrueba123')
        respuesta_login = login(factory.post('/api/login/', data=json.dumps({'correo': cuenta.email, 'password': 'ClaveDePrueba123'}), content_type='application/json'))
        self.assertEqual(respuesta_login.status_code, 200)
        self.assertIn('token_panel', json.loads(respuesta_login.content))
        respuesta_hash = login(factory.post('/api/login/', data=json.dumps({'correo': cuenta.email, 'password': cuenta.password_hash}), content_type='application/json'))
        self.assertEqual(respuesta_hash.status_code, 401)
        docente_id = crear('docentes', {'id_usuario': docente_usuario.pk, 'nombre': 'Docente', 'apellido_paterno': 'Uno', 'estado': 1})
        crear('docentes', {'id_usuario': otro_docente.pk, 'nombre': 'Otro', 'apellido_paterno': 'Dos', 'estado': 1})
        with TemporaryDirectory() as carpeta, override_settings(MEDIA_ROOT=carpeta):
            contenido = BytesIO()
            with ZipFile(contenido, 'w') as libro:
                libro.writestr('[Content_Types].xml', '<Types/>')
                libro.writestr('xl/workbook.xml', '<workbook/>')
            def subir_excel(cuenta, nombre, contenido):
                return archivos_docente(factory.post('/api/docente/archivos/',
                    {'archivo': SimpleUploadedFile(nombre, contenido), 'seccion': 'Alumnos'},
                    HTTP_AUTHORIZATION='Bearer '+signing.dumps({'id_usuario': cuenta.pk}, salt='panel-roles')))
            self.assertEqual(subir_excel(docente_usuario, 'falso.xlsx', b'no es excel').status_code, 400)
            self.assertEqual(subir_excel(alumno_usuario, 'datos.xlsx', contenido.getvalue()).status_code, 403)
            carga = subir_excel(docente_usuario, 'datos.xlsx', contenido.getvalue())
            self.assertEqual(carga.status_code, 201, carga.content)
            archivo_id = json.loads(carga.content)['id']
            listado = json.loads(archivos_docente(peticion(docente_usuario)).content)['archivos']
            self.assertEqual(listado[0]['nombre'], 'datos.xlsx')
            self.assertEqual(json.loads(archivos_docente(peticion(otro_docente)).content)['archivos'], [])
            with self.assertRaises(Http404):
                descargar_excel(peticion(otro_docente), archivo_id)
            descarga_excel = descargar_excel(peticion(docente_usuario), archivo_id)
            self.assertEqual(b''.join(descarga_excel.streaming_content), contenido.getvalue())
            descarga_excel.close()
        alumno_id = crear('alumnos', {'id_usuario': alumno_usuario.pk, 'nombre': 'Alumno', 'apellido_paterno': 'Uno', 'matricula': 'M1', 'estado': 1})
        curso_id = crear('cursos', {'nombre_curso': 'Inglés', 'estado': 1})
        periodo_id = crear('periodos', {'nombre_periodo': 'Actual', 'fecha_inicio': '2026-01-01', 'fecha_fin': '2026-12-31', 'estado': 1})
        grupo_id = crear('grupos', {'nombre_grupo': 'Grupo A', 'id_curso': curso_id, 'id_docente': docente_id, 'id_periodo': periodo_id, 'estado': 1})
        grupo_b = crear('grupos', {'nombre_grupo': 'Grupo B', 'id_curso': curso_id, 'id_docente': docente_id, 'id_periodo': periodo_id, 'estado': 1})
        dia = crear('dias', {'nombre_dia': 'Lunes', 'estado': 1})
        aula = crear('aulas', {'nombre_aula': 'Aula 1', 'estado': 1})
        horario = {'id_grupo': grupo_id, 'id_dia': dia, 'id_aula': aula, 'hora_inicio': '10:00', 'hora_fin': '11:00', 'estado': 1}
        crear('horarios', horario)
        self.assertEqual(guardar(peticion(admin, 'post', {**horario, 'id_grupo': grupo_b}), 'horarios').status_code, 400)
        inscripcion = {'id_alumno': alumno_id, 'id_grupo': grupo_id, 'fecha_inscripcion': '2026-10-01', 'estado': 1}
        inscripcion_id = crear('inscripciones', inscripcion)
        self.assertEqual(guardar(peticion(admin, 'post', inscripcion), 'inscripciones').status_code, 400)
        entidad = m.EntidadesCertificadoras.objects.create(nombre_entidad='Montreal', estado=1)
        constancia = m.Certificaciones.objects.create(id_inscripcion_id=inscripcion_id,
            id_entidad=entidad, folio_certificado='PRUEBA-1', estado=1,
            created_at=timezone.now(), url_certificado='constancias/prueba.pdf')
        with patch('bibliotecaapp.constancias.default_storage.exists', return_value=True), patch(
            'bibliotecaapp.constancias.default_storage.open', side_effect=lambda *args: BytesIO(b'%PDF-prueba')):
            listado = mis_constancias(peticion(alumno_usuario, alumno=True))
            self.assertEqual(json.loads(listado.content)['constancias'][0]['folio'], 'PRUEBA-1')
            descarga = archivo_constancia(peticion(alumno_usuario, alumno=True), constancia.pk)
            self.assertIn('attachment', descarga['Content-Disposition'])
            self.assertEqual(b''.join(descarga.streaming_content), b'%PDF-prueba')
            descarga.close()
            consulta = peticion(alumno_usuario, alumno=True)
            consulta.GET = consulta.GET.copy()
            consulta.GET['ver'] = '1'
            vista = archivo_constancia(consulta, constancia.pk)
            self.assertIn('inline', vista['Content-Disposition'])
            vista.close()
            m.Alumnos.objects.filter(id_usuario=antiguo).update(estado=1)
            self.assertEqual(json.loads(mis_constancias(peticion(antiguo, alumno=True)).content)['constancias'], [])
            with self.assertRaises(Http404):
                archivo_constancia(peticion(antiguo, alumno=True), constancia.pk)
            constancia.estado = 0
            constancia.save()
            with self.assertRaises(Http404):
                archivo_constancia(peticion(alumno_usuario, alumno=True), constancia.pk)
        constancia.estado = 1
        constancia.save()
        with TemporaryDirectory() as carpeta, override_settings(MEDIA_ROOT=carpeta):
            def cargar_constancia(cuenta):
                return subir_constancia(factory.post('/api/', {'archivo': SimpleUploadedFile('constancia.pdf', b'%PDF-prueba')},
                    HTTP_AUTHORIZATION='Bearer '+signing.dumps({'id_usuario': cuenta.pk}, salt='panel-roles')), constancia.pk)
            self.assertEqual(cargar_constancia(alumno_usuario).status_code, 403)
            self.assertEqual(cargar_constancia(admin).status_code, 200)
            self.assertTrue(json.loads(mis_constancias(peticion(alumno_usuario, alumno=True)).content)['constancias'][0]['disponible'])
            archivo_asignado = archivo_constancia(peticion(alumno_usuario, alumno=True), constancia.pk)
            self.assertEqual(b''.join(archivo_asignado.streaming_content), b'%PDF-prueba')
            archivo_asignado.close()
        self.assertIsNone(ruta_pdf('../archivo.pdf'))
        self.assertIsNone(ruta_pdf('https://example.com/archivo.pdf'))
        from openpyxl import Workbook
        def revisar_excel(filas_excel, cuenta=docente_usuario):
            libro = Workbook()
            libro.active.append(['matricula', 'grupo', 'fecha', 'estado', 'observaciones'])
            for fila_excel in filas_excel:
                libro.active.append(fila_excel)
            contenido_excel = BytesIO()
            libro.save(contenido_excel)
            return revisar_asistencias(factory.post('/api/', {'archivo': SimpleUploadedFile('asistencias.xlsx', contenido_excel.getvalue())},
                HTTP_AUTHORIZATION='Bearer '+signing.dumps({'id_usuario': cuenta.pk}, salt='panel-roles')))
        fila_excel = ['M1', 'Grupo A', '2026-01-12', 'Inasistencia', 'Sin aviso']
        revision = json.loads(revisar_excel([fila_excel]).content)
        self.assertEqual(revision['errores'], [])
        self.assertEqual(revision['filas'][0]['estado'], 'Ausente')
        token_importar = revision['token']
        self.assertEqual(confirmar_asistencias(peticion(otro_docente, 'post', {'token': token_importar})).status_code, 400)
        self.assertEqual(confirmar_asistencias(peticion(docente_usuario, 'post', {'token': token_importar})).status_code, 200)
        self.assertEqual(confirmar_asistencias(peticion(docente_usuario, 'post', {'token': token_importar})).status_code, 200)
        self.assertEqual(m.Asistencias.objects.filter(id_inscripcion_id=inscripcion_id, fecha='2026-01-12').count(), 1)
        self.assertIsNone(json.loads(revisar_excel([fila_excel, fila_excel]).content)['token'])
        self.assertIsNone(json.loads(revisar_excel([fila_excel], otro_docente).content)['token'])
        modificada = json.loads(revisar_excel([['M1', 'Grupo A', '2026-01-12', 'Justificada', 'Aviso recibido']]).content)
        self.assertEqual(modificada['filas'][0]['accion'], 'Actualizar')
        self.assertEqual(confirmar_asistencias(peticion(docente_usuario, 'post', {'token': modificada['token']})).status_code, 200)
        self.assertEqual(m.Asistencias.objects.get(id_inscripcion_id=inscripcion_id, fecha='2026-01-12').estado, 'Justificada')
        # Horarios duplicados y saldo calculado a partir de abonos activos.
        self.assertEqual(guardar(peticion(admin, 'post', horario), 'horarios').status_code, 400)
        m.Cursos.objects.filter(pk=curso_id).update(costo='100')
        def situacion_pago():
            return next(r for r in resumen_pagos() if r['id_inscripcion'] == inscripcion_id)['situacion']
        self.assertEqual(situacion_pago(), 'Incompleto')
        pago = m.Pagos.objects.create(id_inscripcion_id=inscripcion_id, fecha_pago='2026-10-01', monto='40', moneda='MXN', estado=1)
        self.assertEqual(situacion_pago(), 'Incompleto')
        segundo = m.Pagos.objects.create(id_inscripcion_id=inscripcion_id, fecha_pago='2026-10-02', monto='60', moneda='MXN', estado=1)
        self.assertEqual(situacion_pago(), 'Completo')
        segundo.estado = 0
        segundo.save()
        self.assertEqual(situacion_pago(), 'Incompleto')
        pago.moneda = 'USD'
        pago.save()
        self.assertEqual(situacion_pago(), 'Por revisar')
        evaluacion = crear('evaluaciones', {'id_grupo': grupo_id, 'nombre_evaluacion': 'Examen', 'estado': 1})
        otra_evaluacion = crear('evaluaciones', {'id_grupo': grupo_b, 'nombre_evaluacion': 'Otro examen', 'estado': 1})
        nota = {'id_inscripcion': inscripcion_id, 'id_evaluacion': evaluacion, 'calificacion': '9.5', 'estado': 1}
        nota_id = crear('calificaciones', nota)
        self.assertEqual(guardar(peticion(admin, 'post', {**nota, 'id_evaluacion': otra_evaluacion}), 'calificaciones').status_code, 400)
        crear('familias', {'padre': padre.pk, 'alumno': alumno_id, 'parentesco': 'Padre', 'estado': 1})
        self.assertEqual(catalogo(peticion(docente_usuario)).status_code, 403)
        self.assertEqual(guardar(peticion(alumno_usuario, 'post', {'nombre_curso': 'No autorizado'}), 'cursos').status_code, 403)
        self.assertEqual(len(json.loads(datos_docente(peticion(docente_usuario)).content)['secciones']['Alumnos']), 1)
        self.assertEqual(json.loads(datos_docente(peticion(otro_docente)).content)['secciones']['Alumnos'], [])
        self.assertEqual(len(json.loads(cursos_familia(peticion(padre)).content)['cursos']), 1)
        self.assertEqual(json.loads(cursos_familia(peticion(padre_ajeno)).content)['cursos'], [])
        response = guardar(peticion(admin, 'put', {**nota, 'calificacion': '10'}), 'calificaciones', nota_id)
        self.assertEqual(response.status_code, 200, response.content)
        self.assertEqual(json.loads(mis_cursos(peticion(alumno_usuario, alumno=True)).content)['cursos'][0]['calificaciones'][0]['calificacion'], '10.00')
        for formato in ('pdf', 'docx'):
            ficha = descargar_ficha(peticion(alumno_usuario, alumno=True), formato)
            self.assertEqual(ficha.status_code, 200)
            contenido_ficha = b''.join(ficha.streaming_content)
            ficha.close()
            self.assertIn('attachment', ficha['Content-Disposition'])
            if formato == 'pdf':
                self.assertTrue(contenido_ficha.startswith(b'%PDF-'))
            else:
                from docx import Document
                texto_ficha = '\n'.join(p.text for p in Document(BytesIO(contenido_ficha)).paragraphs)
                self.assertIn('Alumno Uno', texto_ficha)
                self.assertIn('Grupo A', texto_ficha)
                self.assertIn('Aula 1', texto_ficha)
            self.assertEqual(descargar_ficha(peticion(padre, alumno=True), formato).status_code, 403)
        self.assertEqual(descargar_ficha(peticion(alumno_usuario, alumno=True), 'exe').status_code, 400)
        # CRUD docente: las cuatro secciones y los intentos de acceso de otro docente.
        def crud(seccion, metodo='get', datos=None, registro_id=None, cuenta=docente_usuario):
            return crud_docente(peticion(cuenta, metodo, datos), seccion, registro_id)
        opciones = json.loads(crud('evaluaciones').content)['opciones']['grupos']
        self.assertEqual({g['id_grupo'] for g in opciones}, {grupo_id, grupo_b})
        nueva = crud('evaluaciones', 'post', {'id_grupo': grupo_id, 'nombre_evaluacion': 'Proyecto', 'porcentaje': '30', 'fecha': '2026-10-15'})
        self.assertEqual(nueva.status_code, 201, nueva.content)
        nueva_id = json.loads(nueva.content)['id']
        self.assertEqual(crud('evaluaciones', 'put', {'nombre_evaluacion': 'Proyecto final'}, nueva_id).status_code, 200)
        self.assertEqual(crud('evaluaciones', 'put', {'nombre_evaluacion': ' '}, nueva_id).status_code, 400)
        self.assertEqual(crud('evaluaciones', 'put', {'id_grupo': grupo_b}, evaluacion).status_code, 400)
        nota_nueva = crud('calificaciones', 'post', {'id_inscripcion': inscripcion_id, 'id_evaluacion': nueva_id, 'calificacion': '85'})
        self.assertEqual(nota_nueva.status_code, 201, nota_nueva.content)
        nueva_nota_id = json.loads(nota_nueva.content)['id']
        self.assertEqual(crud('calificaciones', 'put', {'calificacion': '90'}, nueva_nota_id).status_code, 200)
        asistencia = crud('asistencias', 'post', {'id_inscripcion': inscripcion_id, 'fecha': '2026-10-15', 'estado': 'Presente'})
        self.assertEqual(asistencia.status_code, 201, asistencia.content)
        asistencia_id = json.loads(asistencia.content)['id']
        self.assertEqual(crud('asistencias', 'put', {'estado': 'Justificada'}, asistencia_id).status_code, 200)
        self.assertEqual(crud('asistencias', 'post', {'id_inscripcion': inscripcion_id, 'fecha': '2026-10-15', 'estado': 'Presente'}).status_code, 400)
        self.assertEqual(crud('alumnos', 'put', {'observaciones': 'Seguimiento actualizado'}, inscripcion_id).status_code, 200)
        self.assertEqual(crud('alumnos', 'put', {'id_grupo': grupo_b}, inscripcion_id).status_code, 400)
        # El administrador consulta los mismos registros creados y editados por el docente.
        def registro_admin(tabla, pk):
            respuesta = catalogo(peticion(admin))
            self.assertEqual(respuesta.status_code, 200, respuesta.content)
            datos = json.loads(respuesta.content)['tablas'][tabla]
            return next(r for r in datos['registros'] if r[datos['pk']] == pk)
        self.assertEqual(registro_admin('evaluaciones', nueva_id)['nombre_evaluacion'], 'Proyecto final')
        self.assertEqual(str(registro_admin('calificaciones', nueva_nota_id)['calificacion']), '90.00')
        self.assertEqual(registro_admin('asistencias', asistencia_id)['estado'], 'Justificada')
        self.assertEqual(registro_admin('inscripciones', inscripcion_id)['observaciones'], 'Seguimiento actualizado')
        for seccion, pk in [('alumnos', inscripcion_id), ('evaluaciones', nueva_id), ('calificaciones', nueva_nota_id), ('asistencias', asistencia_id)]:
            self.assertEqual(crud(seccion, 'put', {}, pk, otro_docente).status_code, 404)
            self.assertEqual(crud(seccion, 'delete', {}, pk, otro_docente).status_code, 404)
        for seccion, pk in [('asistencias', asistencia_id), ('calificaciones', nueva_nota_id), ('evaluaciones', nueva_id)]:
            self.assertEqual(crud(seccion, 'delete', {}, pk).status_code, 200)
        self.assertFalse(m.Asistencias.objects.filter(pk=asistencia_id).exists())
        self.assertEqual(m.Calificaciones.objects.get(pk=nueva_nota_id).estado, 0)
        self.assertEqual(m.Evaluaciones.objects.get(pk=nueva_id).estado, 0)
        self.assertEqual(registro_admin('calificaciones', nueva_nota_id)['estado'], 0)
        self.assertEqual(registro_admin('evaluaciones', nueva_id)['estado'], 0)
        tablas_admin = json.loads(catalogo(peticion(admin)).content)['tablas']
        self.assertNotIn(asistencia_id, [r['id_asistencia'] for r in tablas_admin['asistencias']['registros']])
        nueva_inscripcion = crud('alumnos', 'post', {'id_alumno': alumno_id, 'id_grupo': grupo_b})
        self.assertEqual(nueva_inscripcion.status_code, 201, nueva_inscripcion.content)
        self.assertEqual(registro_admin('inscripciones', json.loads(nueva_inscripcion.content)['id'])['id_alumno'], alumno_id)
        self.assertEqual(crud('alumnos', 'delete', {}, json.loads(nueva_inscripcion.content)['id']).status_code, 200)
        self.assertTrue(m.Alumnos.objects.filter(pk=alumno_id).exists())
        # Un periodo activo con fechas anteriores sigue abierto por decisi?n del administrador.
        m.Periodos.objects.filter(pk=periodo_id).update(fecha_fin='2026-06-30')
        # Inscripci?n aut?noma: identidad del token, duplicados, cupo y visibilidad.
        respuesta = inscribirme(peticion(alumno_usuario, 'post', {'id_grupo': grupo_b, 'id_alumno': 999999}, alumno=True))
        self.assertEqual(respuesta.status_code, 201, respuesta.content)
        auto_id = json.loads(respuesta.content)['id_inscripcion']
        self.assertEqual(registro_admin('inscripciones', auto_id)['id_alumno'], alumno_id)
        self.assertEqual(inscribirme(peticion(alumno_usuario, 'post', {'id_grupo': grupo_b}, alumno=True)).status_code, 409)
        self.assertEqual(inscribirme(peticion(padre, 'post', {'id_grupo': grupo_b}, alumno=True)).status_code, 403)
        self.assertEqual(inscribirme(peticion(alumno_usuario, 'post', [], alumno=True)).status_code, 400)
        panel = json.loads(mis_cursos(peticion(alumno_usuario, alumno=True)).content)
        self.assertTrue(panel['disponibles'])
        detalle = next(c for c in panel['cursos'] if c['id_inscripcion'] == inscripcion_id)
        self.assertEqual(detalle['horarios'][0]['aula'], 'Aula 1')
        self.assertTrue(detalle['calificaciones'])
        m.Inscripciones.objects.filter(pk=auto_id).update(estado=0)
        m.Grupos.objects.filter(pk=grupo_b).update(cupo_maximo=0)
        self.assertEqual(inscribirme(peticion(alumno_usuario, 'post', {'id_grupo': grupo_b}, alumno=True)).status_code, 409)
        response = guardar(peticion(admin, 'put', {**inscripcion, 'estado': 0}), 'inscripciones', inscripcion_id)
        self.assertEqual(response.status_code, 200, response.content)
        self.assertEqual(json.loads(mis_cursos(peticion(alumno_usuario, alumno=True)).content)['cursos'], [])
        self.assertEqual(json.loads(cursos_familia(peticion(padre)).content)['cursos'], [])


if __name__ == '__main__':
    unittest.main()
