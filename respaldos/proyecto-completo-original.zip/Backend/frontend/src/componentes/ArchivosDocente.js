import { useEffect, useRef, useState } from "react";
import API from "../api/api";
import { notificarCambiosDocente } from "../api/cambiosDocente";

export default function ArchivosDocente() {
    const [revision, setRevision] = useState(null);
    const [archivos, setArchivos] = useState([]);
    const [archivo, setArchivo] = useState(null);
    const [seccion, setSeccion] = useState("Información general");
    const [mensaje, setMensaje] = useState("");
    const [ocupado, setOcupado] = useState(false);
    const [intento, setIntento] = useState(0);
    const selector = useRef(null);
    const headers = () => ({ Authorization: `Bearer ${sessionStorage.getItem("token_panel")}` });
    useEffect(() => {
        const controller = new AbortController();
        API.get("docente/archivos/", { headers: headers(), signal: controller.signal })
            .then(({ data }) => setArchivos(data.archivos))
            .catch(() => { if (!controller.signal.aborted) setMensaje("No se pudieron cargar tus archivos. Pulsa Actualizar lista."); });
        return () => controller.abort();
    }, [intento]);
    const subir = async e => {
        e.preventDefault();
        if (!archivo || ocupado) return;
        if (!/\.(xlsx|xls)$/i.test(archivo.name) || archivo.size > 10 * 1024 * 1024) {
            setMensaje("Selecciona un Excel .xlsx o .xls de hasta 10 MB."); return;
        }
        setOcupado(true); setMensaje("");
        const formulario = new FormData();
        formulario.append("archivo", archivo);
        formulario.append("seccion", seccion);
        try {
            if (seccion === "Asistencias") {
                const { data } = await API.post("docente/asistencias/revisar/", formulario, { headers: headers() });
                setRevision(data); return;
            }
            const { data } = await API.post("docente/archivos/", formulario, { headers: headers() });
            setMensaje(data.mensaje); setArchivo(null); selector.current.value = "";
            setIntento(i => i + 1);
        } catch (error) { setMensaje(error.response?.data?.mensaje || "No se pudo subir el archivo. Intenta nuevamente."); }
        finally { setOcupado(false); }
    };
    const descargar = async item => {
        setOcupado(true); setMensaje("");
        try {
            const { data } = await API.get(`docente/archivos/${item.id}/`, { headers: headers(), responseType: "blob" });
            const url = URL.createObjectURL(data);
            const enlace = document.createElement("a");
            enlace.href = url; enlace.download = item.nombre;
            document.body.appendChild(enlace); enlace.click(); enlace.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
        } catch { setMensaje("No se pudo descargar el archivo."); }
        finally { setOcupado(false); }
    };
    return <section className="docente-registros docente-crud" style={{ margin: "24px 0" }} aria-labelledby="archivos-docente">
        <h2 id="archivos-docente" className="h4" style={{ color: "#d9273e" }}>Mis archivos Excel</h2>
        <p>Selecciona Asistencias para importar registros desde un Excel .xlsx. Las otras secciones conservan el archivo sin importar sus filas.</p>
        {seccion === "Asistencias" && <div className="docente-menu-ayuda">
            <p>Primera fila: <strong>matricula | grupo | fecha | estado | observaciones</strong>. Una fila por alumno y fecha, hasta 500 registros.</p>
            <p>Fecha: AAAA-MM-DD o celda de fecha Excel. Estados: Presente, Ausente, Justificada o Retardo. Inasistencia y Falta se registran como Ausente.</p>
            <p>Usa la matrícula como texto y el nombre exacto de tu grupo. Si ya existe asistencia para esa fecha, se actualizará al confirmar.</p>
        </div>}

        <form onSubmit={subir}>
            <fieldset disabled={ocupado} className="docente-crud-formulario">
                <label>Información del archivo
                    <select value={seccion} onChange={e => { setSeccion(e.target.value); setRevision(null); }}>
                        {["Información general", "Alumnos", "Asistencias", "Calificaciones", "Evaluaciones", "Cursos y grupos", "Horarios"].map(s => <option key={s}>{s}</option>)}
                    </select>
                </label>
                <label>Archivo Excel (máximo 10 MB)
                    <input ref={selector} type="file" accept=".xlsx,.xls" required onChange={e => { setArchivo(e.target.files[0] || null); setRevision(null); }} />
                </label>
                <div className="docente-crud-formulario-acciones"><button type="submit" disabled={!archivo || ocupado}>{ocupado ? "Procesando…" : seccion === "Asistencias" ? "Revisar e importar asistencias" : "Subir archivo Excel"}</button></div>
            </fieldset>
        </form>
        {revision && <section aria-label="Revisi?n de la importaci?n" className="mt-3">
            <h3>Revisar antes de guardar</h3>
            {revision.errores.length > 0 && <div role="alert"><p>No se guardar? ninguna fila hasta corregir los errores.</p><ul>{revision.errores.map((e, i) => <li key={i}>{e}</li>)}</ul></div>}
            <div className="docente-tabla-contenedor"><table className="docente-tabla">
                <thead><tr>{["Fila", "Matr?cula", "Grupo", "Fecha", "Estado anterior", "Nuevo estado", "Observaciones", "Acci?n"].map(t => <th key={t}>{t}</th>)}</tr></thead>
                <tbody>{revision.filas.map(f => <tr key={f.fila}>{[f.fila, f.matricula, f.grupo, f.fecha, f.anterior || "Sin registro", f.estado, f.observaciones, f.accion].map((v, i) => <td key={i}>{v}</td>)}</tr>)}</tbody>
            </table></div>
            <button className="mt-3" disabled={ocupado || !revision.token} onClick={async () => {
                setOcupado(true); setMensaje("");
                try {
                    const { data } = await API.post("docente/asistencias/confirmar/", { token: revision.token }, { headers: headers() });
                    setMensaje(data.mensaje); setRevision(null); setArchivo(null); selector.current.value = "";
                    notificarCambiosDocente(); window.dispatchEvent(new Event("focus"));
                } catch (error) { setMensaje([error.response?.data?.mensaje || "No se pudo importar.", ...(error.response?.data?.errores || [])].join(" ")); }
                finally { setOcupado(false); }
            }}>Confirmar importaci?n</button>
        </section>}
        {mensaje && <p role="status" className="docente-crud-mensaje">{mensaje}</p>}
        <button type="button" className="my-3" disabled={ocupado} onClick={() => { setMensaje(""); setIntento(i => i + 1); }}>Actualizar lista</button>
        {!archivos.length ? <p>No hay archivos cargados para mostrar.</p> : <div className="docente-tabla-contenedor"><table className="docente-tabla">
            <thead><tr><th>Archivo</th><th>Sección</th><th>Fecha</th><th>Acción</th></tr></thead>
            <tbody>{archivos.map(item => <tr key={item.id}><td>{item.nombre}</td><td>{item.seccion}</td><td>{new Date(item.fecha).toLocaleString("es-MX")}</td><td><button disabled={ocupado} onClick={() => descargar(item)}>Descargar</button></td></tr>)}</tbody>
        </table></div>}
    </section>;
}
