
import { Link, useNavigate } from "react-router-dom";
import CursosInicio from "../componentes/CursosInicio";
import "./CatalogoCursos.css";

function CatalogoCursos() {
    const navigate = useNavigate();

    return (
        <div className="pagina-catalogo">

            {/* ENCABEZADO */}
            <header className="catalogo-header">
                <div className="container catalogo-header-contenido">

                    <Link
                        to="/"
                        className="catalogo-marca"
                        aria-label="Volver al inicio de Montreal"
                    >
                        <img
                            src="/montreal.jpeg"
                            alt="Logo de Institución Montreal"
                        />

                        <div>
                            <h2>Institución Montreal</h2>
                            <span>
                                Plataforma de cursos y capacitación
                            </span>
                        </div>
                    </Link>

                    <nav className="catalogo-menu">
                        <Link to="/">
                            Inicio
                        </Link>

                        <a href="#catalogo">
                            Cursos
                        </a>

                        <Link to="/conocer-montreal">
                            Conocer Montreal
                        </Link>

                        <button
                            type="button"
                            onClick={() => navigate("/login")}
                        >
                            Iniciar sesión
                        </button>
                    </nav>

                </div>
            </header>

            {/* PRESENTACIÓN */}
            <section className="catalogo-hero">
                <div className="container">

                    <span className="catalogo-etiqueta">
                        🎓 OFERTA EDUCATIVA
                    </span>

                    <h1>
                        Nuestros cursos disponibles
                    </h1>

                    <p>
                        Explora nuestra oferta de formación,
                        consulta las características de cada curso
                        y elige el que se adapte a tus objetivos.
                    </p>

                    <a
                        href="#catalogo"
                        className="catalogo-boton"
                    >
                        Explorar cursos ↓
                    </a>

                </div>
            </section>

            {/* CATÁLOGO */}
            <main id="catalogo" className="catalogo-contenido">
                <div className="container">

                    <div className="catalogo-titulo">
                        <div>
                            <h2>Catálogo de cursos</h2>
                            <p>
                                Consulta los cursos registrados en Montreal.
                            </p>
                        </div>

                        <span className="catalogo-etiqueta-secundaria">
                            Cursos disponibles
                        </span>
                    </div>

                    <CursosInicio />

                    <div className="catalogo-regreso">
                        <Link to="/" className="catalogo-volver">
                            ← Volver al inicio
                        </Link>
                    </div>

                </div>
            </main>

            {/* PIE DE PÁGINA */}
            <footer className="catalogo-footer">
                <div className="container">

                    <div className="catalogo-footer-columnas">

                        <div>
                            <h3>Institución Montreal</h3>
                            <p>
                                Educación, idiomas, tecnología y cultura.
                            </p>
                        </div>

                        <div>
                            <h4>Enlaces rápidos</h4>
                            <p>
                                <Link to="/">Inicio</Link>
                            </p>
                            <p>
                                <Link to="/cursos">Cursos</Link>
                            </p>
                            <p>
                                <Link to="/registro">Registrarse</Link>
                            </p>
                        </div>

                        <div>
                            <h4>Contacto</h4>
                            <p>
                                Atlacomulco de Fabela,
                                Estado de México.
                            </p>
                            <p>
                                <a href="mailto:atlacomulcomontreal@gmail.com">
                                    atlacomulcomontreal@gmail.com
                                </a>
                            </p>
                            <p>
                                <a
                                    href="https://wa.me/527225720866"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    WhatsApp: 722 572 0866
                                </a>
                            </p>
                        </div>

                    </div>

                    <hr />

                    <p className="catalogo-copyright">
                        © 2026 Institución Montreal.
                        Todos los derechos reservados.
                    </p>

                </div>
            </footer>

        </div>
    );
}

export default CatalogoCursos;