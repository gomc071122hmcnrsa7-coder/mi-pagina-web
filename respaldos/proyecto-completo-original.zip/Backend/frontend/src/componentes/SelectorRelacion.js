import { useState } from "react";
export default function SelectorRelacion({ id, value, onChange, opciones, required = false }) {
    const [filtro, setFiltro] = useState("");
    const normalizar = t => String(t).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const visibles = opciones.filter(o => String(o.valor) === String(value) || normalizar(o.texto).includes(normalizar(filtro)));
    return <div>
        <input className="form-control form-control-sm mb-2" type="search" placeholder="Filtrar opciones por nombre…" aria-label="Filtrar opciones" value={filtro} onChange={e => setFiltro(e.target.value)} />
        <select id={id} className="form-select" value={value ?? ""} onChange={e => onChange(e.target.value)} required={required}>
            <option value="">Selecciona una opción</option>{visibles.map(o => <option key={o.valor} value={o.valor}>{o.texto}</option>)}
        </select>{!visibles.length && <small className="text-muted">No hay opciones que coincidan.</small>}
    </div>;
}
