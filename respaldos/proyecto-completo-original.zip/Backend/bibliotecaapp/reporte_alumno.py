from io import BytesIO
from xml.sax.saxutils import escape

from django.http import FileResponse, JsonResponse
from django.utils import timezone
from django.views.decorators.http import require_GET

from .panel_alumno import alumno_autenticado, datos_cursos


def contenido(alumno):
    nombre = ' '.join(filter(None, [alumno.nombre, alumno.apellido_paterno, alumno.apellido_materno]))
    bloques = [('titulo', 'Institución Montreal'), ('subtitulo', 'Ficha académica del alumno'),
        ('texto', f'Fecha de consulta: {timezone.localtime():%d/%m/%Y %H:%M}'),
        ('texto', f'Nombre: {nombre}'), ('texto', f'Matrícula: {alumno.matricula}'),
        ('texto', f'Correo: {alumno.correo or alumno.id_usuario.email}'),
        ('texto', f'Teléfono: {alumno.telefono or "Por confirmar"}')]
    cursos = datos_cursos(alumno)['cursos']
    if not cursos:
        bloques.append(('texto', 'No hay inscripciones activas.'))
    for curso in cursos:
        bloques.extend([('subtitulo', curso['nombre_curso']),
            ('texto', f'Grupo: {curso["grupo"]} | Docente: {curso["docente"]}'),
            ('texto', f'Periodo: {curso["periodo"]} | {curso["fecha_inicio"]} a {curso["fecha_fin"]}'),
            ('texto', f'Nivel: {curso["nivel"] or "Por confirmar"}'), ('subtitulo', 'Horarios y aulas')])
        for h in curso['horarios']:
            bloques.append(('texto', f'{h["dia"]}: {h["inicio"]} a {h["fin"]} | Aula: {h["aula"]} | Ubicación: {h["ubicacion"] or "Por confirmar"}'))
        if not curso['horarios']:
            bloques.append(('texto', 'Sin horarios asignados.'))
        bloques.append(('subtitulo', 'Calificaciones'))
        for nota in curso['calificaciones']:
            bloques.append(('texto', f'{nota["evaluacion"]}: {nota["calificacion"] if nota["calificacion"] is not None else "Pendiente"} | {nota["observaciones"] or "Sin observaciones"}'))
        if not curso['calificaciones']:
            bloques.append(('texto', 'Sin calificaciones publicadas.'))
        bloques.append(('subtitulo', 'Asistencias'))
        for a in curso['asistencias']:
            bloques.append(('texto', f'{a["fecha"]}: {a["estado"] or "Por confirmar"} | {a["observaciones"] or "Sin observaciones"}'))
        if not curso['asistencias']:
            bloques.append(('texto', 'Sin asistencias registradas.'))
    bloques.append(('texto', 'Documento informativo generado con los datos registrados en la plataforma.'))
    return bloques


@require_GET
@alumno_autenticado
def descargar_ficha(request, formato):
    if formato not in ('pdf', 'docx'):
        return JsonResponse({'mensaje': 'Selecciona PDF o Word.'}, status=400)
    bloques = contenido(request.alumno)
    archivo = BytesIO()
    if formato == 'pdf':
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.pagesizes import A4
        estilos = getSampleStyleSheet()
        estilos['Title'].textColor = '#173b32'
        estilos['Heading2'].textColor = '#236b49'
        estilos['BodyText'].leading = 15
        elementos = []
        for tipo, texto in bloques:
            estilo = estilos[{'titulo': 'Title', 'subtitulo': 'Heading2', 'texto': 'BodyText'}[tipo]]
            elementos.extend([Paragraph(escape(texto).replace('\n', '<br/>'), estilo), Spacer(1, 7)])
        def pie(canvas, documento):
            canvas.setFont('Helvetica', 9)
            canvas.drawString(42, 25, 'Montreal | Ficha académica')
            canvas.drawRightString(A4[0] - 42, 25, str(documento.page))
        SimpleDocTemplate(archivo, pagesize=A4, leftMargin=42, rightMargin=42,
            topMargin=42, bottomMargin=45, title='Ficha académica Montreal').build(elementos, onFirstPage=pie, onLaterPages=pie)
        tipo_archivo = 'application/pdf'
    else:
        from docx import Document
        from docx.shared import Pt, RGBColor
        documento = Document()
        documento.styles['Normal'].font.name = 'Calibri'
        documento.styles['Normal'].font.size = Pt(11)
        for tipo, texto in bloques:
            if tipo == 'texto':
                documento.add_paragraph(texto)
            else:
                p = documento.add_heading(texto, level=0 if tipo == 'titulo' else 2)
                for run in p.runs:
                    run.font.color.rgb = RGBColor.from_string('173B32')
        documento.sections[0].footer.paragraphs[0].text = 'Institución Montreal | Ficha académica'
        documento.save(archivo)
        tipo_archivo = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    archivo.seek(0)
    return FileResponse(archivo, as_attachment=True, filename=f'ficha-alumno-{request.alumno.pk}.{formato}', content_type=tipo_archivo)
