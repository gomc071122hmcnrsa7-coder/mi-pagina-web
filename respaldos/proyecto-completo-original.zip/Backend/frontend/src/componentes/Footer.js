function Footer(){
    return(
        <footer className="bg-success text-white text-center p-3 mt-5">
            <p>Unidad Montreal © 2026 | Cursos y Capacitación</p>

        </footer>
    );
}
export default Footer;