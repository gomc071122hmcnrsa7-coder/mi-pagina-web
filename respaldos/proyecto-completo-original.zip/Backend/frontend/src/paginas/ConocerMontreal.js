import PiePagina from "../componentes/PiePagina";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import "./ConocerMontreal.css";

function ConocerMontreal() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    return (
        <div className="pagina-conocer-montreal montreal-con-pie">
            <header className="bg-dark text-white py-4">
                <div className="container d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <Link to="/" className="conocer-marca text-white text-decoration-none fs-4 fw-bold">Institución Montreal</Link>
                    <Link to="/" className="btn btn-outline-light rounded-pill conocer-volver">← Volver al inicio</Link>
                </div>
            </header>

            <main className="container py-5">
                <section className="card conocer-portada border-0 shadow-sm p-4 p-md-5 mb-4" aria-labelledby="titulo-montreal">
                    <div className="row align-items-center g-4">
                        <div className="col-md-4 text-center">
                            <img src={`${process.env.PUBLIC_URL}/montreal.jpeg`} alt="Logotipo de Institución Montreal"
                                className="img-fluid rounded-4" style={{ width: "280px", maxWidth: "100%", height: "auto" }} />
                        </div>
                        <div className="col-md-8">
                            <p className="conocer-etiqueta text-uppercase fw-bold mb-2">Conoce nuestra institución</p>
                            <h1 id="titulo-montreal" className="fw-bold">Institución Montreal</h1>
                            <p className="lead mt-3">Educación y capacitación en Atlacomulco.</p>
                            <p>En Institución Montreal encontrarás opciones de cursos y capacitación orientadas al aprendizaje y al desarrollo de nuevas habilidades.</p>
                            <p className="mb-0">Nuestra plataforma te permite explorar los cursos disponibles y consultar su descripción, nivel, duración, costo, grupos y horarios para elegir una opción de formación.</p>
                        </div>
                    </div>
                </section>

                <section className="mb-5" aria-labelledby="formacion-montreal">
                    <h2 id="formacion-montreal" className="h3 mb-4">Áreas de formación</h2>
                    <div className="row g-3">
                        {[
                            ["Idiomas", "Desarrollo de habilidades de comunicación y aprendizaje de idiomas."],
                            ["Tecnología", "Aprendizaje de herramientas digitales y conocimientos tecnológicos."],
                            ["Capacitación profesional", "Formación orientada al desarrollo de habilidades para el ámbito laboral."],
                        ].map(([titulo, descripcion]) => (
                            <div className="col-md-4" key={titulo}>
                                <article className="card conocer-area h-100 border-0 shadow-sm p-4">
                                    <h3 className="h5 fw-bold">{titulo}</h3>
                                    <p className="text-muted mb-0">{descripcion}</p>
                                </article>
                            </div>
                        ))}
                    </div>
                </section>

                <section className="card conocer-contacto border-0 shadow-sm p-4 p-md-5" aria-labelledby="contacto-montreal">
                    <h2 id="contacto-montreal" className="h3">Visítanos o contáctanos</h2>
                    <p>Circuito de Los Maestros 28, Atlacomulco de Fabela, Estado de México.</p>
                    <p className="text-muted">La ubicación es aproximada. Escríbenos para confirmar cómo llegar y consultar la oferta de cursos.</p>
                    <div className="d-flex flex-wrap gap-3">
                        <a href="mailto:atlacomulcomontreal@gmail.com" className="btn btn-outline-dark rounded-pill conocer-correo" style={{ overflowWrap: "anywhere", maxWidth: "100%" }}>atlacomulcomontreal@gmail.com</a>
                        <a href="https://wa.me/527225720866" target="_blank" rel="noopener noreferrer" className="btn btn-success rounded-pill conocer-whatsapp">
                            WhatsApp: 722 572 0866 <span className="visually-hidden">(abre una pestaña nueva)</span>
                        </a>
                    </div>
                    
                </section>
            </main>
            <PiePagina />
        </div>
    );
}

export default ConocerMontreal;
