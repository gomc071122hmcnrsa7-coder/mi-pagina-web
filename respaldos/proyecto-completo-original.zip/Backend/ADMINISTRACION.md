# Administración y asignaciones

Volver a iniciar sesión tras actualizar: el administrador, docente y padre utilizan un token firmado. La autorización de estos paneles se comprueba en el servidor.

## Flujo de asignación

1. **Usuarios**: crear la cuenta y elegir su rol. **Padres de familia** crea cuentas con rol Padre automáticamente.
2. **Alumnos / Docentes**: crear el perfil y seleccionar su cuenta de acceso. Solo se ofrecen cuentas del rol correspondiente y no vinculadas a otro perfil.
3. **Cursos** y **Periodos**: registrar la oferta y sus fechas.
4. **Grupos**: seleccionar curso, docente y periodo.
5. **Horarios**: seleccionar grupo, día y aula; elegir horas de inicio y fin.
6. **Inscripciones**: buscar alumno y grupo en los selectores y elegir fecha con el calendario del navegador.
7. **Evaluaciones**: seleccionar el grupo.
8. **Calificaciones**: seleccionar alumno, su inscripción y una evaluación del mismo grupo.
9. **Padres y alumnos**: vincular cada cuenta de padre con los alumnos que puede consultar.

No se añadió una columna redundante `id_alumno` a `calificaciones`: el alumno se obtiene de `id_inscripcion`. El formulario y la tabla muestran al alumno, y el serializador expone su ID derivado para consultas. Así no se pueden guardar dos alumnos contradictorios en una misma calificación.

Los IDs se conservan internamente y se muestran nombres en las relaciones. Las tablas permiten buscar y ordenar por encabezado. Los formularios también funcionan cuando la tabla está vacía. Las contraseñas no se incluyen en las respuestas del catálogo.

## Visibilidad

- Docentes: solo sus grupos activos, alumnos inscritos, horarios, evaluaciones, calificaciones y asistencias.
- Alumnos: sus inscripciones activas y sus datos académicos y pagos.
- Padres: únicamente los alumnos vinculados mediante relaciones activas en **Padres y alumnos**.
- Las pantallas vuelven a consultar cada 15 segundos y al recuperar el foco. No se envían notificaciones externas.
- Los registros inactivos conservan su historial. Las nuevas opciones de relaciones muestran activos y la selección histórica al editar.

## Base de datos

La migración `0002_padrealumno_padrealumno_padre_alumno_unico` agrega `padres_alumnos` y evita duplicar un vínculo. No modifica las tablas existentes de calificaciones e inscripciones.

Los materiales siguen administrándose desde el administrador de Django, como describe `PANEL_ALUMNO.md`.

## Pruebas

Desde la raíz:

```powershell
.\venv\Scripts\python.exe Backend/manage.py test bibliotecaapp
.\venv\Scripts\python.exe Backend/pruebas_gestion.py
```

La segunda prueba crea una base SQLite en memoria y verifica el flujo completo de asignación y la separación por roles, sin modificar la base real.

Desde `Backend/frontend`:

```powershell
npm.cmd test -- --watchAll=false --runInBand --runTestsByPath src/paginas/adminDatos.test.js
npm.cmd run build
```
