import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api/api";
import "./Registro.css";

function Registro() {

    const navigate = useNavigate();

    const [registrando, setRegistrando] = useState(false);
    const [nombre, setNombre] = useState("");
    const [correo, setCorreo] = useState("");
    const [telefono, setTelefono] = useState("");
    const [edad, setEdad] = useState("");
    const [password, setPassword] = useState("");
    const [confirmar, setConfirmar] = useState("");
    const [idRol, setIdRol] = useState("");
    const [rolesDisponibles, setRolesDisponibles] = useState([]);
    const [errorRoles, setErrorRoles] = useState("");

    useEffect(() => {
        let activa = true;

        API.get("roles/")
            .then(({ data }) => {
                if (!activa) return;

                const permitidos = data.filter(rol =>
                    ["alumno", "alumnos", "padre"].includes(
                        rol.nombre_rol?.trim().toLowerCase()
                    )
                );
                setRolesDisponibles(permitidos);
                setErrorRoles(
                    permitidos.length
                        ? ""
                        : "No están configurados los roles Alumno y Padre en el sistema."
                );
            })
            .catch(() => {
                if (activa) {
                    setErrorRoles("No se pudieron cargar los roles. Actualiza la página para intentarlo de nuevo.");
                }
            });

        return () => {
            activa = false;
        };
    }, []);

    const requisitos = [
        ["Entre 10 y 128 caracteres", password.length >= 10 && password.length <= 128],
        ["Una may?scula (A-Z)", /[A-Z]/.test(password)],
        ["Una min?scula (a-z)", /[a-z]/.test(password)],
        ["Un n?mero", /[0-9]/.test(password)],
        ["Un s?mbolo, por ejemplo: ! @ # $", /[^a-zA-Z0-9\s]/.test(password)],
        ["Sin espacios", password.length > 0 && !/\s/.test(password)],
    ];
    const registrar = async () => {
        if (registrando) return;

        // =========================
        // VALIDAR CAMPOS
        // =========================

        if (
            !nombre ||
            !correo ||
            !telefono ||
            !edad ||
            !password ||
            !confirmar ||
            !idRol
        ) {
            alert("Completa todos los campos");
            return;
        }

        // =========================
        // VALIDAR CONTRASEÑA
        // =========================

        if (nombre.trim().length < 2 || nombre.trim().length > 100) {
            alert("El nombre debe tener entre 2 y 100 caracteres."); return;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo.trim()) || correo.trim().length > 100) {
            alert("Ingresa un correo v?lido de hasta 100 caracteres."); return;
        }
        if (!/^[0-9]{10}$/.test(telefono)) {
            alert("El tel\u00e9fono debe contener exactamente 10 d\u00edgitos."); return;
        }
        if (!/^[0-9]+$/.test(edad) || Number(edad) < 1 || Number(edad) > 50) {
            alert("Ingresa una edad entera entre 1 y 50 a\u00f1os."); return;
        }
        if (requisitos.some(([, cumple]) => !cumple)) {
            alert("La contrase?a no cumple todos los requisitos indicados."); return;
        }
        if (password !== confirmar) {
            alert("Las contraseñas no coinciden");
            return;
        }

        // =========================
        // REGISTRAR USUARIO
        // =========================

        setRegistrando(true);
        try {

            const res = await fetch(
                "http://127.0.0.1:8000/api/registro/",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({

                        nombre: nombre,
                        correo: correo,
                        telefono: telefono,
                        edad: edad,
                        password: password,
                        confirmar: confirmar,
                        id_rol: Number(idRol)

                    })
                }
            );

            const data = await res.json();

            // =========================
            // REGISTRO EXITOSO
            // =========================

            if (data.success) {

                if (["alumno", "alumnos"].includes(data.nombre_rol?.trim().toLowerCase())) {
                    try {
                        const { data: sesion } = await API.post("login/", { correo, password });
                        if (!sesion.success || !sesion.token_alumno) throw new Error("Sin sesion");
                        sessionStorage.removeItem("token_panel");
                        sessionStorage.setItem("token_alumno", sesion.token_alumno);
                        if (sesion.token_panel) sessionStorage.setItem("token_panel", sesion.token_panel);
                        localStorage.setItem("usuario", JSON.stringify(sesion.usuario));
                        navigate("/alumno", { replace: true });
                    } catch {
                        alert("Tu cuenta fue creada. Inicia sesi\u00f3n con tu correo y contrase\u00f1a para continuar.");
                        navigate("/login", { replace: true });
                    }
                } else {
                    alert("Registro exitoso. Inicia sesi\u00f3n para continuar.");
                    navigate("/login", { replace: true });
                }

            } else {

                alert(
                    data.mensaje ||
                    "No se pudo realizar el registro."
                );

            }

        } catch (error) {

            console.error(
                "ERROR EN REGISTRO:",
                error
            );

            alert(
                "No se pudo conectar con el servidor."
            );

        } finally { setRegistrando(false); }

    };


    return (

        <div
            className="pagina-registro"
            style={{
                minHeight: "100vh",
               background:
    "linear-gradient(135deg, #173b32, #236b49)",
                display: "flex",
                flexDirection: "column",
                color: "#f5f5f5"
            }}
        >

            {/* =====================================================
                ENCABEZADO
            ====================================================== */}

            <header
                className="registro-header"
                style={{
                    background:
    "linear-gradient(135deg, #173b32, #236b49)",
                    color: "white",
                    boxShadow:
                        "0 4px 20px rgba(0,0,0,0.45)",
                    borderBottom:
                        "1px solid rgba(255,255,255,0.08)"
                }}
            >

                <div
                    className="container"
                    style={{
                        padding: "18px 20px"
                    }}
                >

                    <div
                        className="d-flex justify-content-between align-items-center"
                    >

                        {/* LOGO + NOMBRE */}

                        <div className="d-flex align-items-center">

                            <img
                                src="/montreal.jpeg"
                                alt="Institución Montreal"
                                style={{
                                    width: "68px",
                                    height: "68px",
                                    objectFit: "contain",
                                    background: "white",
                                    borderRadius: "14px",
                                    padding: "5px",
                                    marginRight: "16px",
                                    boxShadow:
                                        "0 5px 18px rgba(0,0,0,0.5)"
                                }}
                            />

                            <div>

                                <h1
                                    className="mb-1"
                                    style={{
                                        fontSize: "27px",
                                        fontWeight: "800",
                                        letterSpacing: "0.3px"
                                    }}
                                >
                                    Institución Montreal
                                </h1>

                                <p
                                    className="mb-0"
                                    style={{
                                        color: "#bdbdbd",
                                        fontSize: "14px"
                                    }}
                                >
                                    Plataforma de cursos y capacitación
                                </p>

                            </div>

                        </div>


                        {/* BOTÓN REGRESAR */}

                        <button
                            className="btn"
                            onClick={() => navigate("/")}
                            style={{
                                color: "white",
                                border:
                                    "1px solid rgba(255,255,255,0.35)",
                                borderRadius: "10px",
                                padding: "10px 18px",
                                fontWeight: "600",
                                background:
                                    "rgba(255,255,255,0.06)",
                                transition: "0.2s"
                            }}
                        >
                            ← Regresar
                        </button>

                    </div>

                </div>

            </header>


            {/* =====================================================
                CONTENIDO PRINCIPAL
            ====================================================== */}

            <main
                className="container"
                style={{
                    flex: 1,
                    paddingTop: "45px",
                    paddingBottom: "55px"
                }}
            >

                <div className="row justify-content-center">

                    <div className="col-12 col-lg-9 col-xl-8">

                        {/* TARJETA PRINCIPAL */}

                        <div
                            className="registro-tarjeta"
                            style={{
                                background: "#101010",
                                borderRadius: "24px",
                                overflow: "hidden",
                                boxShadow:
                                    "0 20px 55px rgba(0,0,0,0.55)",
                                border:
                                    "1px solid rgba(255,255,255,0.08)"
                            }}
                        >

                            {/* CABECERA DEL FORMULARIO */}

                            <div
                                className="registro-cabecera"
                                style={{
                                    background:
    "linear-gradient(135deg, #173b32, #236b49)",
                                    color: "white",
                                    padding: "35px",
                                    textAlign: "center",
                                    borderBottom:
                                        "1px solid rgba(255,255,255,0.08)"
                                }}
                            >

                                <div
                                    style={{
                                        width: "82px",
                                        height: "82px",
                                        background: "#ffffff",
                                        borderRadius: "50%",
                                        margin: "0 auto 15px",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        boxShadow:
                                            "0 8px 25px rgba(0,0,0,0.5)"
                                    }}
                                >

                                    <img
                                        src="/montreal.jpeg"
                                        alt="Montreal"
                                        style={{
                                            width: "65px",
                                            height: "65px",
                                            objectFit: "contain",
                                            borderRadius: "50%"
                                        }}
                                    />

                                </div>


                                <h2
                                    style={{
                                        fontWeight: "800",
                                        marginBottom: "8px"
                                    }}
                                >
                                    Crear una cuenta
                                </h2>

                                <p
                                    style={{
                                        margin: 0,
                                        color: "#bdbdbd"
                                    }}
                                >
                                    Regístrate para acceder a la plataforma
                                </p>

                            </div>


                            {/* FORMULARIO */}

                            <div
                                style={{
                                    padding: "35px"
                                }}
                            >

                                {/* INFORMACIÓN PERSONAL */}

                                <div className="mb-4">

                                    <h5
                                        style={{
                                            color: "#ffffff",
                                            fontWeight: "700",
                                            borderBottom:
                                                "1px solid #333333",
                                            paddingBottom: "10px"
                                        }}
                                    >
                                        👤 Información personal
                                    </h5>

                                </div>


                                <div className="row">

                                    {/* NOMBRE */}

                                    <div className="col-md-6 mb-3">

                                        <label
                                            className="form-label"
                                            style={{
                                                fontWeight: "600",
                                                color: "#dddddd"
                                            }}
                                        >
                                            Nombre completo
                                        </label>

                                        <div className="input-group">

                                            <span
                                                className="input-group-text"
                                                style={{
                                                    background: "#1b1b1b",
                                                    borderColor: "#383838",
                                                    color: "#ffffff"
                                                }}
                                            >
                                                👤
                                            </span>

                                            <input
                                                type="text"
                                                className="form-control"
                                                placeholder="Ej. Juan Pérez"
                                                value={nombre}
                                                onChange={(e) =>
                                                    setNombre(e.target.value)
                                                }
                                                style={{
                                                    background: "#181818",
                                                    color: "white",
                                                    borderColor: "#383838"
                                                }}
                                            />

                                        </div>

                                    </div>


                                    {/* CORREO */}

                                    <div className="col-md-6 mb-3">

                                        <label
                                            className="form-label"
                                            style={{
                                                fontWeight: "600",
                                                color: "#dddddd"
                                            }}
                                        >
                                            Correo electrónico
                                        </label>

                                        <div className="input-group">

                                            <span
                                                className="input-group-text"
                                                style={{
                                                    background: "#1b1b1b",
                                                    borderColor: "#383838",
                                                    color: "#ffffff"
                                                }}
                                            >
                                                ✉️
                                            </span>

                                            <input
                                                type="email"
                                                className="form-control"
                                                placeholder="correo@ejemplo.com"
                                                value={correo}
                                                onChange={(e) =>
                                                    setCorreo(e.target.value)
                                                }
                                                style={{
                                                    background: "#181818",
                                                    color: "white",
                                                    borderColor: "#383838"
                                                }}
                                            />

                                        </div>

                                    </div>


                                    {/* TELEFONO */}

                                    <div className="col-md-6 mb-3">

                                        <label
                                            className="form-label"
                                            style={{
                                                fontWeight: "600",
                                                color: "#dddddd"
                                            }}
                                        >
                                            Teléfono
                                        </label>

                                        <div className="input-group">

                                            <span
                                                className="input-group-text"
                                                style={{
                                                    background: "#1b1b1b",
                                                    borderColor: "#383838",
                                                    color: "#ffffff"
                                                }}
                                            >
                                                📱
                                            </span>

                                            <input
                                                type="text"
                                                className="form-control"
                                                placeholder="Número telefónico"
                                                inputMode="numeric"
                                                maxLength={10}
                                                pattern="[0-9]{10}"
                                                title="Ingresa exactamente 10 cifras"
                                                value={telefono}
                                                onChange={(e) =>
                                                    setTelefono(e.target.value.replace(/[^0-9]/g, "").slice(0, 10))
                                                }
                                                style={{
                                                    background: "#181818",
                                                    color: "white",
                                                    borderColor: "#383838"
                                                }}
                                            />

                                        </div>

                                    </div>


                                    {/* EDAD */}

                                    <div className="col-md-6 mb-3">

                                        <label
                                            className="form-label"
                                            style={{
                                                fontWeight: "600",
                                                color: "#dddddd"
                                            }}
                                        >
                                            Edad
                                        </label>

                                        <div className="input-group">

                                            <span
                                                className="input-group-text"
                                                style={{
                                                    background: "#1b1b1b",
                                                    borderColor: "#383838",
                                                    color: "#ffffff"
                                                }}
                                            >
                                                🎂
                                            </span>

                                            <input
                                                type="number"
                                                className="form-control"
                                                min={1}
                                                max={50}
                                                step={1}
                                                placeholder="Edad (1 a 50)"
                                                value={edad}
                                                onChange={(e) =>
                                                    setEdad(/^[0-9]{0,2}$/.test(e.target.value) && (e.target.value === "" || (Number(e.target.value) >= 1 && Number(e.target.value) <= 50)) ? e.target.value : edad)
                                                }
                                                style={{
                                                    background: "#181818",
                                                    color: "white",
                                                    borderColor: "#383838"
                                                }}
                                            />

                                        </div>

                                    </div>


                                    {/* ROL */}

                                    <div className="col-12 mb-4">

                                        <label
                                            className="form-label"
                                            style={{
                                                fontWeight: "600",
                                                color: "#dddddd"
                                            }}
                                        >
                                            Tipo de usuario
                                        </label>

                                        <div className="input-group">

                                            <span
                                                className="input-group-text"
                                                style={{
                                                    background: "#1b1b1b",
                                                    borderColor: "#383838",
                                                    color: "#ffffff"
                                                }}
                                            >
                                                🎓
                                            </span>

                                            <select
                                                className="form-select"
                                                value={idRol}
                                                onChange={(e) =>
                                                    setIdRol(e.target.value)
                                                }
                                                style={{
                                                    backgroundColor: "#181818",
                                                    color: "white",
                                                    borderColor: "#383838"
                                                }}
                                            >

                                                <option value="">
                                                    Selecciona tu rol
                                                </option>

                                                {rolesDisponibles.map(rol => (
                                                    <option key={rol.id_rol} value={rol.id_rol}>
                                                        {rol.nombre_rol.trim().toLowerCase() === "padre"
                                                            ? "Padre y/o tutor"
                                                            : "Alumno"}
                                                    </option>
                                                ))}

                                            </select>

                                        </div>
                                        {errorRoles && (
                                            <div className="form-text text-danger" role="alert">
                                                {errorRoles}
                                            </div>
                                        )}

                                    </div>

                                </div>


                                {/* SEGURIDAD */}

                                <div className="mb-4">

                                    <h5
                                        style={{
                                            color: "#ffffff",
                                            fontWeight: "700",
                                            borderBottom:
                                                "1px solid #333333",
                                            paddingBottom: "10px"
                                        }}
                                    >
                                        🔐 Seguridad de la cuenta
                                    </h5>

                                </div>


                                <div className="row">

                                    {/* CONTRASEÑA */}

                                    <div className="col-md-6 mb-3">

                                        <label
                                            className="form-label"
                                            style={{
                                                fontWeight: "600",
                                                color: "#dddddd"
                                            }}
                                        >
                                            Contraseña
                                        </label>

                                        <div className="input-group">

                                            <span
                                                className="input-group-text"
                                                style={{
                                                    background: "#1b1b1b",
                                                    borderColor: "#383838",
                                                    color: "#ffffff"
                                                }}
                                            >
                                                🔒
                                            </span>

                                            <input
                                                type="password"
                                                autoComplete="new-password"
                                                minLength={10}
                                                maxLength={128}
                                                className="form-control"
                                                placeholder="Crea una contraseña"
                                                aria-describedby="requisitos-password"
                                                value={password}
                                                onChange={(e) =>
                                                    setPassword(e.target.value)
                                                }
                                                style={{
                                                    background: "#181818",
                                                    color: "white",
                                                    borderColor: "#383838"
                                                }}
                                            />

                                        </div>

                                    </div>


                                    <div className="col-12 mb-3" id="requisitos-password">
                                        <strong>Requisitos de la contrase?a</strong>
                                        <ul className="mb-0">{requisitos.map(([texto, cumple]) => <li key={texto}>{cumple ? "?" : "?"} {texto}</li>)}</ul>
                                        {confirmar && password !== confirmar && <p role="status">Las contrase?as todav?a no coinciden.</p>}
                                    </div>
                                    {/* CONFIRMAR */}

                                    <div className="col-md-6 mb-3">

                                        <label
                                            className="form-label"
                                            style={{
                                                fontWeight: "600",
                                                color: "#dddddd"
                                            }}
                                        >
                                            Confirmar contraseña
                                        </label>

                                        <div className="input-group">

                                            <span
                                                className="input-group-text"
                                                style={{
                                                    background: "#1b1b1b",
                                                    borderColor: "#383838",
                                                    color: "#ffffff"
                                                }}
                                            >
                                                🔒
                                            </span>

                                            <input
                                                type="password"
                                                autoComplete="new-password"
                                                minLength={10}
                                                maxLength={128}
                                                className="form-control"
                                                placeholder="Repite tu contraseña"
                                                value={confirmar}
                                                onChange={(e) =>
                                                    setConfirmar(e.target.value)
                                                }
                                                style={{
                                                    background: "#181818",
                                                    color: "white",
                                                    borderColor: "#383838"
                                                }}
                                            />

                                        </div>

                                    </div>

                                </div>


                                {/* INFORMACIÓN */}

                                <div
                                    className="alert mt-3"
                                    style={{
                                        background: "#181818",
                                        border:
                                            "1px solid #333333",
                                        color: "#bdbdbd",
                                        borderRadius: "12px"
                                    }}
                                >

                                    🔐 Tu información será utilizada
                                    exclusivamente para gestionar tu
                                    cuenta dentro de la plataforma.

                                </div>


                                {/* BOTONES */}

                                <div
                                    className="d-flex flex-column flex-md-row gap-3 mt-4"
                                >

                                    <button
                                        type="button"
                                        className="btn btn-lg flex-fill"
                                        onClick={registrar}
                                        disabled={registrando}
                                        style={{
                                            background:
    "linear-gradient(135deg, #173b32, #236b49)",
                                            color: "#080808",
                                            border: "none",
                                            borderRadius: "12px",
                                            fontWeight: "800",
                                            padding: "13px",
                                            boxShadow:
                                                "0 8px 20px rgba(0,0,0,0.3)"
                                        }}
                                    >
                                        ✓ Crear mi cuenta
                                    </button>


                                    <button
                                        type="button"
                                        className="btn btn-lg"
                                        onClick={() => navigate("/")}
                                        style={{
                                            borderRadius: "12px",
                                            padding: "13px 28px",
                                            color: "#dddddd",
                                            border:
                                                "1px solid #444444",
                                            background: "#181818"
                                        }}
                                    >
                                        Cancelar
                                    </button>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </main>


            {/* =====================================================
                PIE DE PÁGINA
            ====================================================== */}

            <footer
                style={{
                   background:
    "linear-gradient(135deg, #173b32, #236b49)",
                    color: "white",
                    textAlign: "center",
                    padding: "25px",
                    borderTop:
                        "1px solid rgba(255,255,255,0.08)"
                }}
            >

                <p
                    className="mb-1"
                    style={{
                        fontWeight: "700"
                    }}
                >
                    Institución Montreal
                </p>

                <p
                    className="mb-1"
                    style={{
                        color: "#bdbdbd"
                    }}
                >
                    Educación y capacitación profesional
                </p>

                <p
                    className="mb-0"
                    style={{
                        color: "#777777",
                        fontSize: "14px"
                    }}
                >
                    © 2026 Todos los derechos reservados
                </p>

            </footer>

        </div>

    );

}

export default Registro;
