﻿from django.db import models

class Curso(models.Model):
    nombre = models.CharField(max_length=100)
    horario = models.CharField(max_length=100)
    costo = models.CharField(max_length=50)

    class Meta:
        db_table = 'cursos'

    def __str__(self):
        return self.nombre