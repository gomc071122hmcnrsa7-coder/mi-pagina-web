import PiePagina from "../componentes/PiePagina";

import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../api/api";
import imagenCurso from "../utils/imagenCurso";

function Cursos() {
    const navigate = useNavigate();
    const [cursos, setCursos] = useState([]);
    const [estado, setEstado] = useState("cargando");
    const [intento, setIntento] = useState(0);

    useEffect(() => {
        const controller = new AbortController();

        setEstado("cargando");

        API.get("cursos-completos/", {
            signal: controller.signal
        })
            .then(({ data }) => {
                if (controller.signal.aborted) return;

                // Mostrar una sola tarjeta por curso.
                const cursosUnicos = [
                    ...new Map(
                        data.map(curso => [curso.id_curso, curso])
                    ).values()
                ];

                setCursos(cursosUnicos);
                setEstado("listo");
            })
            .catch(() => {
                if (!controller.signal.aborted) {
                    setEstado("error");
                }
            });

        return () => controller.abort();
    }, [intento]);

    return (
        <div className="montreal-con-pie"
            style={{
                minHeight: "100vh",
                backgroundColor: "#e5eee5",
                color: "#294538"
            }}
        >
            <header
                style={{
                    backgroundColor: "#173b32",
                    color: "#ffffff",
                    padding: "20px 0"
                }}
            >
                <div className="container d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <div className="d-flex align-items-center gap-3">
                        <img
                            src="/montreal.jpeg"
                            alt="Logo Institución Montreal"
                            style={{
                                width: "55px",
                                height: "55px",
                                objectFit: "contain",
                                backgroundColor: "#ffffff",
                                borderRadius: "10px",
                                padding: "4px"
                            }}
                        />

                        <div>
                            <h1 className="h4 fw-bold mb-1">
                                Catálogo de cursos
                            </h1>
                            <p className="mb-0" style={{ color: "#dcebdc" }}>
                                Institución Montreal
                            </p>
                        </div>
                    </div>

                    <button
                        className="btn rounded-pill px-4"
                        style={{
                            backgroundColor: "#d9ead7",
                            color: "#244c37"
                        }}
                        onClick={() => navigate("/")}
                    >
                        ← Volver al inicio
                    </button>
                </div>
            </header>

            <section className="container py-5">
                <div className="mb-4">
                    <h2 className="fw-bold">Nuestros cursos</h2>
                    <p style={{ color: "#60796a" }}>
                        Explora las opciones de formación disponibles
                        en Institución Montreal.
                    </p>
                </div>

                {estado === "cargando" && (
                    <p role="status">Cargando cursos...</p>
                )}

                {estado === "error" && (
                    <div role="alert" className="card p-4">
                        <p>No se pudieron cargar los cursos.</p>
                        <button
                            className="btn btn-success"
                            onClick={() => setIntento(valor => valor + 1)}
                        >
                            Reintentar
                        </button>
                    </div>
                )}

                {estado === "listo" && cursos.length === 0 && (
                    <div className="card p-4">
                        <h3 className="h5">Todavía no hay cursos disponibles</h3>
                        <p className="mb-0">
                            Los cursos aparecerán aquí cuando estén
                            disponibles en el sistema.
                        </p>
                    </div>
                )}

                {estado === "listo" && cursos.length > 0 && (
                    <div className="row g-4">
                        {cursos.map(curso => (
                            <div
                                className="col-12 col-md-6 col-lg-4"
                                key={curso.id_curso}
                            >
                                <article
                                    className="card h-100 border-0 shadow-sm"
                                    style={{
                                        borderRadius: "18px",
                                        overflow: "hidden",
                                        backgroundColor: "#f0f5e9",
                                        border: "1px solid #cbdccb"
                                    }}
                                >
                                    <img
                                        src={imagenCurso(curso.nombre_curso)}
                                        alt={`Ilustración del curso ${curso.nombre_curso}`}
                                        loading="lazy"
                                        width="640"
                                        height="360"
                                        style={{
                                            width: "100%",
                                            height: "200px",
                                            objectFit: "cover"
                                        }}
                                    />

                                    <div className="card-body p-4">
                                        {curso.nivel && (
                                            <span
                                                className="badge mb-2"
                                                style={{
                                                    backgroundColor: "#d9ead7",
                                                    color: "#244c37"
                                                }}
                                            >
                                                {curso.nivel}
                                            </span>
                                        )}

                                        <h3 className="h5 fw-bold">
                                            {curso.nombre_curso}
                                        </h3>

                                        <p style={{ color: "#60796a" }}>
                                            {curso.descripcion ||
                                                "Consulta la información de este curso."}
                                        </p>

                                        <Link
                                            className="btn rounded-pill"
                                            style={{
                                                backgroundColor: "#236b49",
                                                color: "#ffffff"
                                            }}
                                            to={`/cursos/${curso.id_curso}`}
                                        >
                                            Ver curso →
                                        </Link>
                                    </div>
                                </article>
                            </div>
                        ))}
                    </div>
                )}
            </section>
            <PiePagina />
        </div>
    );
}

export default Cursos;