export const mismo = (a, b) => String(a ?? "") === String(b ?? "");
export const buscar = (tablas, tabla, id) => tablas[tabla]?.registros.find(r => mismo(r[tablas[tabla].pk], id));
const nombre = r => [r.nombre, r.apellido_paterno, r.apellido_materno].filter(Boolean).join(" ");
export function textoRegistro(tablas, tabla, r) {
    if (!r) return "Sin asignar";
    if (tabla === "entidades") return r.nombre_entidad;
    const etiqueta = (t, id) => textoRegistro(tablas, t, buscar(tablas, t, id));
    if (tabla === "alumnos") return `${nombre(r)} · ${r.matricula}`;
    if (tabla === "docentes") return nombre(r);
    if (["usuarios", "padres"].includes(tabla)) return `${r.nombre_usuario} · ${r.email}`;
    if (tabla === "grupos") return `${r.nombre_grupo} · ${etiqueta("cursos", r.id_curso)} · ${etiqueta("docentes", r.id_docente)}`;
    if (tabla === "inscripciones") return `${etiqueta("alumnos", r.id_alumno)} / ${etiqueta("grupos", r.id_grupo)}`;
    if (tabla === "evaluaciones") return `${r.nombre_evaluacion} · ${etiqueta("grupos", r.id_grupo)}`;
    return r.nombre_curso || r.nombre_periodo || r.nombre_aula || r.nombre_dia || r.nombre_rol || nombre(r) || "Registro";
}
export function opcionesRelacion(tablas, tabla, campo, datos, registro, alumnoFiltro) {
    let opciones = tablas[campo.relacion]?.registros || [];
    if (campo.nombre === "id_usuario" && ["alumnos", "docentes"].includes(tabla)) {
        const rol = tabla === "alumnos" ? "Alumno" : "Docente";
        opciones = opciones.filter(u => {
            const nombreRol = buscar(tablas, "roles", u.id_rol)?.nombre_rol?.trim().toLowerCase();
            const rolCorrecto = tabla === "alumnos"
                ? ["alumno", "alumnos"].includes(nombreRol)
                : nombreRol === rol.toLowerCase();
            const yaVinculada = (tablas[tabla]?.registros || []).some(r =>
                mismo(r.id_usuario, u.id_usuario) &&
                !mismo(r[tablas[tabla].pk], registro?.[tablas[tabla].pk])
            );
            return rolCorrecto && !yaVinculada;
        });
    }
    if (campo.nombre === "id_inscripcion" && alumnoFiltro) opciones = opciones.filter(i => mismo(i.id_alumno, alumnoFiltro));
    if (campo.nombre === "id_evaluacion") {
        const inscripcion = buscar(tablas, "inscripciones", datos.id_inscripcion);
        opciones = opciones.filter(e => inscripcion && mismo(e.id_grupo, inscripcion.id_grupo));
    }
    return opciones.filter(r => r.estado === undefined || Number(r.estado) === 1 || mismo(r[tablas[campo.relacion].pk], datos[campo.nombre]))
        .map(r => ({ valor: r[tablas[campo.relacion].pk], texto: textoRegistro(tablas, campo.relacion, r) })).sort((a, b) => a.texto.localeCompare(b.texto, "es"));
}
export function valorTabla(tablas, campo, registro) {
    const valor = registro[campo.nombre];
    if (valor === null || valor === undefined || valor === "") return "—";
    if (campo.relacion) return textoRegistro(tablas, campo.relacion, buscar(tablas, campo.relacion, valor));
    return campo.opciones?.find(o => mismo(o.valor, valor))?.texto ?? String(valor);
}
