import { Link } from "react-router-dom";
import "./PiePagina.css";

export default function PiePagina() {
    return <footer className="montreal-pie">
        <div className="container montreal-pie-contenido">
            <div>
                <strong>Institución Montreal</strong>
                <p>Educación y capacitación</p>
            </div>
            <nav aria-label="Enlaces del pie de página">
                <Link to="/">Inicio</Link>
                <Link to="/conocer-montreal">Conocer Montreal</Link>
                <Link to="/mision-vision">Misión y visión</Link>
            </nav>
            <address>
                <a href="mailto:atlacomulcomontreal@gmail.com">Correo: atlacomulcomontreal@gmail.com</a>
                <a href="https://wa.me/527225720866" target="_blank" rel="noopener noreferrer">WhatsApp: 722 572 0866</a>
            </address>
        </div>
        <div className="container montreal-pie-legal">© {new Date().getFullYear()} Institución Montreal. Todos los derechos reservados.</div>
    </footer>;
}
