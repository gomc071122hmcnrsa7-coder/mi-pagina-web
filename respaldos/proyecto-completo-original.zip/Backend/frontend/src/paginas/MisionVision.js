import { useEffect } from "react";
import { Link } from "react-router-dom";
import "./Inicio.css";
import "./MisionVision.css";

export default function MisionVision() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    return (
        <div className="pagina-mision-vision">
            <header className="text-white py-4">
                <div className="container d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <Link to="/" className="text-white text-decoration-none fs-4 fw-bold">Institución Montreal</Link>
                    <Link to="/" className="btn btn-outline-light rounded-pill">← Volver al inicio</Link>
                </div>
            </header>

            <main className="container py-5">
                <section className="card mision-portada p-4 p-md-5 mb-4" aria-labelledby="titulo-mision-vision">
                    <div className="row align-items-center g-4">
                        <div className="col-md-3 text-center">
                            <img src={`${process.env.PUBLIC_URL}/montreal.jpeg`} alt="Logotipo de Institución Montreal"
                                className="img-fluid rounded-4" width="200" style={{ maxWidth: "100%", height: "auto" }} />
                        </div>
                        <div className="col-md-9">
                            <p className="text-uppercase fw-bold mb-2">Nuestra institución</p>
                            <h1 id="titulo-mision-vision" className="fw-bold">Misión y visión</h1>
                            <p className="lead mb-0">Educación, idiomas y capacitación para el desarrollo personal y profesional.</p>
                        </div>
                    </div>
                </section>

                {/* Propuesta de redacción basada en las áreas de formación del proyecto. */}
                <div className="row g-4">
                    <div className="col-md-6">
                        <section className="card h-100 p-4 p-md-5" aria-labelledby="mision">
                            <h2 id="mision" className="fw-bold mb-3">Misión</h2>
                            <p className="mb-0" style={{ lineHeight: 1.9 }}>
                                Contribuir a la formación de nuestros alumnos mediante cursos de idiomas,
                                tecnología y capacitación profesional que les permitan desarrollar
                                conocimientos y habilidades para su vida cotidiana y laboral.
                                Promover el aprendizaje continuo, la responsabilidad y el respeto,
                                acompañando a cada estudiante en su proceso de formación.
                            </p>
                        </section>
                    </div>
                    <div className="col-md-6">
                        <section className="card h-100 p-4 p-md-5" aria-labelledby="vision">
                            <h2 id="vision" className="fw-bold mb-3">Visión</h2>
                            <p className="mb-0" style={{ lineHeight: 1.9 }}>
                                Ser una institución reconocida en Atlacomulco y su región por su
                                compromiso con la educación y el desarrollo de sus estudiantes.
                                Ampliar las oportunidades de formación mediante propuestas educativas
                                que respondan a las necesidades de la comunidad y el uso de herramientas
                                tecnológicas que faciliten el acceso al aprendizaje.
                            </p>
                        </section>
                    </div>
                </div>
                <div className="mt-4 text-center">
                    <Link to="/conocer-montreal" className="btn btn-dark rounded-pill px-4">Conocer más sobre Montreal</Link>
                </div>
            </main>
            <footer className="text-center py-4">Institución Montreal · Educación y capacitación</footer>
        </div>
    );
}
