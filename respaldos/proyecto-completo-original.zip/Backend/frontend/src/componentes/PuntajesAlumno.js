import { valorAlumno } from "../paginas/alumnoTablas";

export default function PuntajesAlumno({ curso }) {
    const notas = Array.isArray(curso.calificaciones) ? curso.calificaciones : [];
    return <section className="card border-0 shadow-sm p-4 mb-4" aria-labelledby="puntajes-alumno">
        <h3 id="puntajes-alumno" className="h4">Mi puntaje asignado</h3>
        <p>Consulta el puntaje registrado por la institución para cada evaluación de tu curso. Los cambios del administrador o docente se actualizan automáticamente.</p>
        {!notas.length ? <p role="status">Todavía no tienes puntajes publicados para este curso.</p> : <div className="table-responsive">
            <table className="table align-middle">
                <caption>Puntajes de {curso.nombre_curso} · Grupo {curso.grupo}</caption>
                <thead><tr><th scope="col">Evaluación</th><th scope="col">Puntaje asignado</th><th scope="col">Estado</th><th scope="col">Observaciones</th></tr></thead>
                <tbody>{notas.map((nota, indice) => {
                    const puntaje = valorAlumno("calificacion", nota?.calificacion);
                    const estado = puntaje === "Pendiente" ? "Pendiente de asignación" : puntaje === "Dato inválido" ? "Requiere revisión" : "Asignado";
                    return <tr key={indice}>
                        <th scope="row">{valorAlumno("evaluacion", nota?.evaluacion)}</th>
                        <td><strong>{puntaje}</strong></td>
                        <td>{estado}</td>
                        <td>{valorAlumno("observaciones", nota?.observaciones)}</td>
                    </tr>;
                })}</tbody>
            </table>
        </div>}
    </section>;
}
