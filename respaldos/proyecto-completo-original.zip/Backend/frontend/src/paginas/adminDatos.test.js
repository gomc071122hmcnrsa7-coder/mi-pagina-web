import { buscar, opcionesRelacion, textoRegistro } from "./adminDatos";

const tablas = {
    roles: { pk: "id_rol", registros: [{ id_rol: 1, nombre_rol: "Docente" }, { id_rol: 2, nombre_rol: "Alumno" }] },
    usuarios: { pk: "id_usuario", registros: [{ id_usuario: 5, id_rol: 1, nombre_usuario: "Docente", email: "d@example.com", estado: 1 }, { id_usuario: 6, id_rol: 2, nombre_usuario: "Ana", email: "a@example.com", estado: 1 }] },
    alumnos: { pk: "id_alumno", registros: [{ id_alumno: 10, nombre: "Ana", matricula: "M10", id_usuario: 6 }] },
    docentes: { pk: "id_docente", registros: [] },
    cursos: { pk: "id_curso", registros: [{ id_curso: 1, nombre_curso: "Inglés" }] },
    grupos: { pk: "id_grupo", registros: [{ id_grupo: 20, nombre_grupo: "Grupo A", id_curso: 1 }] },
    inscripciones: { pk: "id_inscripcion", registros: [{ id_inscripcion: 30, id_alumno: 10, id_grupo: 20, estado: 1 }, { id_inscripcion: 31, id_alumno: 11, id_grupo: 21, estado: 1 }] },
    evaluaciones: { pk: "id_evaluacion", registros: [{ id_evaluacion: 40, nombre_evaluacion: "Examen A", id_grupo: 20, estado: 1 }, { id_evaluacion: 41, nombre_evaluacion: "Examen B", id_grupo: 21, estado: 1 }] },
};

test("filtra inscripciones por alumno sin confundir IDs numéricos y texto", () => {
    const opciones = opcionesRelacion(tablas, "calificaciones", { nombre: "id_inscripcion", relacion: "inscripciones" }, {}, null, "10");
    expect(opciones.map(o => o.valor)).toEqual([30]);
    expect(opciones[0].texto).toContain("Ana");
});
test("solo ofrece evaluaciones del grupo de la inscripción seleccionada", () => {
    expect(opcionesRelacion(tablas, "calificaciones", { nombre: "id_evaluacion", relacion: "evaluaciones" }, { id_inscripcion: "30" }, null, "10").map(o => o.valor)).toEqual([40]);
});
test("no ofrece evaluaciones antes de seleccionar inscripción", () => {
    expect(opcionesRelacion(tablas, "calificaciones", { nombre: "id_evaluacion", relacion: "evaluaciones" }, {}, null, "10")).toEqual([]);
});
test("las cuentas docentes se filtran por rol", () => {
    expect(opcionesRelacion(tablas, "docentes", { nombre: "id_usuario", relacion: "usuarios" }, {}, null, "").map(o => o.valor)).toEqual([5]);
});
test("las cuentas con rol Alumnos plural se ofrecen para el perfil de alumno", () => {
    const tablasConRolPlural = {
        ...tablas,
        roles: { ...tablas.roles, registros: [...tablas.roles.registros, { id_rol: 3, nombre_rol: "Alumnos" }] },
        usuarios: { ...tablas.usuarios, registros: [...tablas.usuarios.registros, { id_usuario: 7, id_rol: 3, nombre_usuario: "Luis", email: "l@example.com", estado: 1 }] },
        alumnos: { ...tablas.alumnos, registros: [] },
    };
    expect(opcionesRelacion(tablasConRolPlural, "alumnos", { nombre: "id_usuario", relacion: "usuarios" }, {}, null, "").map(o => o.valor)).toContain(7);
});
test("una cuenta de alumno ya vinculada no se ofrece para otro perfil", () => {
    expect(opcionesRelacion(tablas, "alumnos", { nombre: "id_usuario", relacion: "usuarios" }, {}, null, "")).toEqual([]);
});
test("editar conserva la cuenta asociada al mismo alumno", () => {
    expect(opcionesRelacion(tablas, "alumnos", { nombre: "id_usuario", relacion: "usuarios" }, { id_usuario: 6 }, tablas.alumnos.registros[0], "").map(o => o.valor)).toEqual([6]);
});
test("las etiquetas muestran nombres y matrícula", () => {
    expect(textoRegistro(tablas, "alumnos", buscar(tablas, "alumnos", "10"))).toBe("Ana · M10");
});
