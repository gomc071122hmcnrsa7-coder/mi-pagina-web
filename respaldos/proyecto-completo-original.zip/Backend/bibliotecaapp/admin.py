from django.contrib import admin
from django import forms
from django.core.files.storage import default_storage
from django.utils import timezone
from uuid import uuid4

from .models import MaterialCurso
from .models import Certificaciones, EntidadesCertificadoras


class ConstanciaForm(forms.ModelForm):
    pdf = forms.FileField(required=False, label='Constancia en PDF')

    class Meta:
        model = Certificaciones
        exclude = ('url_certificado', 'created_at')

    def clean_pdf(self):
        archivo = self.cleaned_data.get('pdf')
        if archivo:
            cabecera = archivo.read(5)
            archivo.seek(0)
            if not archivo.name.lower().endswith('.pdf') or cabecera != b'%PDF-':
                raise forms.ValidationError('Selecciona un archivo PDF válido.')
        return archivo


@admin.register(Certificaciones)
class ConstanciaAdmin(admin.ModelAdmin):
    form = ConstanciaForm
    list_display = ('folio_certificado', 'id_inscripcion', 'fecha_certificacion', 'estado')
    search_fields = ('folio_certificado', 'id_inscripcion__id_alumno__nombre', 'id_inscripcion__id_alumno__matricula')
    list_filter = ('estado', 'fecha_certificacion')

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        campo = super().formfield_for_foreignkey(db_field, request, **kwargs)
        if db_field.name == 'id_inscripcion':
            campo.queryset = campo.queryset.select_related('id_alumno', 'id_grupo__id_curso')
            campo.label_from_instance = lambda i: f'{i.id_alumno.matricula} · {i.id_alumno.nombre} {i.id_alumno.apellido_paterno} · {i.id_grupo.id_curso.nombre_curso} · {i.id_grupo.nombre_grupo}'
        elif db_field.name == 'id_entidad':
            campo.label_from_instance = lambda e: e.nombre_entidad
        return campo

    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_at = timezone.now()
        archivo = form.cleaned_data.get('pdf')
        if archivo:
            obj.url_certificado = default_storage.save(f'constancias/{uuid4().hex}.pdf', archivo)
        super().save_model(request, obj, form, change)


admin.site.register(EntidadesCertificadoras)


@admin.register(MaterialCurso)
class MaterialCursoAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'curso', 'publicado', 'orden')
    list_filter = ('publicado', 'curso')
    search_fields = ('titulo', 'curso__nombre_curso')

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        field = super().formfield_for_foreignkey(db_field, request, **kwargs)
        if db_field.name == 'curso':
            field.label_from_instance = lambda curso: curso.nombre_curso
        return field
