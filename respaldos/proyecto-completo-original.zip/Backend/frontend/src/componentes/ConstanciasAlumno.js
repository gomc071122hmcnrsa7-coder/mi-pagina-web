import { useEffect, useRef, useState } from "react";
import API from "../api/api";

export default function ConstanciasAlumno() {
    const [constancias, setConstancias] = useState([]);
    const [cargando, setCargando] = useState(true);
    const [mensaje, setMensaje] = useState("");
    const [intento, setIntento] = useState(0);
    const [ocupado, setOcupado] = useState(false);
    const [vista, setVista] = useState(null);
    const urls = useRef(new Set());
    const montado = useRef(true);
    useEffect(() => {
        montado.current = true;
        const activas = urls.current;
        return () => { montado.current = false; activas.forEach(url => URL.revokeObjectURL(url)); activas.clear(); };
    }, []);
    useEffect(() => {
        const controller = new AbortController();
        const cargar = async () => {
            try {
                const { data } = await API.get("alumno/constancias/", {
                    signal: controller.signal,
                    headers: { Authorization: `Bearer ${sessionStorage.getItem("token_alumno")}` },
                });
                if (!controller.signal.aborted) setConstancias(data.constancias);
            } catch (error) {
                if (!controller.signal.aborted) setMensaje(error.response?.data?.mensaje || "No se pudieron cargar tus constancias. Pulsa Actualizar.");
            } finally { if (!controller.signal.aborted) setCargando(false); }
        };
        cargar();
        const intervalo = setInterval(cargar, 15000);
        return () => { controller.abort(); clearInterval(intervalo); };
    }, [intento]);

    const cerrar = () => {
        if (vista) { URL.revokeObjectURL(vista.url); urls.current.delete(vista.url); }
        setVista(null);
    };
    const abrir = async (constancia, consultar) => {
        setOcupado(true); setMensaje(""); cerrar();
        try {
            const { data } = await API.get(`alumno/constancias/${constancia.id}/archivo/`, {
                params: consultar ? { ver: 1 } : {}, responseType: "blob",
                headers: { Authorization: `Bearer ${sessionStorage.getItem("token_alumno")}` },
            });
            if (!montado.current) return;
            const url = URL.createObjectURL(data);
            urls.current.add(url);
            if (consultar) setVista({ url, nombre: constancia.curso });
            else {
                const enlace = document.createElement("a");
                enlace.href = url; enlace.download = `constancia-${constancia.id}.pdf`;
                document.body.appendChild(enlace); enlace.click(); enlace.remove();
                setTimeout(() => { URL.revokeObjectURL(url); urls.current.delete(url); }, 1000);
            }
        } catch {
            if (montado.current) setMensaje("No se pudo abrir la constancia. Actualiza la lista o vuelve a iniciar sesión.");
        } finally { if (montado.current) setOcupado(false); }
    };

    return <section className="card p-4 my-4" aria-labelledby="mis-constancias">
        <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h3 id="mis-constancias" className="h4 mb-0">Mis constancias</h3>
            <button className="btn btn-outline-success" disabled={ocupado} onClick={() => { setMensaje(""); setIntento(i => i + 1); }}>Actualizar</button>
        </div>
        <p>Consulta y descarga las constancias que la institución haya emitido a tu nombre.</p>
        {mensaje && <p role="alert" className="alert alert-warning">{mensaje}</p>}
        {cargando ? <p role="status">Cargando constancias…</p> : !constancias.length && !mensaje && <p>Aún no tienes constancias emitidas.</p>}
        {constancias.map(c => <article key={c.id} className="border-top pt-3 mb-3">
            <h4 className="h5">{c.curso}</h4>
            <dl className="row">
                <div className="col-sm-6"><dt>Folio</dt><dd>{c.folio || "Por asignar"}</dd></div>
                <div className="col-sm-6"><dt>Grupo</dt><dd>{c.grupo}</dd></div>
                <div className="col-sm-6"><dt>Fecha de emisión</dt><dd>{c.fecha || "Por confirmar"}</dd></div>
                <div className="col-sm-6"><dt>Entidad certificadora</dt><dd>{c.entidad}</dd></div>
                {c.vencimiento && <div className="col-sm-6"><dt>Vencimiento</dt><dd>{c.vencimiento}</dd></div>}
            </dl>
            {c.disponible ? <div className="d-flex flex-wrap gap-2">
                <button className="btn btn-outline-success" disabled={ocupado} onClick={() => abrir(c, true)}>Consultar constancia</button>
                <button className="btn btn-success" disabled={ocupado} onClick={() => abrir(c, false)}>Descargar PDF</button>
            </div> : <p>El archivo PDF está pendiente de publicación por la institución.</p>}
        </article>)}
        {ocupado && <p role="status">Abriendo constancia…</p>}
        {vista && <div className="mt-3">
            <button className="btn btn-outline-success mb-2" onClick={cerrar}>Cerrar vista previa</button>
            <iframe title={`Constancia de ${vista.nombre}`} src={vista.url} style={{ width: "100%", height: "65vh", border: "1px solid #cbdccb" }} />
        </div>}
    </section>;
}
