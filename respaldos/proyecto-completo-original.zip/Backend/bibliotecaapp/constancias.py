from pathlib import PurePosixPath

from django.core.files.storage import default_storage
from django.http import FileResponse, JsonResponse, Http404
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_GET

from .models import Certificaciones
from .panel_alumno import alumno_autenticado
from .acceso import requiere_rol
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from uuid import uuid4


@csrf_exempt
@require_POST
@requiere_rol('Administrador')
def subir_constancia(request, constancia_id):
    constancia = get_object_or_404(Certificaciones, pk=constancia_id)
    archivo = request.FILES.get('archivo')
    if not archivo or not archivo.name.lower().endswith('.pdf') or archivo.size > 10 * 1024 * 1024:
        return JsonResponse({'mensaje': 'Selecciona un PDF de hasta 10 MB.'}, status=400)
    cabecera = archivo.read(5)
    archivo.seek(0)
    if cabecera != b'%PDF-':
        return JsonResponse({'mensaje': 'El archivo no es un PDF válido.'}, status=400)
    ruta = default_storage.save(f'constancias/{uuid4().hex}.pdf', archivo)
    try:
        constancia.url_certificado = ruta
        constancia.save(update_fields=['url_certificado'])
    except Exception:
        default_storage.delete(ruta)
        raise
    return JsonResponse({'mensaje': 'PDF guardado. El alumno podrá descargarlo si la constancia está activa.'})


def propias(alumno):
    return Certificaciones.objects.filter(id_inscripcion__id_alumno=alumno, estado=1)


def ruta_pdf(valor):
    ruta = PurePosixPath(valor or '')
    if ruta.is_absolute() or '..' in ruta.parts or '\\' in str(ruta):
        return None
    if not str(ruta).startswith('constancias/') or ruta.suffix.lower() != '.pdf':
        return None
    return str(ruta)


@require_GET
@alumno_autenticado
def mis_constancias(request):
    registros = propias(request.alumno).select_related('id_inscripcion__id_grupo__id_curso', 'id_entidad').order_by('-fecha_certificacion', '-pk')
    return JsonResponse({'constancias': [{
        'id': c.pk, 'curso': c.id_inscripcion.id_grupo.id_curso.nombre_curso,
        'grupo': c.id_inscripcion.id_grupo.nombre_grupo,
        'folio': c.folio_certificado, 'fecha': c.fecha_certificacion,
        'vencimiento': c.fecha_vencimiento, 'entidad': c.id_entidad.nombre_entidad,
        'disponible': bool(ruta_pdf(c.url_certificado) and default_storage.exists(ruta_pdf(c.url_certificado))),
    } for c in registros]})


@require_GET
@alumno_autenticado
def archivo_constancia(request, constancia_id):
    constancia = get_object_or_404(propias(request.alumno), pk=constancia_id)
    ruta = ruta_pdf(constancia.url_certificado)
    if not ruta or not default_storage.exists(ruta):
        raise Http404('El PDF de esta constancia aún no está disponible.')
    try:
        archivo = default_storage.open(ruta, 'rb')
    except FileNotFoundError:
        raise Http404('Archivo no disponible.')
    respuesta = FileResponse(archivo, content_type='application/pdf',
        as_attachment=request.GET.get('ver') != '1', filename=f'constancia-{constancia.pk}.pdf')
    respuesta['X-Content-Type-Options'] = 'nosniff'
    return respuesta
