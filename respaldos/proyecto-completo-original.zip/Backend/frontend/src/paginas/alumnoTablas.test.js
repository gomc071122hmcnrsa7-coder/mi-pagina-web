import { fechaTabla, horaTabla, valorAlumno } from "./alumnoTablas";

test("valida fechas reales y mantiene el día sin cambios de zona horaria", () => {
    expect(fechaTabla("2026-10-22")).toBe("22/10/2026");
    expect(fechaTabla("2026-02-30")).toBe("Fecha inválida");
    expect(fechaTabla(null)).toBe("Por confirmar");
    expect(horaTabla("25:15:00")).toBe("Por confirmar");
});
test("no convierte valores vacíos o inválidos en calificaciones o pagos", () => {
    expect(valorAlumno("calificacion", null)).toBe("Pendiente");
    expect(valorAlumno("calificacion", 0)).toBe("0");
    expect(valorAlumno("calificacion", 101)).toBe("Dato inválido");
    expect(valorAlumno("monto", -10)).toBe("Dato inválido");
    expect(valorAlumno("porcentaje", "25")).toBe("25 %");
    expect(valorAlumno("estado", "desconocido")).toBe("Estado por revisar");
});
