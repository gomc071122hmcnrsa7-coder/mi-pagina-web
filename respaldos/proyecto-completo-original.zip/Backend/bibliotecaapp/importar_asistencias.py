import json
from datetime import date, datetime
from zipfile import ZipFile
from django.core import signing
from django.utils import timezone
from django.db import transaction
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from openpyxl import load_workbook
from .acceso import requiere_rol
from .models import Inscripciones, Asistencias

ESTADOS = {e.lower(): e for e in ('Presente', 'Ausente', 'Justificada', 'Retardo')}
ESTADOS.update({'inasistencia': 'Ausente', 'falta': 'Ausente'})


def validar_filas(filas, usuario):
    errores, validas, vistos = [], [], set()
    for numero, fila in enumerate(filas, 2):
        try:
            matricula, grupo, fecha, estado, observaciones = fila
            if not isinstance(matricula, str) or not matricula.strip():
                raise ValueError('La matrícula debe estar escrita como texto.')
            if isinstance(fecha, datetime):
                fecha = fecha.date()
            if not isinstance(fecha, date):
                fecha = date.fromisoformat(str(fecha))
            if fecha > timezone.localdate():
                raise ValueError('No se permiten fechas futuras.')
            estado = ESTADOS.get(str(estado).strip().lower())
            if not estado:
                raise ValueError('Estado válido: Presente, Ausente, Justificada o Retardo.')
            inscripciones = list(Inscripciones.objects.filter(estado=1,
                id_alumno__matricula=matricula.strip(), id_alumno__estado=1,
                id_grupo__nombre_grupo=str(grupo).strip(), id_grupo__estado=1,
                id_grupo__id_docente__id_usuario=usuario, id_grupo__id_docente__estado=1)[:2])
            if len(inscripciones) != 1:
                raise ValueError('No se encontró una inscripción única del alumno en un grupo asignado a ti.')
            inscripcion = inscripciones[0]
            clave = (inscripcion.pk, fecha.isoformat())
            if clave in vistos:
                raise ValueError('Alumno y fecha repetidos en el archivo.')
            vistos.add(clave)
            existentes = list(Asistencias.objects.filter(id_inscripcion=inscripcion, fecha=fecha)[:2])
            if len(existentes) > 1:
                raise ValueError('Existen asistencias duplicadas; solicita su corrección antes de importar.')
            observaciones = str(observaciones or '').strip()
            if len(observaciones) > 1000:
                raise ValueError('Las observaciones exceden 1000 caracteres.')
            validas.append({'fila': numero, 'matricula': matricula.strip(), 'grupo': str(grupo).strip(),
                'fecha': fecha.isoformat(), 'estado': estado, 'observaciones': observaciones,
                'id_inscripcion': inscripcion.pk, 'anterior': existentes[0].estado if existentes else None,
                'accion': 'Actualizar' if existentes else 'Crear'})
        except (ValueError, TypeError) as error:
            errores.append(f'Fila {numero}: {error}')
    return validas, errores


@csrf_exempt
@require_POST
@requiere_rol('Docente')
def revisar_asistencias(request):
    archivo = request.FILES.get('archivo')
    if not archivo or not archivo.name.lower().endswith('.xlsx') or archivo.size > 10 * 1024 * 1024:
        return JsonResponse({'mensaje': 'La importación requiere un .xlsx de hasta 10 MB.'}, status=400)
    try:
        with ZipFile(archivo) as zip_excel:
            if sum(i.file_size for i in zip_excel.infolist()) > 30 * 1024 * 1024:
                raise ValueError('El libro es demasiado grande.')
        archivo.seek(0)
        libro = load_workbook(archivo, read_only=True, data_only=False, keep_links=False)
        try:
            hoja = libro.active
            if hoja.max_row > 501 or hoja.max_column > 5:
                raise ValueError('Usa hasta 500 registros y las cinco columnas indicadas.')
            filas = list(hoja.iter_rows(values_only=True))
        finally:
            libro.close()
        esperadas = ['matricula', 'grupo', 'fecha', 'estado', 'observaciones']
        if not filas or [str(c or '').strip().lower() for c in filas[0]] != esperadas:
            raise ValueError('Encabezados requeridos: matricula, grupo, fecha, estado, observaciones.')
        filas = [list(f) for f in filas[1:] if any(v is not None for v in f)]
        if not filas:
            raise ValueError('El archivo no contiene registros.')
        if any(isinstance(v, str) and v.startswith('=') for f in filas for v in f):
            raise ValueError('Usa valores, no fórmulas, en las celdas.')
    except Exception as error:
        return JsonResponse({'mensaje': str(error) if isinstance(error, ValueError) else 'No se pudo leer el Excel. Revisa su formato.'}, status=400)
    validas, errores = validar_filas(filas, request.usuario_panel)
    token = None
    if not errores:
        datos = [[r[c] for c in esperadas] for r in validas]
        token = signing.dumps({'usuario': request.usuario_panel.pk, 'filas': datos}, salt='importar-asistencias', compress=True)
    return JsonResponse({'filas': validas, 'errores': errores, 'token': token})


@csrf_exempt
@require_POST
@requiere_rol('Docente')
def confirmar_asistencias(request):
    try:
        datos = signing.loads(json.loads(request.body)['token'], salt='importar-asistencias', max_age=900)
        if datos['usuario'] != request.usuario_panel.pk:
            raise ValueError()
    except (ValueError, TypeError, KeyError, signing.BadSignature):
        return JsonResponse({'mensaje': 'La revisión venció o no es válida. Vuelve a revisar el Excel.'}, status=400)
    with transaction.atomic():
        list(Inscripciones.objects.select_for_update().filter(id_grupo__id_docente__id_usuario=request.usuario_panel).order_by('pk'))
        filas, errores = validar_filas(datos['filas'], request.usuario_panel)
        if errores:
            return JsonResponse({'mensaje': 'No se importó ninguna fila.', 'errores': errores}, status=400)
        for fila in filas:
            Asistencias.objects.update_or_create(id_inscripcion_id=fila['id_inscripcion'], fecha=fila['fecha'],
                defaults={'estado': fila['estado'], 'observaciones': fila['observaciones']})
    return JsonResponse({'mensaje': f'Importación exitosa: {len(filas)} asistencias guardadas.'})
