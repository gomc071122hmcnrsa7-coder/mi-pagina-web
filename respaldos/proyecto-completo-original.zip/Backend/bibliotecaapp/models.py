from django.db import models
from django.core.validators import FileExtensionValidator


class ArchivoDocente(models.Model):
    id = models.AutoField(primary_key=True)
    docente = models.ForeignKey('Docentes', on_delete=models.PROTECT)
    archivo = models.FileField(upload_to='docentes/excel/%Y/%m/')
    nombre = models.CharField(max_length=255)
    seccion = models.CharField(max_length=100)
    creado = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'archivos_docente'
        ordering = ['-creado', '-pk']


class MaterialCurso(models.Model):
    id = models.AutoField(primary_key=True)
    curso = models.ForeignKey('Cursos', on_delete=models.PROTECT, related_name='materiales')
    titulo = models.CharField(max_length=180)
    contenido = models.TextField(blank=True, help_text='Texto o instrucciones para el alumno.')
    archivo = models.FileField(
        upload_to='materiales/%Y/%m/', blank=True,
        validators=[FileExtensionValidator(['pdf', 'txt', 'png', 'jpg', 'jpeg', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'zip', 'mp4', 'mp3'])],
    )
    publicado = models.BooleanField(default=True)
    orden = models.PositiveIntegerField(default=0)
    creado = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'materiales_curso'
        ordering = ['orden', 'id']
        verbose_name = 'material de curso'
        verbose_name_plural = 'materiales de cursos'

    def __str__(self):
        return self.titulo


class PadreAlumno(models.Model):
    id = models.AutoField(primary_key=True)
    padre = models.ForeignKey('Usuarios', on_delete=models.PROTECT)
    alumno = models.ForeignKey('Alumnos', on_delete=models.PROTECT)
    parentesco = models.CharField(max_length=30, default='Padre')
    estado = models.IntegerField(default=1)

    class Meta:
        db_table = 'padres_alumnos'
        constraints = [models.UniqueConstraint(fields=['padre', 'alumno'], name='padre_alumno_unico')]


class Alumnos(models.Model):
    id_alumno = models.AutoField(primary_key=True)
    id_usuario = models.OneToOneField('Usuarios', models.DO_NOTHING, db_column='id_usuario', blank=True, null=True)
    matricula = models.CharField(unique=True, max_length=30)
    nombre = models.CharField(max_length=100)
    apellido_paterno = models.CharField(max_length=100)
    apellido_materno = models.CharField(max_length=100, blank=True, null=True)
    fecha_nacimiento = models.DateField(blank=True, null=True)
    sexo = models.CharField(max_length=20, blank=True, null=True)
    telefono = models.CharField(max_length=20, blank=True, null=True)
    correo = models.CharField(unique=True, max_length=100, blank=True, null=True)
    direccion = models.TextField(blank=True, null=True)
    fecha_registro = models.DateTimeField()
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'alumnos'


class Asistencias(models.Model):
    id_asistencia = models.AutoField(primary_key=True)
    id_inscripcion = models.ForeignKey('Inscripciones', models.DO_NOTHING, db_column='id_inscripcion')
    fecha = models.DateField()
    estado = models.CharField(max_length=20, blank=True, null=True)
    observaciones = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'asistencias'


class Aulas(models.Model):
    id_aula = models.AutoField(primary_key=True)
    nombre_aula = models.CharField(max_length=100)
    capacidad = models.IntegerField(blank=True, null=True)
    ubicacion = models.CharField(max_length=255, blank=True, null=True)
    descripcion = models.TextField(blank=True, null=True)
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'aulas'


class Calificaciones(models.Model):
    id_calificacion = models.AutoField(primary_key=True)
    id_evaluacion = models.ForeignKey('Evaluaciones', models.DO_NOTHING, db_column='id_evaluacion')
    id_inscripcion = models.ForeignKey('Inscripciones', models.DO_NOTHING, db_column='id_inscripcion')
    calificacion = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    observaciones = models.TextField(blank=True, null=True)
    fecha_registro = models.DateTimeField()
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'calificaciones'


class Certificaciones(models.Model):
    id_certificacion = models.AutoField(primary_key=True)
    id_inscripcion = models.ForeignKey('Inscripciones', models.DO_NOTHING, db_column='id_inscripcion')
    id_entidad = models.ForeignKey('EntidadesCertificadoras', models.DO_NOTHING, db_column='id_entidad')
    fecha_certificacion = models.DateField(blank=True, null=True)
    fecha_vencimiento = models.DateField(blank=True, null=True)
    calificacion_final = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    folio_certificado = models.CharField(unique=True, max_length=100, blank=True, null=True)
    url_certificado = models.CharField(max_length=255, blank=True, null=True)
    observaciones = models.TextField(blank=True, null=True)
    estado = models.IntegerField(blank=True, null=True)
    created_at = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'certificaciones'


class Cursos(models.Model):
    id_curso = models.AutoField(primary_key=True)
    nombre_curso = models.CharField(max_length=100)
    descripcion = models.TextField(blank=True, null=True)
    duracion_horas = models.IntegerField(blank=True, null=True)
    costo = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    nivel = models.CharField(max_length=50, blank=True, null=True)
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'cursos'


class Dias(models.Model):
    id_dia = models.AutoField(primary_key=True)
    nombre_dia = models.CharField(max_length=20)
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dias'


class Docentes(models.Model):
    id_docente = models.AutoField(primary_key=True)
    id_usuario = models.OneToOneField('Usuarios', models.DO_NOTHING, db_column='id_usuario', blank=True, null=True)
    nombre = models.CharField(max_length=100)
    apellido_paterno = models.CharField(max_length=100)
    apellido_materno = models.CharField(max_length=100, blank=True, null=True)
    especialidad = models.CharField(max_length=100, blank=True, null=True)
    telefono = models.CharField(max_length=20, blank=True, null=True)
    correo = models.CharField(unique=True, max_length=100, blank=True, null=True)
    fecha_contratacion = models.DateField(blank=True, null=True)
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'docentes'


class EntidadesCertificadoras(models.Model):
    id_entidad = models.AutoField(primary_key=True)
    nombre_entidad = models.CharField(unique=True, max_length=150)
    descripcion = models.TextField(blank=True, null=True)
    telefono = models.CharField(max_length=20, blank=True, null=True)
    correo = models.CharField(max_length=100, blank=True, null=True)
    sitio_web = models.CharField(max_length=255, blank=True, null=True)
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'entidades_certificadoras'


class Evaluaciones(models.Model):
    id_evaluacion = models.AutoField(primary_key=True)
    id_grupo = models.ForeignKey('Grupos', models.DO_NOTHING, db_column='id_grupo')
    nombre_evaluacion = models.CharField(max_length=100)
    tipo_evaluacion = models.CharField(max_length=50, blank=True, null=True)
    porcentaje = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    fecha = models.DateField(blank=True, null=True)
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'evaluaciones'


class Grupos(models.Model):
    id_grupo = models.AutoField(primary_key=True)
    id_curso = models.ForeignKey(Cursos, models.DO_NOTHING, db_column='id_curso')
    id_docente = models.ForeignKey(Docentes, models.DO_NOTHING, db_column='id_docente')
    id_periodo = models.ForeignKey('Periodos', models.DO_NOTHING, db_column='id_periodo')
    nombre_grupo = models.CharField(max_length=100)
    cupo_maximo = models.IntegerField(blank=True, null=True)
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'grupos'


class Horarios(models.Model):
    id_horario = models.AutoField(primary_key=True)
    id_grupo = models.ForeignKey(Grupos, models.DO_NOTHING, db_column='id_grupo')
    id_dia = models.ForeignKey(Dias, models.DO_NOTHING, db_column='id_dia')
    id_aula = models.ForeignKey(Aulas, models.DO_NOTHING, db_column='id_aula')
    hora_inicio = models.TimeField()
    hora_fin = models.TimeField()
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'horarios'


class Inscripciones(models.Model):
    id_inscripcion = models.AutoField(primary_key=True)
    id_alumno = models.ForeignKey(Alumnos, models.DO_NOTHING, db_column='id_alumno')
    id_grupo = models.ForeignKey(Grupos, models.DO_NOTHING, db_column='id_grupo')
    fecha_inscripcion = models.DateField()
    estado = models.IntegerField(blank=True, null=True)
    observaciones = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'inscripciones'


class Pagos(models.Model):
    id_pago = models.AutoField(primary_key=True)
    id_inscripcion = models.ForeignKey(Inscripciones, models.DO_NOTHING, db_column='id_inscripcion')
    fecha_pago = models.DateField()
    monto = models.DecimalField(max_digits=10, decimal_places=2)
    metodo_pago = models.CharField(max_length=50, blank=True, null=True)
    concepto = models.CharField(max_length=100, blank=True, null=True)
    folio = models.CharField(unique=True, max_length=50, blank=True, null=True)
    moneda = models.CharField(max_length=10, blank=True, null=True)
    estado = models.IntegerField(blank=True, null=True)
    observaciones = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'pagos'


class Periodos(models.Model):
    id_periodo = models.AutoField(primary_key=True)
    nombre_periodo = models.CharField(max_length=100)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'periodos'


class Roles(models.Model):
    id_rol = models.AutoField(primary_key=True)
    nombre_rol = models.CharField(max_length=50)
    descripcion = models.CharField(max_length=255, blank=True, null=True)
    estado = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'roles'


class Usuarios(models.Model):
    id_usuario = models.AutoField(primary_key=True)
    id_rol = models.ForeignKey(Roles, models.DO_NOTHING, db_column='id_rol')
    nombre_usuario = models.CharField(max_length=100)
    email = models.CharField(unique=True, max_length=100)
    password_hash = models.CharField(max_length=255)
    estado = models.IntegerField(blank=True, null=True)
    fecha_creacion = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'usuarios'
 
