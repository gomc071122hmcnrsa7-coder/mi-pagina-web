from functools import wraps
from django.core import signing
from django.http import JsonResponse
from .models import Usuarios


def _normalizar_rol(nombre):
    rol = nombre.strip().casefold()
    return 'alumno' if rol in {'alumno', 'alumnos'} else rol


def requiere_rol(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(request, *args, **kwargs):
            authorization = request.headers.get('Authorization', '')
            try:
                if not authorization.startswith('Bearer '):
                    raise signing.BadSignature()
                datos = signing.loads(authorization[7:], salt='panel-roles', max_age=28800)
                usuario = Usuarios.objects.select_related('id_rol').filter(pk=datos['id_usuario'], estado=1).first()
            except (signing.BadSignature, KeyError, TypeError):
                return JsonResponse({'mensaje': 'Inicia sesión nuevamente.'}, status=401)
            if not usuario or _normalizar_rol(usuario.id_rol.nombre_rol) not in {
                _normalizar_rol(rol) for rol in roles
            }:
                return JsonResponse({'mensaje': 'No tienes permiso para consultar esta información.'}, status=403)
            request.usuario_panel = usuario
            response = view(request, *args, **kwargs)
            response['Cache-Control'] = 'private, no-store'
            return response
        return wrapped
    return decorator
