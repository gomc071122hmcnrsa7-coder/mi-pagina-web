import json
from django.db import transaction
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from .models import Cursos, Grupos, Usuarios
from uuid import uuid4
from functools import wraps
from pathlib import Path
import mimetypes

from django.core import signing
from django.db.models import Q
from django.http import FileResponse, JsonResponse, Http404
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_GET

from .models import Alumnos, Inscripciones, Horarios, MaterialCurso, Calificaciones, Pagos, Asistencias, Evaluaciones, PadreAlumno
from .acceso import requiere_rol


def completar_perfil_alumno(usuario_id):
    # Bloquear la cuenta evita crear dos perfiles al recibir peticiones simult?neas.
    with transaction.atomic():
        usuario = Usuarios.objects.select_for_update().filter(pk=usuario_id, estado=1).select_related('id_rol').first()
        if usuario is None or usuario.id_rol.nombre_rol.strip().casefold() not in {'alumno', 'alumnos'}:
            return None
        existente = Alumnos.objects.filter(id_usuario=usuario).first()
        if existente is not None:
            return existente if existente.estado == 1 else None
        matricula = f'MTL-{usuario.pk}'
        if Alumnos.objects.filter(matricula=matricula).exists():
            matricula = f'MTL-{uuid4().hex[:24]}'
        return Alumnos.objects.create(id_usuario=usuario, matricula=matricula,
            nombre=usuario.nombre_usuario[:100], apellido_paterno='',
            fecha_registro=timezone.now(), estado=1)


def alumno_autenticado(view):
    @wraps(view)
    def wrapped(request, *args, **kwargs):
        authorization = request.headers.get('Authorization', '')
        if not authorization.startswith('Bearer '):
            return JsonResponse({'mensaje': 'Inicia sesión para consultar tus cursos.'}, status=401)
        try:
            datos = signing.loads(authorization[7:], salt='panel-alumno', max_age=8 * 60 * 60)
            usuario_id = datos['id_usuario']
        except (signing.BadSignature, KeyError, TypeError):
            return JsonResponse({'mensaje': 'Tu sesión venció. Inicia sesión nuevamente.'}, status=401)
        alumno = Alumnos.objects.filter(
            Q(id_usuario__id_rol__nombre_rol__iexact='Alumno') |
            Q(id_usuario__id_rol__nombre_rol__iexact='Alumnos'),
            id_usuario_id=usuario_id, estado=1,
            id_usuario__estado=1,
        ).first()
        if alumno is None:
            alumno = completar_perfil_alumno(usuario_id)
        if alumno is None:
            return JsonResponse({'mensaje': 'No hay un perfil de alumno activo asociado a esta cuenta.'}, status=403)
        request.alumno = alumno
        response = view(request, *args, **kwargs)
        response['Cache-Control'] = 'private, no-store'
        return response
    return wrapped


def inscripciones_de(alumno):
    return Inscripciones.objects.filter(id_alumno=alumno, estado=1)


@require_GET
@alumno_autenticado
def mis_cursos(request):
    datos = datos_cursos(request.alumno)
    datos['disponibles'] = cursos_disponibles(request.alumno)
    return JsonResponse(datos)


def datos_cursos(alumno):
    inscripciones = inscripciones_de(alumno).select_related(
        'id_grupo__id_curso', 'id_grupo__id_docente', 'id_grupo__id_periodo',
    ).order_by('id_grupo__id_curso__nombre_curso', 'id_inscripcion')
    resultado = []
    for inscripcion in inscripciones:
        grupo = inscripcion.id_grupo
        curso = grupo.id_curso
        docente = grupo.id_docente
        periodo = grupo.id_periodo
        horarios = Horarios.objects.filter(id_grupo=grupo, estado=1).select_related('id_dia', 'id_aula').order_by('id_dia', 'hora_inicio')
        materiales = MaterialCurso.objects.filter(curso=curso, publicado=True)
        resultado.append({
            'id_inscripcion': inscripcion.pk, 'id_curso': curso.pk,
            'nombre_curso': curso.nombre_curso, 'descripcion': curso.descripcion,
            'duracion_horas': curso.duracion_horas, 'nivel': curso.nivel,
            'grupo': grupo.nombre_grupo,
            'docente': ' '.join(filter(None, [docente.nombre, docente.apellido_paterno, docente.apellido_materno])),
            'periodo': periodo.nombre_periodo,
            'fecha_inicio': periodo.fecha_inicio, 'fecha_fin': periodo.fecha_fin,
            'horarios': [{
                'id': horario.pk, 'dia': horario.id_dia.nombre_dia,
                'inicio': horario.hora_inicio, 'fin': horario.hora_fin,
                'aula': horario.id_aula.nombre_aula, 'ubicacion': horario.id_aula.ubicacion,
            } for horario in horarios],
            'materiales': [{
                'id': material.pk, 'titulo': material.titulo, 'contenido': material.contenido,
                'archivo': Path(material.archivo.name).name if material.archivo else None,
            } for material in materiales],
            'calificaciones': [{'evaluacion': nota.id_evaluacion.nombre_evaluacion, 'calificacion': nota.calificacion, 'observaciones': nota.observaciones}
                               for nota in Calificaciones.objects.filter(id_inscripcion=inscripcion, estado=1).select_related('id_evaluacion')],
            'pagos': list(Pagos.objects.filter(id_inscripcion=inscripcion, estado=1).values('fecha_pago', 'monto', 'moneda', 'concepto')),
            'asistencias': list(Asistencias.objects.filter(id_inscripcion=inscripcion).values('fecha', 'estado', 'observaciones')),
            'evaluaciones': list(Evaluaciones.objects.filter(id_grupo=grupo, estado=1).values('nombre_evaluacion', 'tipo_evaluacion', 'porcentaje', 'fecha')),
        })
    return {'alumno': {'nombre': alumno.nombre, 'matricula': alumno.matricula}, 'cursos': resultado}


@require_GET
@requiere_rol('Padre')
def cursos_familia(request):
    vinculos = PadreAlumno.objects.filter(padre=request.usuario_panel, estado=1, alumno__estado=1).select_related('alumno')
    cursos = []
    for vinculo in vinculos:
        datos = datos_cursos(vinculo.alumno)
        for curso in datos['cursos']:
            curso['alumno_nombre'] = ' '.join(filter(None, [vinculo.alumno.nombre, vinculo.alumno.apellido_paterno, vinculo.alumno.apellido_materno]))
            cursos.append(curso)
    return JsonResponse({'alumno': {'nombre': request.usuario_panel.nombre_usuario, 'matricula': 'Familia'}, 'cursos': cursos})


@require_GET
@alumno_autenticado
def archivo_material(request, material_id):
    material = get_object_or_404(MaterialCurso, pk=material_id, publicado=True)
    if not inscripciones_de(request.alumno).filter(id_grupo__id_curso_id=material.curso_id).exists():
        raise Http404('Material no disponible')
    return entregar_archivo(request, material)


@require_GET
@requiere_rol('Padre')
def archivo_familia(request, material_id):
    material = get_object_or_404(MaterialCurso, pk=material_id, publicado=True)
    alumnos = PadreAlumno.objects.filter(padre=request.usuario_panel, estado=1, alumno__estado=1).values('alumno_id')
    if not Inscripciones.objects.filter(id_alumno_id__in=alumnos, estado=1, id_grupo__id_curso_id=material.curso_id).exists():
        raise Http404('Material no disponible')
    return entregar_archivo(request, material)


def entregar_archivo(request, material):
    if not material.archivo:
        raise Http404('Este contenido no tiene archivo adjunto')
    try:
        archivo = material.archivo.open('rb')
    except FileNotFoundError:
        raise Http404('Archivo no disponible')
    nombre = Path(material.archivo.name).name
    tipo = mimetypes.guess_type(nombre)[0] or 'application/octet-stream'
    # Solo estos formatos se permiten en vista previa; los demás se descargan.
    vista_previa = request.GET.get('ver') == '1' and tipo in {'application/pdf', 'text/plain', 'image/png', 'image/jpeg', 'audio/mpeg', 'video/mp4'}
    response = FileResponse(archivo, as_attachment=not vista_previa, filename=nombre, content_type=tipo)
    response['X-Content-Type-Options'] = 'nosniff'
    return response


def grupos_disponibles():
    # El administrador controla la apertura mediante el estado del grupo y periodo.
    # Las fechas se muestran al alumno, pero no sustituyen ese estado.
    return Grupos.objects.filter(estado=1, id_curso__estado=1,
        id_docente__estado=1, id_periodo__estado=1)


def cursos_disponibles(alumno):
    resultado = []
    inscritos = set(inscripciones_de(alumno).values_list('id_grupo_id', flat=True))
    for curso in Cursos.objects.filter(estado=1).order_by('nombre_curso'):
        grupos = []
        for grupo in grupos_disponibles().filter(id_curso=curso).select_related('id_docente', 'id_periodo'):
            ocupados = Inscripciones.objects.filter(id_grupo=grupo, estado=1).count()
            grupos.append({
                'id': grupo.pk, 'nombre': grupo.nombre_grupo,
                'docente': ' '.join(filter(None, [grupo.id_docente.nombre, grupo.id_docente.apellido_paterno, grupo.id_docente.apellido_materno])),
                'periodo': grupo.id_periodo.nombre_periodo,
                'inicio': grupo.id_periodo.fecha_inicio, 'fin': grupo.id_periodo.fecha_fin,
                'inscrito': grupo.pk in inscritos,
                'lugares': None if grupo.cupo_maximo is None else max(0, grupo.cupo_maximo - ocupados),
                'horarios': [{'dia': h.id_dia.nombre_dia, 'inicio': h.hora_inicio, 'fin': h.hora_fin,
                    'aula': h.id_aula.nombre_aula, 'ubicacion': h.id_aula.ubicacion} for h in Horarios.objects.filter(id_grupo=grupo, estado=1).select_related('id_dia', 'id_aula')],
            })
        resultado.append({'id': curso.pk, 'nombre': curso.nombre_curso, 'descripcion': curso.descripcion,
                          'duracion_horas': curso.duracion_horas, 'costo': curso.costo,
                          'nivel': curso.nivel, 'grupos': grupos})
    return resultado


@csrf_exempt
@require_POST
@alumno_autenticado
def inscribirme(request):
    try:
        datos = json.loads(request.body)
        grupo_id = int(datos['id_grupo'])
    except (ValueError, TypeError, KeyError):
        return JsonResponse({'mensaje': 'Selecciona un grupo válido.'}, status=400)
    with transaction.atomic():
        grupo = grupos_disponibles().select_for_update().filter(pk=grupo_id).first()
        if grupo is None:
            return JsonResponse({'mensaje': 'Este grupo ya no está disponible.'}, status=400)
        if inscripciones_de(request.alumno).filter(id_grupo=grupo).exists():
            return JsonResponse({'mensaje': 'Ya estás inscrito en este grupo.'}, status=409)
        if grupo.cupo_maximo is not None and Inscripciones.objects.filter(id_grupo=grupo, estado=1).count() >= grupo.cupo_maximo:
            return JsonResponse({'mensaje': 'Este grupo ya no tiene lugares disponibles.'}, status=409)
        inscripcion = Inscripciones.objects.create(id_alumno=request.alumno, id_grupo=grupo,
            fecha_inscripcion=timezone.localdate(), estado=1)
    return JsonResponse({'mensaje': 'Inscripción realizada correctamente.', 'id_inscripcion': inscripcion.pk}, status=201)
