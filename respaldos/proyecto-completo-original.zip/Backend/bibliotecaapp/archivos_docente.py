from pathlib import Path
from uuid import uuid4
from zipfile import ZipFile, BadZipFile

from django.http import JsonResponse, FileResponse, Http404
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods, require_GET

from .acceso import requiere_rol
from .models import ArchivoDocente, Docentes

SECCIONES = ('Alumnos', 'Asistencias', 'Calificaciones', 'Evaluaciones', 'Cursos y grupos', 'Horarios', 'Información general')


@csrf_exempt
@require_http_methods(['GET', 'POST'])
@requiere_rol('Docente')
def archivos_docente(request):
    docente = get_object_or_404(Docentes, id_usuario=request.usuario_panel, estado=1)
    if request.method == 'GET':
        return JsonResponse({'archivos': [{'id': a.pk, 'nombre': a.nombre,
            'seccion': a.seccion, 'fecha': a.creado} for a in ArchivoDocente.objects.filter(docente=docente)]})
    archivo = request.FILES.get('archivo')
    seccion = request.POST.get('seccion', 'Información general')
    if not archivo or seccion not in SECCIONES:
        return JsonResponse({'mensaje': 'Selecciona un archivo Excel y una sección válida.'}, status=400)
    extension = Path(archivo.name).suffix.lower()
    if extension not in ('.xlsx', '.xls') or archivo.size > 10 * 1024 * 1024:
        return JsonResponse({'mensaje': 'Se permiten archivos .xlsx o .xls de hasta 10 MB.'}, status=400)
    valido = False
    try:
        if extension == '.xlsx':
            with ZipFile(archivo) as libro:
                valido = {'[Content_Types].xml', 'xl/workbook.xml'}.issubset(libro.namelist())
        else:
            valido = archivo.read(8) == b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'
    except (BadZipFile, OSError):
        pass
    finally:
        archivo.seek(0)
    if not valido:
        return JsonResponse({'mensaje': 'El archivo no tiene un formato Excel válido.'}, status=400)
    registro = ArchivoDocente(docente=docente, nombre=Path(archivo.name).name[:255], seccion=seccion)
    registro.archivo.save(f'{uuid4().hex}{extension}', archivo, save=False)
    try:
        registro.save()
    except Exception:
        registro.archivo.delete(save=False)
        raise
    return JsonResponse({'mensaje': 'Archivo Excel guardado correctamente.', 'id': registro.pk}, status=201)


@require_GET
@requiere_rol('Docente')
def descargar_excel(request, archivo_id):
    registro = get_object_or_404(ArchivoDocente, pk=archivo_id,
        docente__id_usuario=request.usuario_panel, docente__estado=1)
    try:
        archivo = registro.archivo.open('rb')
    except FileNotFoundError:
        raise Http404('Archivo no disponible.')
    respuesta = FileResponse(archivo, as_attachment=True, filename=registro.nombre,
        content_type='application/octet-stream')
    respuesta['X-Content-Type-Options'] = 'nosniff'
    return respuesta
