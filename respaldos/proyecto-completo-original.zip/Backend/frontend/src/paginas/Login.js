import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [mostrarPassword, setMostrarPassword] = useState(false);
    const [cargando, setCargando] = useState(false);

    const navigate = useNavigate();

    const login = async () => {

        if (!email || !password) {
            alert("Ingresa tu correo y contraseña");
            return;
        }

        setCargando(true);

        try {

            const res = await fetch(
                "http://127.0.0.1:8000/api/login/",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        correo: email,
                        password: password
                    })
                }
            );

            const data = await res.json();

            if (data.success) {
                sessionStorage.removeItem("token_alumno");
                sessionStorage.removeItem("token_panel");
                if (data.token_panel) sessionStorage.setItem("token_panel", data.token_panel);
                if (data.token_alumno) sessionStorage.setItem("token_alumno", data.token_alumno);

                localStorage.setItem(
                    "usuario",
                    JSON.stringify(data.usuario)
                );

                const rol = data.usuario.nombre_rol?.trim().toLowerCase();

                console.log("ROL DEL USUARIO:", rol);

                if (rol === "administrador") {

                    alert("Bienvenido Administrador");

                    navigate("/admin");

                    return;
                }

                if (rol === "docente") {

                    alert("Bienvenido Docente");

                    navigate("/docente");

                    return;
                }

                if (["alumno", "alumnos"].includes(rol)) {

                    alert("Bienvenido Alumno");

                    navigate("/alumno");

                    return;
                }

                if (rol === "padre") {
                    navigate("/padre");
                    return;
                }

                alert("El usuario no tiene un rol válido");

            } else {

                alert(
                    data.mensaje ||
                    "Correo o contraseña incorrectos"
                );

            }

        } catch (error) {

            console.error(
                "ERROR EN LOGIN:",
                error
            );

            alert(
                "No se pudo conectar con el servidor."
            );

        } finally {

            setCargando(false);

        }
    };


   
return (

    <div
        style={{
            minHeight: "100vh",
            display: "flex",
            flexDirection: "column",
            background: "linear-gradient(135deg, #f5f5f5 0%, #ffffff 50%, #e9e9e9 100%)",
            color: "#171717"
        }}
    >
        

            {/* =====================================================
                ENCABEZADO
            ====================================================== */}

            <header
                style={{
                   background:
                 "linear-gradient(135deg, #173b32, #236b49)",
                    color: "white",
                    padding: "20px 0",
                    boxShadow:
                        "0 5px 20px rgba(0,0,0,0.25)"
                }}
            >

                <div
                    className="container d-flex justify-content-between align-items-center"
                >

                    <div>

                        <h1
                            className="mb-1"
                            style={{
                                fontWeight: "800",
                                letterSpacing: "0.5px"
                            }}
                        >
                            Institución Montreal
                        </h1>

                        <p
                            className="mb-0"
                            style={{
                                opacity: "0.75"
                            }}
                        >
                            Plataforma de cursos y capacitación
                        </p>

                    </div>


                    <div
                        className="d-flex align-items-center gap-3"
                    >

                        <button
                            className="btn"
                            style={{
                                backgroundColor: "white",
                                color: "#111",
                                fontWeight: "700",
                                borderRadius: "10px",
                                padding: "9px 18px",
                                border: "none"
                            }}
                            onClick={() => navigate("/")}
                        >
                            ← Regresar
                        </button>


                        <img
                            src="/montreal.jpeg"
                            width="105"
                            alt="Institución Montreal"
                            style={{
                                borderRadius: "12px",
                                backgroundColor: "white",
                                padding: "5px",
                                boxShadow:
                                    "0 5px 15px rgba(0,0,0,0.35)"
                            }}
                        />

                    </div>

                </div>

            </header>


            {/* =====================================================
                CONTENIDO PRINCIPAL
            ====================================================== */}

            <main
                className="container"
                style={{
                    flex: "1",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    padding: "60px 15px"
                }}
            >

                <div
                    className="row w-100 justify-content-center align-items-center"
                    style={{
                        maxWidth: "1050px"
                    }}
                >

                    {/* =================================================
                        LADO IZQUIERDO
                    ================================================== */}

                    <div
                        className="col-lg-6 text-center mb-5 mb-lg-0"
                    >

                        <img
                            src="/montreal.jpeg"
                            alt="Institución Montreal"
                            style={{
                                width: "230px",
                                maxWidth: "80%",
                                borderRadius: "18px",
                                backgroundColor: "white",
                                padding: "10px",
                                boxShadow:
                                    "0 15px 40px rgba(0,0,0,0.20)"
                            }}
                        />

                        <h2
                            className="mt-4"
                            style={{
                                color: "#111111",
                                fontWeight: "800"
                            }}
                        >
                            Bienvenido de nuevo
                        </h2>

                        <p
                            className="text-muted mt-3"
                            style={{
                                fontSize: "17px",
                                lineHeight: "1.7"
                            }}
                        >
                            Accede a tu cuenta para consultar
                            tus cursos, actividades y
                            información académica.
                        </p>


                        <div
                            className="d-flex justify-content-center gap-3 mt-4 flex-wrap"
                        >

                            <div
                                style={{
                                    background: "white",
                                    color: "#222",
                                    padding: "12px 18px",
                                    borderRadius: "12px",
                                    boxShadow:
                                        "0 6px 20px rgba(0,0,0,0.10)",
                                    border:
                                        "1px solid #e5e5e5"
                                }}
                            >
                                🎓 Educación
                            </div>

                            <div
                                style={{
                                    background: "white",
                                    color: "#222",
                                    padding: "12px 18px",
                                    borderRadius: "12px",
                                    boxShadow:
                                        "0 6px 20px rgba(0,0,0,0.10)",
                                    border:
                                        "1px solid #e5e5e5"
                                }}
                            >
                                💻 Tecnología
                            </div>

                            <div
                                style={{
                                    background: "white",
                                    color: "#222",
                                    padding: "12px 18px",
                                    borderRadius: "12px",
                                    boxShadow:
                                        "0 6px 20px rgba(0,0,0,0.10)",
                                    border:
                                        "1px solid #e5e5e5"
                                }}
                            >
                                📚 Capacitación
                            </div>

                        </div>

                    </div>


                    {/* =================================================
                        TARJETA LOGIN
                    ================================================== */}

                    <div className="col-lg-5">

                        <div
                            style={{
                                background: "white",
                                borderRadius: "24px",
                                padding: "40px",
                                boxShadow:
                                    "0 20px 55px rgba(0,0,0,0.18)",
                                border:
                                    "1px solid #e2e2e2"
                            }}
                        >

                            {/* ENCABEZADO LOGIN */}

                            <div className="text-center mb-4">

                                <div
                                    style={{
                                        width: "68px",
                                        height: "68px",
                                        margin: "0 auto 15px",
                                        borderRadius: "50%",
                                        background:
                                            "linear-gradient(135deg, #050505, #292929)",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        fontSize: "30px",
                                        boxShadow:
                                            "0 8px 22px rgba(0,0,0,0.25)"
                                    }}
                                >
                                    🔐
                                </div>

                                <h2
                                    style={{
                                        fontWeight: "800",
                                        color: "#111"
                                    }}
                                >
                                    Iniciar Sesión
                                </h2>

                                <p className="text-muted mb-0">
                                    Ingresa tus datos para continuar
                                </p>

                            </div>


                            {/* =================================================
                                CORREO
                            ================================================== */}

                            <div className="mb-3">

                                <label
                                    className="form-label"
                                    style={{
                                        fontWeight: "700",
                                        color: "#222"
                                    }}
                                >
                                    Correo electrónico
                                </label>

                                <div
                                    className="d-flex align-items-center"
                                    style={{
                                        border:
                                            "1px solid #cccccc",
                                        borderRadius: "12px",
                                        padding: "0 14px",
                                        background: "#fafafa"
                                    }}
                                >

                                    <span
                                        style={{
                                            fontSize: "20px",
                                            marginRight: "10px"
                                        }}
                                    >
                                        ✉️
                                    </span>

                                    <input
                                        type="email"
                                        className="form-control border-0 shadow-none"
                                        placeholder="ejemplo@correo.com"
                                        value={email}
                                        onChange={(e) =>
                                            setEmail(e.target.value)
                                        }
                                        style={{
                                            background: "transparent",
                                            padding: "13px 5px"
                                        }}
                                    />

                                </div>

                            </div>


                            {/* =================================================
                                CONTRASEÑA
                            ================================================== */}

                            <div className="mb-3">

                                <label
                                    className="form-label"
                                    style={{
                                        fontWeight: "700",
                                        color: "#222"
                                    }}
                                >
                                    Contraseña
                                </label>

                                <div
                                    className="d-flex align-items-center"
                                    style={{
                                        border:
                                            "1px solid #cccccc",
                                        borderRadius: "12px",
                                        padding: "0 14px",
                                        background: "#fafafa"
                                    }}
                                >

                                    <span
                                        style={{
                                            fontSize: "20px",
                                            marginRight: "10px"
                                        }}
                                    >
                                        🔒
                                    </span>

                                    <input
                                        type={
                                            mostrarPassword
                                                ? "text"
                                                : "password"
                                        }
                                        className="form-control border-0 shadow-none"
                                        placeholder="Ingresa tu contraseña"
                                        value={password}
                                        onChange={(e) =>
                                            setPassword(e.target.value)
                                        }
                                        style={{
                                            background: "transparent",
                                            padding: "13px 5px"
                                        }}
                                    />

                                    <button
                                        type="button"
                                        onClick={() =>
                                            setMostrarPassword(
                                                !mostrarPassword
                                            )
                                        }
                                        style={{
                                            border: "none",
                                            background: "transparent",
                                            fontSize: "19px",
                                            cursor: "pointer"
                                        }}
                                    >
                                        {mostrarPassword
                                            ? "🙈"
                                            : "👁️"
                                        }
                                    </button>

                                </div>

                            </div>


                            {/* =================================================
                                BOTÓN ENTRAR
                            ================================================== */}

                            <button
                                className="btn w-100 mt-3"
                                onClick={login}
                                disabled={cargando}
                                style={{
                                   background:
                                    "linear-gradient(135deg, #173b32, #236b49)",
                                    color: "white",
                                    border: "none",
                                    borderRadius: "12px",
                                    padding: "14px",
                                    fontSize: "17px",
                                    fontWeight: "700",
                                    boxShadow:
                                        "0 8px 20px rgba(0,0,0,0.25)"
                                }}
                            >

                                {cargando
                                    ? "Iniciando sesión..."
                                    : "🚀 Entrar a mi cuenta"
                                }

                            </button>


                            {/* =================================================
                                REGISTRO
                            ================================================== */}

                            <div
                                className="text-center mt-4"
                            >

                                <p className="text-muted mb-2">
                                    ¿Todavía no tienes una cuenta?
                                </p>


                            </div>

                        </div>

                    </div>

                </div>

            </main>


            {/* =====================================================
                PIE DE PÁGINA
            ====================================================== */}

            <footer
                style={{
                    background:
                     "linear-gradient(135deg, #173b32, #236b49)",
                    color: "white",
                    textAlign: "center",
                    padding: "25px 15px",
                    boxShadow:
                        "0 -5px 18px rgba(0,0,0,0.18)"
                }}
            >

                <h5
                    style={{
                        fontWeight: "800"
                    }}
                >
                    Institución Montreal
                </h5>

                <p
                    className="mb-2"
                    style={{
                        opacity: "0.85"
                    }}
                >
                    Educación y capacitación profesional
                </p>

                <p
                    className="mb-0"
                    style={{
                        opacity: "0.65",
                        fontSize: "14px"
                    }}
                >
                    © 2026 Todos los derechos reservados
                </p>

            </footer>

        </div>

    );
}

export default Login;
