const vacio = v => v == null || (typeof v === "string" && !v.trim());
export function fechaTabla(v) {
    if (vacio(v)) return "Por confirmar";
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v));
    if (!m) return "Fecha inválida";
    const f = new Date(`${v}T12:00:00Z`);
    if (!Number.isFinite(f.getTime()) || f.toISOString().slice(0, 10) !== v) return "Fecha inválida";
    return `${m[3]}/${m[2]}/${m[1]}`;
}
export function horaTabla(v) {
    return /^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/.test(String(v)) ? String(v).slice(0, 5) : "Por confirmar";
}
export const columnasAlumno = {
    Calificaciones: [["evaluacion", "Evaluación"], ["calificacion", "Calificación"], ["observaciones", "Observaciones"]],
    Evaluaciones: [["nombre_evaluacion", "Evaluación"], ["tipo_evaluacion", "Tipo"], ["porcentaje", "Porcentaje"], ["fecha", "Fecha"]],
    Asistencias: [["fecha", "Fecha"], ["estado", "Asistencia"], ["observaciones", "Observaciones"]],
    Pagos: [["fecha_pago", "Fecha de pago"], ["monto", "Importe"], ["moneda", "Moneda"], ["concepto", "Concepto"]],
};
export function valorAlumno(campo, valor, fila = {}) {
    if (campo === "fecha" || campo === "fecha_pago") return fechaTabla(valor);
    if (vacio(valor)) return campo === "observaciones" ? "Sin observaciones" : "Pendiente";
    if (["calificacion", "porcentaje", "monto"].includes(campo)) {
        const n = typeof valor === "number" || (typeof valor === "string" && /^\d+(\.\d+)?$/.test(valor.trim())) ? Number(valor) : NaN;
        if (!Number.isFinite(n) || n < 0 || (campo !== "monto" && n > 100)) return "Dato inválido";
        if (campo === "monto") return `${n.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${["MXN", "USD"].includes(fila.moneda) ? fila.moneda : "(moneda pendiente)"}`;
        return `${n.toLocaleString("es-MX", { maximumFractionDigits: 2 })}${campo === "porcentaje" ? " %" : ""}`;
    }
    if (campo === "estado" && !["Presente", "Ausente", "Justificada", "Retardo"].includes(valor)) return "Estado por revisar";
    if (campo === "moneda" && !["MXN", "USD"].includes(valor)) return "Por confirmar";
    return typeof valor === "string" || typeof valor === "number" ? String(valor).trim() : "Dato inválido";
}
