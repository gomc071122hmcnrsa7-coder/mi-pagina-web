import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Login from "./paginas/Login";
import Alumno from "./paginas/Alumno";
import Inicio from "./paginas/Inicio";
import Registro from "./paginas/Registro";
import Admin from "./paginas/Admin";
import Docente from "./paginas/Docente";
import Cursos from "./paginas/Cursos";
import CatalogoCursos from "./paginas/CatalogoCursos";

import DetalleCurso from "./paginas/DetalleCurso";
import ConocerMontreal from "./paginas/ConocerMontreal";
import MisionVision from "./paginas/MisionVision";

function App() {

    return (

        <BrowserRouter>

            <Routes>

                <Route path="/" element={<Inicio />} />
                <Route path="/cursos" element={<Cursos />} />
                <Route path="/cursos/:idCurso" element={<DetalleCurso />} />
                <Route path="/conocer-montreal" element={<ConocerMontreal />} />
                <Route path="/mision-vision" element={<MisionVision />} />

                <Route path="/cursos" element={<CatalogoCursos />} />

                <Route path="/login" element={<Login />} />

                <Route path="/cliente" element={<Navigate to="/alumno" replace />} />
                <Route path="/alumno" element={<Alumno />} />
                <Route path="/alumno/cursos/:idCurso" element={<Alumno />} />
                <Route path="/padre" element={<Alumno familia />} />

                <Route path="/docente" element={<Docente />} />

                <Route path="/admin" element={<Admin />} />
  
                <Route path="/registro" element={<Registro />} />

            </Routes>

        </BrowserRouter>

    );
}

export default App;
