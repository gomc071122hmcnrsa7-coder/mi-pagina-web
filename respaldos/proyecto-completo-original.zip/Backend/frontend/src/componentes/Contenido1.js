import { useEffect, useState } from "react";

function Contenido1() {

    const [cursos, setCursos] = useState([]);
    const [inscripciones, setInscripciones] = useState([]);
    const [cursoAbierto, setCursoAbierto] = useState(null);

    // ==========================================
    // CARGAR DATOS
    // ==========================================

    useEffect(() => {

        // ==============================
        // OBTENER CURSOS
        // ==============================

        fetch("http://127.0.0.1:8000/api/cursos-completos/")
            .then(res => {

                if (!res.ok) {
                    throw new Error("Error al consultar la API");
                }

                return res.json();

            })
            .then(data => {

                console.log("CURSOS RECIBIDOS:", data);

                setCursos(data);

            })
            .catch(error => {

                console.error("ERROR:", error);

            });


        // ==============================
        // OBTENER INSCRIPCIONES
        // ==============================

        fetch("http://127.0.0.1:8000/api/inscripciones/alumno/1/")
            .then(res => res.json())
            .then(data => {

                console.log("INSCRIPCIONES:", data);

                setInscripciones(data);

            })
            .catch(error => {

                console.error(
                    "Error al obtener inscripciones:",
                    error
                );

            });

    }, []);


    // ==========================================
    // FUNCIÓN PARA INSCRIBIR AL ALUMNO
    // ==========================================

    const inscribirse = async (curso) => {

        try {

            const respuesta = await fetch(
                "http://127.0.0.1:8000/api/inscripciones/crear/",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        id_alumno: 1,
                        id_grupo: curso.id_grupo
                    })
                }
            );

            const data = await respuesta.json();

            console.log(
                "RESPUESTA INSCRIPCIÓN:",
                data
            );

            if (data.success) {

                alert(data.mensaje);

                // Actualizar las inscripciones

                fetch(
                    "http://127.0.0.1:8000/api/inscripciones/alumno/1/"
                )
                    .then(res => res.json())
                    .then(data => {

                        setInscripciones(data);

                    });

            } else {

                alert(data.mensaje);

            }

        } catch (error) {

            console.error(
                "ERROR AL INSCRIBIR:",
                error
            );

            alert(
                "No se pudo realizar la inscripción"
            );

        }

    };


    // ==========================================
    // CURSO SELECCIONADO
    // ==========================================

    const cursoSeleccionado =
        cursos.find(
            curso =>
                curso.id_curso === cursoAbierto
        );


    return (

        <div
            style={{
                minHeight: "100vh",
                background:
                    "linear-gradient(135deg, #eef8f2 0%, #f7faf8 50%, #e5f3ea 100%)",
                display: "flex",
                flexDirection: "column"
            }}
        >

            {/* =====================================================
                ENCABEZADO
            ===================================================== */}

            <header
                style={{
                    background:
                        "linear-gradient(135deg, #087f4f, #11965f)",
                    color: "white",
                    padding: "18px 0",
                    boxShadow:
                        "0 5px 20px rgba(0,0,0,0.18)",
                    position: "relative",
                    zIndex: 10
                }}
            >

                <div
                    className="container-fluid px-4"
                    style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        gap: "20px"
                    }}
                >

                    {/* BOTÓN REGRESAR */}

                    <button
                        className="btn"
                        onClick={() =>
                            window.history.back()
                        }
                        style={{
                            color: "white",
                            border:
                                "1px solid rgba(255,255,255,0.55)",
                            background:
                                "rgba(255,255,255,0.10)",
                            borderRadius: "10px",
                            fontWeight: "600",
                            padding: "10px 18px",
                            whiteSpace: "nowrap"
                        }}
                    >
                        ← Regresar
                    </button>


                    {/* TÍTULO */}

                    <div
                        style={{
                            textAlign: "center",
                            flex: 1
                        }}
                    >

                        <h1
                            style={{
                                margin: 0,
                                fontSize: "30px",
                                fontWeight: "800",
                                letterSpacing: "0.5px"
                            }}
                        >
                            Unidad Montreal
                        </h1>

                        <p
                            style={{
                                margin: "4px 0 0",
                                opacity: 0.9,
                                fontSize: "14px"
                            }}
                        >
                            Plataforma educativa de cursos y capacitación
                        </p>

                    </div>


                    {/* LOGO */}

                    <img
                        src="/montreal.jpeg"
                        width="82"
                        height="82"
                        alt="Montreal"
                        className="rounded"
                        style={{
                            backgroundColor: "white",
                            padding: "5px",
                            objectFit: "contain",
                            borderRadius: "12px",
                            boxShadow:
                                "0 4px 12px rgba(0,0,0,0.20)"
                        }}
                    />

                </div>

            </header>


            {/* =====================================================
                CONTENIDO PRINCIPAL
            ===================================================== */}

            <main
                style={{
                    flex: 1,
                    padding: "30px 25px"
                }}
            >

                {/* TÍTULO */}

                <div
                    style={{
                        marginBottom: "25px"
                    }}
                >

                    <h2
                        style={{
                            color: "#075d3b",
                            fontWeight: "800",
                            marginBottom: "5px"
                        }}
                    >
                        Cursos disponibles
                    </h2>

                    <p
                        style={{
                            color: "#65736b",
                            margin: 0
                        }}
                    >
                        Selecciona un curso para consultar toda su información.
                    </p>

                </div>


                {/* =================================================
                    CONTENEDOR PRINCIPAL
                ================================================= */}

                <div
                    style={{
                        display: "flex",
                        gap: "25px",
                        height: "calc(100vh - 235px)",
                        minHeight: "500px"
                    }}
                >


                    {/* =================================================
                        PANEL IZQUIERDO
                    ================================================= */}

                    <section
                        style={{
                            width: "360px",
                            minWidth: "360px",
                            backgroundColor: "#ffffff",
                            borderRadius: "18px",
                            padding: "18px",
                            boxShadow:
                                "0 8px 30px rgba(0,0,0,0.10)",
                            border:
                                "1px solid #dcebe2",
                            display: "flex",
                            flexDirection: "column",
                            overflow: "hidden"
                        }}
                    >

                        {/* CABECERA */}

                        <div
                            style={{
                                paddingBottom: "15px",
                                borderBottom:
                                    "1px solid #e1ebe5",
                                marginBottom: "15px"
                            }}
                        >

                            <div
                                style={{
                                    display: "flex",
                                    justifyContent:
                                        "space-between",
                                    alignItems: "center"
                                }}
                            >

                                <div>

                                    <h4
                                        style={{
                                            margin: 0,
                                            color: "#075d3b",
                                            fontWeight: "800"
                                        }}
                                    >
                                        📚 Mis cursos
                                    </h4>

                                    <small
                                        style={{
                                            color: "#718078"
                                        }}
                                    >
                                        Selecciona uno para ver detalles
                                    </small>

                                </div>


                                <span
                                    style={{
                                        background:
                                            "#087f4f",
                                        color: "white",
                                        padding:
                                            "6px 12px",
                                        borderRadius:
                                            "20px",
                                        fontWeight: "700",
                                        fontSize: "13px"
                                    }}
                                >
                                    {cursos.length}
                                </span>

                            </div>

                        </div>


                        {/* =================================================
                            LISTA CON SCROLL INDEPENDIENTE
                        ================================================= */}

                        <div
                            style={{
                                flex: 1,
                                overflowY: "auto",
                                paddingRight: "8px"
                            }}
                        >

                            {cursos.length === 0 ? (

                                <div
                                    style={{
                                        padding: "25px 10px",
                                        textAlign: "center",
                                        color: "#7b8881"
                                    }}
                                >
                                    No hay cursos disponibles.
                                </div>

                            ) : (

                                cursos.map((curso, index) => (

                                    <div
                                        key={
                                            curso.id_curso ||
                                            index
                                        }
                                        onClick={() =>
                                            setCursoAbierto(
                                                cursoAbierto ===
                                                    curso.id_curso
                                                    ? null
                                                    : curso.id_curso
                                            )
                                        }
                                        style={{
                                            background:
                                                cursoAbierto ===
                                                curso.id_curso
                                                    ? "linear-gradient(135deg, #087f4f, #11965f)"
                                                    : "#f7faf8",
                                            color:
                                                cursoAbierto ===
                                                curso.id_curso
                                                    ? "white"
                                                    : "#1f2d27",
                                            border:
                                                cursoAbierto ===
                                                curso.id_curso
                                                    ? "1px solid #087f4f"
                                                    : "1px solid #e0ebe4",
                                            borderRadius:
                                                "14px",
                                            padding:
                                                "16px",
                                            marginBottom:
                                                "12px",
                                            cursor:
                                                "pointer",
                                            transition:
                                                "all 0.2s ease",
                                            boxShadow:
                                                cursoAbierto ===
                                                curso.id_curso
                                                    ? "0 7px 18px rgba(8,127,79,0.25)"
                                                    : "0 3px 10px rgba(0,0,0,0.05)"
                                        }}
                                    >

                                        <div
                                            style={{
                                                display:
                                                    "flex",
                                                justifyContent:
                                                    "space-between",
                                                alignItems:
                                                    "center",
                                                gap: "10px"
                                            }}
                                        >

                                            <div
                                                style={{
                                                    display:
                                                        "flex",
                                                    alignItems:
                                                        "center",
                                                    gap: "10px",
                                                    minWidth: 0
                                                }}
                                            >

                                                <div
                                                    style={{
                                                        width: "40px",
                                                        height: "40px",
                                                        minWidth: "40px",
                                                        borderRadius:
                                                            "10px",
                                                        background:
                                                            cursoAbierto ===
                                                            curso.id_curso
                                                                ? "rgba(255,255,255,0.18)"
                                                                : "#e2f2e8",
                                                        display:
                                                            "flex",
                                                        alignItems:
                                                            "center",
                                                        justifyContent:
                                                            "center",
                                                        fontSize:
                                                            "19px"
                                                    }}
                                                >
                                                    📚
                                                </div>


                                                <div
                                                    style={{
                                                        overflow:
                                                            "hidden"
                                                    }}
                                                >

                                                    <h5
                                                        style={{
                                                            margin: 0,
                                                            fontWeight:
                                                                "700",
                                                            fontSize:
                                                                "16px",
                                                            whiteSpace:
                                                                "nowrap",
                                                            overflow:
                                                                "hidden",
                                                            textOverflow:
                                                                "ellipsis"
                                                        }}
                                                    >
                                                        {curso.nombre_curso}
                                                    </h5>

                                                    <small
                                                        style={{
                                                            opacity:
                                                                cursoAbierto ===
                                                                curso.id_curso
                                                                    ? 0.9
                                                                    : 0.65
                                                        }}
                                                    >
                                                        {curso.nombre_grupo ||
                                                            "Grupo no asignado"}
                                                    </small>

                                                </div>

                                            </div>


                                            <span
                                                style={{
                                                    fontSize:
                                                        "18px"
                                                }}
                                            >
                                                {cursoAbierto ===
                                                curso.id_curso
                                                    ? "●"
                                                    : "›"}
                                            </span>

                                        </div>

                                    </div>

                                ))

                            )}

                        </div>

                    </section>


                    {/* =================================================
                        PANEL DERECHO
                    ================================================= */}

                    <section
                        style={{
                            flex: 1,
                            minWidth: 0,
                            backgroundColor: "#ffffff",
                            borderRadius: "18px",
                            boxShadow:
                                "0 8px 30px rgba(0,0,0,0.10)",
                            border:
                                "1px solid #dcebe2",
                            overflow: "hidden",
                            display: "flex",
                            flexDirection: "column"
                        }}
                    >

                        {!cursoSeleccionado ? (

                            /* =========================================
                               ESTADO INICIAL
                            ========================================= */

                            <div
                                style={{
                                    flex: 1,
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    textAlign: "center",
                                    padding: "40px"
                                }}
                            >

                                <div>

                                    <div
                                        style={{
                                            width: "90px",
                                            height: "90px",
                                            borderRadius:
                                                "50%",
                                            background:
                                                "#e4f3ea",
                                            display:
                                                "flex",
                                            alignItems:
                                                "center",
                                            justifyContent:
                                                "center",
                                            margin:
                                                "0 auto 20px",
                                            fontSize:
                                                "38px"
                                        }}
                                    >
                                        📚
                                    </div>

                                    <h3
                                        style={{
                                            color: "#075d3b",
                                            fontWeight: "800"
                                        }}
                                    >
                                        Selecciona un curso
                                    </h3>

                                    <p
                                        style={{
                                            color: "#718078",
                                            maxWidth:
                                                "430px",
                                            margin:
                                                "0 auto"
                                        }}
                                    >
                                        Selecciona uno de los cursos
                                        del panel izquierdo para
                                        consultar su información
                                        completa.
                                    </p>

                                </div>

                            </div>

                        ) : (

                            <>
                                {/* =====================================
                                    CABECERA INFORMACIÓN
                                ====================================== */}

                                <div
                                    style={{
                                        background:
                                            "linear-gradient(135deg, #087f4f, #11965f)",
                                        color: "white",
                                        padding: "24px 28px"
                                    }}
                                >

                                    <div
                                        style={{
                                            display:
                                                "flex",
                                            justifyContent:
                                                "space-between",
                                            alignItems:
                                                "center",
                                            gap: "15px"
                                        }}
                                    >

                                        <div>

                                            <small
                                                style={{
                                                    opacity:
                                                        0.85,
                                                    fontWeight:
                                                        "600"
                                                }}
                                            >
                                                INFORMACIÓN DEL CURSO
                                            </small>

                                            <h3
                                                style={{
                                                    margin:
                                                        "5px 0 0",
                                                    fontWeight:
                                                        "800"
                                                }}
                                            >
                                                {
                                                    cursoSeleccionado.nombre_curso
                                                }
                                            </h3>

                                        </div>


                                        <div
                                            style={{
                                                background:
                                                    "rgba(255,255,255,0.15)",
                                                padding:
                                                    "10px 15px",
                                                borderRadius:
                                                    "10px",
                                                fontWeight:
                                                    "700",
                                                whiteSpace:
                                                    "nowrap"
                                            }}
                                        >
                                            #{cursoSeleccionado.id_curso}
                                        </div>

                                    </div>

                                </div>


                                {/* =====================================
                                    INFORMACIÓN
                                ====================================== */}

                                <div
                                    style={{
                                        padding: "28px",
                                        overflowY:
                                            "auto",
                                        flex: 1
                                    }}
                                >

                                    <div
                                        className="row g-3"
                                    >

                                        {/* DESCRIPCIÓN */}

                                        <div
                                            className="col-12"
                                        >

                                            <div
                                                style={{
                                                    background:
                                                        "#f6faf7",
                                                    border:
                                                        "1px solid #dfebe3",
                                                    borderRadius:
                                                        "12px",
                                                    padding:
                                                        "18px"
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        color:
                                                            "#087f4f",
                                                        fontWeight:
                                                            "700"
                                                    }}
                                                >
                                                    DESCRIPCIÓN
                                                </small>

                                                <p
                                                    style={{
                                                        margin:
                                                            "7px 0 0",
                                                        color:
                                                            "#394840"
                                                    }}
                                                >
                                                    {cursoSeleccionado.descripcion ||
                                                        "Sin descripción"}
                                                </p>

                                            </div>

                                        </div>


                                        {/* DURACIÓN */}

                                        <div
                                            className="col-md-6"
                                        >

                                            <div
                                                style={{
                                                    padding:
                                                        "16px",
                                                    background:
                                                        "#f8faf9",
                                                    border:
                                                        "1px solid #e3ebe6",
                                                    borderRadius:
                                                        "12px"
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        color:
                                                            "#087f4f",
                                                        fontWeight:
                                                            "700"
                                                    }}
                                                >
                                                    ⏱ DURACIÓN
                                                </small>

                                                <div
                                                    style={{
                                                        fontSize:
                                                            "18px",
                                                        fontWeight:
                                                            "700",
                                                        marginTop:
                                                            "5px"
                                                    }}
                                                >
                                                    {
                                                        cursoSeleccionado.duracion_horas ||
                                                        0
                                                    }{" "}
                                                    horas
                                                </div>

                                            </div>

                                        </div>


                                        {/* NIVEL */}

                                        <div
                                            className="col-md-6"
                                        >

                                            <div
                                                style={{
                                                    padding:
                                                        "16px",
                                                    background:
                                                        "#f8faf9",
                                                    border:
                                                        "1px solid #e3ebe6",
                                                    borderRadius:
                                                        "12px"
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        color:
                                                            "#087f4f",
                                                        fontWeight:
                                                            "700"
                                                    }}
                                                >
                                                    🎯 NIVEL
                                                </small>

                                                <div
                                                    style={{
                                                        fontSize:
                                                            "18px",
                                                        fontWeight:
                                                            "700",
                                                        marginTop:
                                                            "5px"
                                                    }}
                                                >
                                                    {
                                                        cursoSeleccionado.nivel ||
                                                        "No especificado"
                                                    }
                                                </div>

                                            </div>

                                        </div>


                                        {/* COSTO */}

                                        <div
                                            className="col-md-6"
                                        >

                                            <div
                                                style={{
                                                    padding:
                                                        "16px",
                                                    background:
                                                        "#f8faf9",
                                                    border:
                                                        "1px solid #e3ebe6",
                                                    borderRadius:
                                                        "12px"
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        color:
                                                            "#087f4f",
                                                        fontWeight:
                                                            "700"
                                                    }}
                                                >
                                                    💰 COSTO
                                                </small>

                                                <div
                                                    style={{
                                                        fontSize:
                                                            "20px",
                                                        fontWeight:
                                                            "800",
                                                        color:
                                                            "#087f4f",
                                                        marginTop:
                                                            "5px"
                                                    }}
                                                >
                                                    $
                                                    {
                                                        cursoSeleccionado.costo ??
                                                        "0.00"
                                                    }
                                                </div>

                                            </div>

                                        </div>


                                        {/* GRUPO */}

                                        <div
                                            className="col-md-6"
                                        >

                                            <div
                                                style={{
                                                    padding:
                                                        "16px",
                                                    background:
                                                        "#f8faf9",
                                                    border:
                                                        "1px solid #e3ebe6",
                                                    borderRadius:
                                                        "12px"
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        color:
                                                            "#087f4f",
                                                        fontWeight:
                                                            "700"
                                                    }}
                                                >
                                                    👥 GRUPO
                                                </small>

                                                <div
                                                    style={{
                                                        fontSize:
                                                            "18px",
                                                        fontWeight:
                                                            "700",
                                                        marginTop:
                                                            "5px"
                                                    }}
                                                >
                                                    {
                                                        cursoSeleccionado.nombre_grupo ||
                                                        "Sin grupo asignado"
                                                    }
                                                </div>

                                            </div>

                                        </div>


                                        {/* DOCENTE */}

                                        <div
                                            className="col-md-6"
                                        >

                                            <div
                                                style={{
                                                    padding:
                                                        "16px",
                                                    background:
                                                        "#f8faf9",
                                                    border:
                                                        "1px solid #e3ebe6",
                                                    borderRadius:
                                                        "12px"
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        color:
                                                            "#087f4f",
                                                        fontWeight:
                                                            "700"
                                                    }}
                                                >
                                                    👨‍🏫 DOCENTE
                                                </small>

                                                <div
                                                    style={{
                                                        fontSize:
                                                            "17px",
                                                        fontWeight:
                                                            "700",
                                                        marginTop:
                                                            "5px"
                                                    }}
                                                >
                                                    {
                                                        cursoSeleccionado.nombre_docente
                                                            ? `${cursoSeleccionado.nombre_docente} ${
                                                                cursoSeleccionado.apellido_paterno ||
                                                                ""
                                                            }`
                                                            : "Sin docente asignado"
                                                    }
                                                </div>

                                            </div>

                                        </div>


                                        {/* PERIODO */}

                                        <div
                                            className="col-md-6"
                                        >

                                            <div
                                                style={{
                                                    padding:
                                                        "16px",
                                                    background:
                                                        "#f8faf9",
                                                    border:
                                                        "1px solid #e3ebe6",
                                                    borderRadius:
                                                        "12px"
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        color:
                                                            "#087f4f",
                                                        fontWeight:
                                                            "700"
                                                    }}
                                                >
                                                    📅 PERIODO
                                                </small>

                                                <div
                                                    style={{
                                                        fontSize:
                                                            "17px",
                                                        fontWeight:
                                                            "700",
                                                        marginTop:
                                                            "5px"
                                                    }}
                                                >
                                                    {
                                                        cursoSeleccionado.nombre_periodo ||
                                                        "Sin periodo"
                                                    }
                                                </div>

                                            </div>

                                        </div>


                                        {/* DÍA */}

                                        <div
                                            className="col-md-6"
                                        >

                                            <div
                                                style={{
                                                    padding:
                                                        "16px",
                                                    background:
                                                        "#f8faf9",
                                                    border:
                                                        "1px solid #e3ebe6",
                                                    borderRadius:
                                                        "12px"
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        color:
                                                            "#087f4f",
                                                        fontWeight:
                                                            "700"
                                                    }}
                                                >
                                                    📅 DÍA
                                                </small>

                                                <div
                                                    style={{
                                                        fontSize:
                                                            "17px",
                                                        fontWeight:
                                                            "700",
                                                        marginTop:
                                                            "5px"
                                                    }}
                                                >
                                                    {
                                                        cursoSeleccionado.nombre_dia ||
                                                        "Sin horario"
                                                    }
                                                </div>

                                            </div>

                                        </div>


                                        {/* HORARIO */}

                                        <div
                                            className="col-md-6"
                                        >

                                            <div
                                                style={{
                                                    padding:
                                                        "16px",
                                                    background:
                                                        "#f8faf9",
                                                    border:
                                                        "1px solid #e3ebe6",
                                                    borderRadius:
                                                        "12px"
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        color:
                                                            "#087f4f",
                                                        fontWeight:
                                                            "700"
                                                    }}
                                                >
                                                    🕐 HORARIO
                                                </small>

                                                <div
                                                    style={{
                                                        fontSize:
                                                            "17px",
                                                        fontWeight:
                                                            "700",
                                                        marginTop:
                                                            "5px"
                                                    }}
                                                >

                                                    {
                                                        cursoSeleccionado.hora_inicio &&
                                                        cursoSeleccionado.hora_fin

                                                            ? `${cursoSeleccionado.hora_inicio} - ${cursoSeleccionado.hora_fin}`

                                                            : "Sin horario"
                                                    }

                                                </div>

                                            </div>

                                        </div>


                                        {/* AULA */}

                                        <div
                                            className="col-md-6"
                                        >

                                            <div
                                                style={{
                                                    padding:
                                                        "16px",
                                                    background:
                                                        "#f8faf9",
                                                    border:
                                                        "1px solid #e3ebe6",
                                                    borderRadius:
                                                        "12px"
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        color:
                                                            "#087f4f",
                                                        fontWeight:
                                                            "700"
                                                    }}
                                                >
                                                    🏫 AULA
                                                </small>

                                                <div
                                                    style={{
                                                        fontSize:
                                                            "17px",
                                                        fontWeight:
                                                            "700",
                                                        marginTop:
                                                            "5px"
                                                    }}
                                                >
                                                    {
                                                        cursoSeleccionado.nombre_aula ||
                                                        "Sin aula"
                                                    }
                                                </div>

                                            </div>

                                        </div>


                                        {/* UBICACIÓN */}

                                        <div
                                            className="col-md-6"
                                        >

                                            <div
                                                style={{
                                                    padding:
                                                        "16px",
                                                    background:
                                                        "#f8faf9",
                                                    border:
                                                        "1px solid #e3ebe6",
                                                    borderRadius:
                                                        "12px"
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        color:
                                                            "#087f4f",
                                                        fontWeight:
                                                            "700"
                                                    }}
                                                >
                                                    📍 UBICACIÓN
                                                </small>

                                                <div
                                                    style={{
                                                        fontSize:
                                                            "17px",
                                                        fontWeight:
                                                            "700",
                                                        marginTop:
                                                            "5px"
                                                    }}
                                                >
                                                    {
                                                        cursoSeleccionado.ubicacion ||
                                                        "Sin ubicación"
                                                    }
                                                </div>

                                            </div>

                                        </div>


                                        {/* ESTADO */}

                                        <div
                                            className="col-12"
                                        >

                                            <div
                                                style={{
                                                    display:
                                                        "flex",
                                                    justifyContent:
                                                        "space-between",
                                                    alignItems:
                                                        "center",
                                                    padding:
                                                        "15px 18px",
                                                    background:
                                                        cursoSeleccionado.estado === 1
                                                            ? "#e8f7ee"
                                                            : "#fbeaea",
                                                    borderRadius:
                                                        "12px",
                                                    border:
                                                        cursoSeleccionado.estado === 1
                                                            ? "1px solid #bfe6ce"
                                                            : "1px solid #f1c5c5"
                                                }}
                                            >

                                                <strong>
                                                    Estado del curso
                                                </strong>

                                                <span
                                                    style={{
                                                        color:
                                                            cursoSeleccionado.estado === 1
                                                                ? "#087f4f"
                                                                : "#dc3545",
                                                        fontWeight:
                                                            "800"
                                                    }}
                                                >
                                                    {cursoSeleccionado.estado === 1
                                                        ? "● Disponible"
                                                        : "● No disponible"
                                                    }
                                                </span>

                                            </div>

                                        </div>

                                    </div>


                                    {/* =================================
                                        BOTÓN INSCRIBIRME
                                    ================================== */}

                                    {cursoSeleccionado.estado === 1 &&
                                    cursoSeleccionado.id_grupo && (

                                        <button
                                            className="btn w-100 mt-4"
                                            style={{
                                                background:
                                                    "linear-gradient(135deg, #087f4f, #11965f)",
                                                color: "white",
                                                border: "none",
                                                borderRadius: "12px",
                                                padding: "14px",
                                                fontWeight: "800",
                                                fontSize: "16px",
                                                boxShadow:
                                                    "0 6px 18px rgba(8,127,79,0.25)"
                                            }}
                                            onClick={() =>
                                                inscribirse(
                                                    cursoSeleccionado
                                                )
                                            }
                                        >
                                            ✓ Inscribirme a este curso
                                        </button>

                                    )}

                                </div>

                            </>

                        )}

                    </section>

                </div>

            </main>


            {/* =====================================================
                PIE DE PÁGINA
            ===================================================== */}

            <footer
                style={{
                    background:
                        "linear-gradient(135deg, #087f4f, #11965f)",
                    color: "white",
                    textAlign: "center",
                    padding: "20px",
                    boxShadow:
                        "0 -4px 15px rgba(0,0,0,0.12)"
                }}
            >

                <h5
                    style={{
                        fontWeight: "800",
                        marginBottom: "5px"
                    }}
                >
                    Unidad Montreal
                </h5>

                <p
                    style={{
                        marginBottom: "5px",
                        opacity: 0.9
                    }}
                >
                    Plataforma educativa de cursos y capacitación
                </p>

                <p
                    style={{
                        marginBottom: 0,
                        opacity: 0.7,
                        fontSize: "13px"
                    }}
                >
                    © 2026 Todos los derechos reservados
                </p>

            </footer>

        </div>

    );

}

export default Contenido1;