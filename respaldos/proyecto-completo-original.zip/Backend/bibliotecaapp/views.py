from datetime import date
from django.core import signing
from django.contrib.auth.hashers import check_password, identify_hasher, make_password
from django.utils.crypto import constant_time_compare
import json

from django.apps import apps
from django.db import connection
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import (
    Cursos,
    Alumnos,
    Docentes,
    Grupos,
    Inscripciones,
    Horarios,
    Usuarios,
    Roles,
    Periodos,
    Aulas,
    Dias,
    Pagos,
    Asistencias,
    Evaluaciones,
    Calificaciones,
    EntidadesCertificadoras,
    Certificaciones
)

from .serializers import (
    CursoSerializer,
    AlumnoSerializer,
    DocenteSerializer,
    GrupoSerializer,
    InscripcionSerializer,
    HorarioSerializer,
    UsuarioSerializer,
    RolSerializer,
    PeriodoSerializer,
    AulaSerializer,
    DiaSerializer,
    PagoSerializer,
    AsistenciaSerializer,
    EvaluacionSerializer,
    CalificacionSerializer,
    EntidadCertificadoraSerializer,
    CertificacionSerializer
)


# ============================================================
# ALUMNOS
# ============================================================

@api_view(['GET'])
def obtener_alumnos(request):

    id_docente = request.GET.get('id_docente')

    if id_docente:
        alumnos = Alumnos.objects.filter(
            inscripciones__id_grupo__id_docente=id_docente
        ).distinct()
    else:
        alumnos = Alumnos.objects.all()

    serializer = AlumnoSerializer(alumnos, many=True)

    return Response(serializer.data)


# ============================================================
# DOCENTES
# ============================================================

@api_view(['GET'])
def obtener_docentes(request):

    docentes = Docentes.objects.all()

    serializer = DocenteSerializer(
        docentes,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# GRUPOS
# ============================================================

@api_view(['GET'])
def obtener_grupos(request):

    id_docente = request.GET.get('id_docente')

    if id_docente:
        grupos = Grupos.objects.filter(
            id_docente=id_docente
        )
    else:
        grupos = Grupos.objects.all()

    serializer = GrupoSerializer(
        grupos,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# INSCRIPCIONES
# ============================================================

@api_view(['GET'])
def obtener_inscripciones(request):

    id_docente = request.GET.get('id_docente')

    if id_docente:
        inscripciones = Inscripciones.objects.filter(
            id_grupo__id_docente=id_docente
        )
    else:
        inscripciones = Inscripciones.objects.all()

    serializer = InscripcionSerializer(
        inscripciones,
        many=True
    )

    return Response(serializer.data)


@api_view(['GET'])
def obtener_inscripciones_alumno(request, id_alumno):

    inscripciones = Inscripciones.objects.filter(
        id_alumno=id_alumno
    )

    serializer = InscripcionSerializer(
        inscripciones,
        many=True
    )

    return Response(serializer.data)


@csrf_exempt
@api_view(['POST'])
def crear_inscripcion(request):

    try:

        id_alumno = request.data.get('id_alumno')
        id_grupo = request.data.get('id_grupo')

        if not id_alumno or not id_grupo:
            return Response({
                'success': False,
                'mensaje': 'id_alumno e id_grupo son obligatorios'
            }, status=400)

        alumno = Alumnos.objects.filter(
            id_alumno=id_alumno
        ).first()

        if not alumno:
            return Response({
                'success': False,
                'mensaje': 'El alumno no existe'
            }, status=404)

        grupo = Grupos.objects.filter(
            id_grupo=id_grupo
        ).first()

        if not grupo:
            return Response({
                'success': False,
                'mensaje': 'El grupo no existe'
            }, status=404)

        inscripcion_existente = Inscripciones.objects.filter(
            id_alumno=alumno,
            id_grupo=grupo,
            estado=1
        ).first()

        if inscripcion_existente:
            return Response({
                'success': False,
                'mensaje': 'El alumno ya está inscrito en este grupo'
            }, status=400)

        inscripcion = Inscripciones.objects.create(
            id_alumno=alumno,
            id_grupo=grupo,
            fecha_inscripcion=date.today(),
            estado=1,
            observaciones='Inscripción realizada desde la plataforma'
        )

        return Response({
            'success': True,
            'mensaje': 'Inscripción realizada correctamente',
            'id_inscripcion': inscripcion.id_inscripcion
        }, status=201)

    except Exception as error:

        print("ERROR INSCRIPCION:", error)

        return Response({
            'success': False,
            'mensaje': 'Error al registrar la inscripción',
            'error': str(error)
        }, status=500)


# ============================================================
# CURSOS
# ============================================================

@api_view(['GET'])
def obtener_cursos(request):

    id_docente = request.GET.get('id_docente')

    if id_docente:
        cursos = Cursos.objects.filter(
            grupos__id_docente=id_docente
        ).distinct()
    else:
        cursos = Cursos.objects.all()

    serializer = CursoSerializer(
        cursos,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# HORARIOS
# ============================================================

@api_view(['GET'])
def obtener_horarios(request):

    id_docente = request.GET.get('id_docente')

    if id_docente:
        horarios = Horarios.objects.filter(
            id_grupo__id_docente=id_docente
        )
    else:
        horarios = Horarios.objects.all()

    serializer = HorarioSerializer(
        horarios,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# LOGIN
# ============================================================

@csrf_exempt
def login(request):

    if request.method != 'POST':
        return JsonResponse({
            'success': False,
            'mensaje': 'Método no permitido'
        }, status=405)

    try:

        data = json.loads(request.body)

        correo = data.get('correo')
        password = data.get('password')

        if not correo or not password:
            return JsonResponse({
                'success': False,
                'mensaje': 'Correo y contraseña son obligatorios'
            }, status=400)

        with connection.cursor() as cursor:

            cursor.execute("""
                SELECT
                    u.id_usuario,
                    u.id_rol,
                    u.nombre_usuario,
                    u.email,
                    u.estado,
                    r.nombre_rol,
                    a.id_alumno,
                    d.id_docente,
                    u.password_hash
                FROM usuarios u
                INNER JOIN roles r
                    ON u.id_rol = r.id_rol
                LEFT JOIN alumnos a
                    ON u.id_usuario = a.id_usuario
                LEFT JOIN docentes d
                    ON u.id_usuario = d.id_usuario
                WHERE u.email = %s
                AND u.estado = 1
            """, [correo])

            usuario = cursor.fetchone()

        password_valido = False
        if usuario:
            try:
                identify_hasher(usuario[8])
            except ValueError:
                password_valido = constant_time_compare(password, usuario[8])
            else:
                password_valido = check_password(password, usuario[8])
        if not password_valido:
            return JsonResponse({
                'success': False,
                'mensaje': 'Correo o contraseña incorrectos'
            }, status=401)

        return JsonResponse({

            'success': True,

            'mensaje': 'Inicio de sesión correcto',

            'token_alumno': signing.dumps({'id_usuario': usuario[0]}, salt='panel-alumno') if usuario[5].strip().casefold() in {'alumno', 'alumnos'} else None,
            'token_panel': signing.dumps({'id_usuario': usuario[0]}, salt='panel-roles'),

            'usuario': {
                'id_usuario': usuario[0],
                'id_rol': usuario[1],
                'nombre_usuario': usuario[2],
                'email': usuario[3],
                'estado': usuario[4],
                'nombre_rol': usuario[5],
                'id_alumno': usuario[6],
                'id_docente': usuario[7]
            }

        })

    except json.JSONDecodeError:

        return JsonResponse({
            'success': False,
            'mensaje': 'El formato JSON enviado no es válido'
        }, status=400)

    except Exception as error:

        print("ERROR LOGIN:", error)

        return JsonResponse({
            'success': False,
            'mensaje': 'Error al iniciar sesión',
            'error': str(error)
        }, status=500)


# ============================================================
# PAGOS
# ============================================================

@api_view(['GET'])
def obtener_pagos(request):

    id_docente = request.GET.get('id_docente')

    if id_docente:
        pagos = Pagos.objects.filter(
            id_inscripcion__id_grupo__id_docente=id_docente
        )
    else:
        pagos = Pagos.objects.all()

    serializer = PagoSerializer(
        pagos,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# ASISTENCIAS
# ============================================================

@api_view(['GET'])
def obtener_asistencias(request):

    id_docente = request.GET.get('id_docente')

    if id_docente:
        asistencias = Asistencias.objects.filter(
            id_inscripcion__id_grupo__id_docente=id_docente
        )
    else:
        asistencias = Asistencias.objects.all()

    serializer = AsistenciaSerializer(
        asistencias,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# EVALUACIONES
# ============================================================

@api_view(['GET'])
def obtener_evaluaciones(request):

    id_docente = request.GET.get('id_docente')

    if id_docente:
        evaluaciones = Evaluaciones.objects.filter(
            id_grupo__id_docente=id_docente
        )
    else:
        evaluaciones = Evaluaciones.objects.all()

    serializer = EvaluacionSerializer(
        evaluaciones,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# CALIFICACIONES
# ============================================================

@api_view(['GET'])
def obtener_calificaciones(request):

    id_docente = request.GET.get('id_docente')

    if id_docente:
        calificaciones = Calificaciones.objects.filter(
            id_inscripcion__id_grupo__id_docente=id_docente
        )
    else:
        calificaciones = Calificaciones.objects.all()

    serializer = CalificacionSerializer(
        calificaciones,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# ENTIDADES CERTIFICADORAS
# ============================================================

@api_view(['GET'])
def obtener_entidades(request):

    entidades = EntidadesCertificadoras.objects.all()

    serializer = EntidadCertificadoraSerializer(
        entidades,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# CERTIFICACIONES
# ============================================================

@api_view(['GET'])
def obtener_certificaciones(request):

    id_docente = request.GET.get('id_docente')

    if id_docente:
        certificaciones = Certificaciones.objects.filter(
            id_inscripcion__id_grupo__id_docente=id_docente
        )
    else:
        certificaciones = Certificaciones.objects.all()

    serializer = CertificacionSerializer(
        certificaciones,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# REGISTRO DE USUARIO
# ============================================================

@csrf_exempt
def registro(request):

    if request.method != 'POST':
        return JsonResponse({
            'success': False,
            'mensaje': 'Método no permitido'
        }, status=405)

    try:

        data = json.loads(request.body)

        from django.core.validators import validate_email
        from django.core.exceptions import ValidationError
        import re
        if not isinstance(data, dict):
            return JsonResponse({'success': False, 'mensaje': 'Datos de registro no v?lidos.'}, status=400)
        campos = ('nombre', 'correo', 'password', 'confirmar', 'telefono', 'edad')
        if any(not isinstance(data.get(c), str) for c in campos):
            return JsonResponse({'success': False, 'mensaje': 'Completa todos los campos del formulario.'}, status=400)
        nombre = data['nombre'].strip()
        correo = data['correo'].strip().lower()
        password = data['password']
        telefono = data['telefono'].strip()
        id_rol = data.get('id_rol')
        errores = []
        if not 2 <= len(nombre) <= 100 or any(ord(c) < 32 for c in nombre):
            errores.append('El nombre debe tener entre 2 y 100 caracteres.')
        try:
            validate_email(correo)
            if len(correo) > 100:
                raise ValidationError('Correo demasiado largo.')
        except ValidationError:
            errores.append('Ingresa un correo v?lido de hasta 100 caracteres.')
        if not re.fullmatch(r'[0-9]{10}', telefono):
            errores.append('El tel\u00e9fono debe contener exactamente 10 d\u00edgitos.')
        if not re.fullmatch(r'[0-9]{1,2}', data['edad']) or not 1 <= int(data['edad']) <= 50:
            errores.append('Ingresa una edad entera entre 1 y 50 a\u00f1os.')
        if not (10 <= len(password) <= 128 and re.search(r'[A-Z]', password)
                and re.search(r'[a-z]', password) and re.search(r'[0-9]', password)
                and re.search(r'[^a-zA-Z0-9\s]', password) and not re.search(r'\s', password)):
            errores.append('La contrase?a debe tener de 10 a 128 caracteres, may?scula, min?scula, n?mero y s?mbolo, sin espacios.')
        if password != data['confirmar']:
            errores.append('Las contrase?as no coinciden.')
        if errores:
            return JsonResponse({'success': False, 'mensaje': ' '.join(errores)}, status=400)

        try:
            id_rol = int(id_rol)
        except (ValueError, TypeError):

            return JsonResponse({
                'success': False,
                'mensaje': 'El rol seleccionado no es válido'
            }, status=400)

        rol = Roles.objects.filter(
            id_rol=id_rol
        ).first()

        if not rol:
            return JsonResponse({
                'success': False,
                'mensaje': 'El rol seleccionado no existe en la base de datos'
            }, status=400)

        nombre_rol = rol.nombre_rol.strip().casefold()
        if nombre_rol not in {'alumno', 'alumnos', 'padre'}:
            return JsonResponse({
                'success': False,
                'mensaje': 'Solo se permite el registro con rol Alumno o Padre y/o tutor'
            }, status=400)

        usuario_existente = Usuarios.objects.filter(
            email__iexact=correo
        ).first()

        if usuario_existente:
            return JsonResponse({
                'success': False,
                'mensaje': 'El correo ya está registrado'
            }, status=400)

        from django.db import transaction
        from django.utils import timezone
        with transaction.atomic():
            usuario = Usuarios.objects.create(
                id_rol=rol,
                nombre_usuario=nombre,
                email=correo,
                password_hash=make_password(password),
                fecha_creacion=timezone.now(),
                estado=1
            )
            if nombre_rol in {'alumno', 'alumnos'}:
                Alumnos.objects.create(id_usuario=usuario, matricula=f'MTL-{usuario.pk}',
                    nombre=nombre, apellido_paterno='', telefono=telefono, correo=correo, fecha_registro=timezone.now(), estado=1)

        return JsonResponse({

            'success': True,

            'mensaje': 'Usuario registrado correctamente',

            'id_usuario': usuario.id_usuario,

            'id_rol': rol.id_rol,

            'nombre_rol': rol.nombre_rol

        }, status=201)

    except json.JSONDecodeError:

        return JsonResponse({
            'success': False,
            'mensaje': 'El formato JSON enviado no es válido'
        }, status=400)

    except Exception as error:

        print("ERROR REGISTRO:", error)

        return JsonResponse({
            'success': False,
            'mensaje': 'Error al registrar usuario',
            'error': str(error)
        }, status=500)


# ============================================================
# CURSOS COMPLETOS
# ============================================================

@api_view(['GET'])
def obtener_cursos_completos(request):

    id_docente = request.GET.get('id_docente')

    sql = """
        SELECT
            c.id_curso,
            c.nombre_curso,
            c.descripcion,
            c.duracion_horas,
            c.costo,
            c.nivel,
            c.estado,

            g.id_grupo,
            g.nombre_grupo,

            d.nombre AS nombre_docente,
            d.apellido_paterno,

            p.nombre_periodo,

            di.nombre_dia,

            h.hora_inicio,
            h.hora_fin,

            a.nombre_aula,
            a.ubicacion

        FROM cursos c

        LEFT JOIN grupos g
            ON c.id_curso = g.id_curso

        LEFT JOIN docentes d
            ON g.id_docente = d.id_docente

        LEFT JOIN periodos p
            ON g.id_periodo = p.id_periodo

        LEFT JOIN horarios h
            ON g.id_grupo = h.id_grupo

        LEFT JOIN dias di
            ON h.id_dia = di.id_dia

        LEFT JOIN aulas a
            ON h.id_aula = a.id_aula

        WHERE c.estado = 1
    """

    parametros = []

    if id_docente:
        sql += """
            AND g.id_docente = %s
        """
        parametros.append(id_docente)

    sql += """
        ORDER BY c.id_curso ASC
    """

    with connection.cursor() as cursor:

        cursor.execute(sql, parametros)

        columnas = [
            columna[0]
            for columna in cursor.description
        ]

        resultados = [
            dict(zip(columnas, fila))
            for fila in cursor.fetchall()
        ]

    return Response(resultados)


# ============================================================
# USUARIOS
# ============================================================

@api_view(['GET'])
def obtener_usuarios(request):

    with connection.cursor() as cursor:

        cursor.execute("""
            SELECT
                u.id_usuario,
                u.id_rol,
                u.nombre_usuario,
                u.email,
                u.estado,
                r.nombre_rol
            FROM usuarios u
            LEFT JOIN roles r
                ON u.id_rol = r.id_rol
            ORDER BY u.id_usuario ASC
        """)

        columnas = [
            col[0]
            for col in cursor.description
        ]

        usuarios = [
            dict(zip(columnas, fila))
            for fila in cursor.fetchall()
        ]

    return Response(usuarios)


# ============================================================
# CREAR USUARIO
# ============================================================

@csrf_exempt
@api_view(['POST'])
def crear_usuario(request):

    try:

        nombre_usuario = request.data.get('nombre_usuario')
        email = request.data.get('email')
        password_hash = request.data.get('password_hash')
        id_rol = request.data.get('id_rol')
        estado = request.data.get('estado', 1)

        if not nombre_usuario or not email or not password_hash or not id_rol:
            return Response({
                'success': False,
                'mensaje': 'Nombre, correo, contraseña y rol son obligatorios'
            }, status=400)

        try:
            id_rol = int(id_rol)
        except (ValueError, TypeError):

            return Response({
                'success': False,
                'mensaje': 'El rol no es válido'
            }, status=400)

        rol = Roles.objects.filter(
            id_rol=id_rol
        ).first()

        if not rol:
            return Response({
                'success': False,
                'mensaje': 'El rol seleccionado no existe'
            }, status=400)

        usuario_existente = Usuarios.objects.filter(
            email=email
        ).first()

        if usuario_existente:
            return Response({
                'success': False,
                'mensaje': 'El correo ya está registrado'
            }, status=400)

        usuario = Usuarios.objects.create(
            id_rol=rol,
            nombre_usuario=nombre_usuario,
            email=email,
            password_hash=password_hash,
            estado=estado
        )

        return Response({

            'success': True,

            'mensaje': 'Usuario creado correctamente',

            'usuario': {
                'id_usuario': usuario.id_usuario,
                'id_rol': rol.id_rol,
                'nombre_usuario': usuario.nombre_usuario,
                'email': usuario.email,
                'estado': usuario.estado
            }

        }, status=201)

    except Exception as error:

        print("ERROR CREAR USUARIO:", error)

        return Response({
            'success': False,
            'mensaje': 'Error al crear usuario',
            'error': str(error)
        }, status=500)


# ============================================================
# EDITAR USUARIO
# ============================================================

@csrf_exempt
@api_view(['PUT'])
def editar_usuario(request, id_usuario):

    try:

        usuario = Usuarios.objects.filter(
            id_usuario=id_usuario
        ).first()

        if not usuario:
            return Response({
                'success': False,
                'mensaje': 'El usuario no existe'
            }, status=404)

        nombre_usuario = request.data.get(
            'nombre_usuario',
            usuario.nombre_usuario
        )

        email = request.data.get(
            'email',
            usuario.email
        )

        password_hash = request.data.get(
            'password_hash',
            usuario.password_hash
        )

        id_rol = request.data.get(
            'id_rol',
            usuario.id_rol_id
        )

        estado = request.data.get(
            'estado',
            usuario.estado
        )

        try:
            id_rol = int(id_rol)
        except (ValueError, TypeError):

            return Response({
                'success': False,
                'mensaje': 'El rol no es válido'
            }, status=400)

        rol = Roles.objects.filter(
            id_rol=id_rol
        ).first()

        if not rol:
            return Response({
                'success': False,
                'mensaje': 'El rol seleccionado no existe'
            }, status=400)

        correo_existente = Usuarios.objects.filter(
            email=email
        ).exclude(
            id_usuario=id_usuario
        ).first()

        if correo_existente:
            return Response({
                'success': False,
                'mensaje': 'El correo ya pertenece a otro usuario'
            }, status=400)

        usuario.id_rol = rol
        usuario.nombre_usuario = nombre_usuario
        usuario.email = email
        usuario.password_hash = password_hash
        usuario.estado = estado

        usuario.save(
            update_fields=[
                'id_rol',
                'nombre_usuario',
                'email',
                'password_hash',
                'estado'
            ]
        )

        return Response({

            'success': True,

            'mensaje': 'Usuario actualizado correctamente',

            'usuario': {
                'id_usuario': usuario.id_usuario,
                'id_rol': rol.id_rol,
                'nombre_usuario': usuario.nombre_usuario,
                'email': usuario.email,
                'estado': usuario.estado
            }

        })

    except Exception as error:

        print("ERROR EDITAR USUARIO:", error)

        return Response({
            'success': False,
            'mensaje': 'Error al editar usuario',
            'error': str(error)
        }, status=500)


# ============================================================
# ELIMINAR USUARIO
# ============================================================

@csrf_exempt
@api_view(['DELETE'])
def eliminar_usuario(request, id_usuario):

    try:

        usuario = Usuarios.objects.filter(
            id_usuario=id_usuario
        ).first()

        if not usuario:
            return Response({
                'success': False,
                'mensaje': 'El usuario no existe'
            }, status=404)

        usuario.delete()

        return Response({
            'success': True,
            'mensaje': 'Usuario eliminado correctamente'
        })

    except Exception as error:

        print("ERROR ELIMINAR USUARIO:", error)

        return Response({
            'success': False,
            'mensaje': 'No se pudo eliminar el usuario',
            'error': str(error)
        }, status=400)


# ============================================================
# ROLES
# ============================================================

@api_view(['GET'])
def obtener_roles(request):

    roles = Roles.objects.all()

    serializer = RolSerializer(
        roles,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# PERIODOS
# ============================================================

@api_view(['GET'])
def obtener_periodos(request):

    periodos = Periodos.objects.all()

    serializer = PeriodoSerializer(
        periodos,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# AULAS
# ============================================================

@api_view(['GET'])
def obtener_aulas(request):

    aulas = Aulas.objects.all()

    serializer = AulaSerializer(
        aulas,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# DIAS
# ============================================================

@api_view(['GET'])
def obtener_dias(request):

    dias = Dias.objects.all()

    serializer = DiaSerializer(
        dias,
        many=True
    )

    return Response(serializer.data)


# ============================================================
# CRUD PARA EL PANEL DEL ADMINISTRADOR
# ============================================================

from django.apps import apps
from rest_framework.decorators import api_view
from rest_framework.response import Response


MODELOS_ADMIN = {
    'usuarios': 'Usuarios',
    'alumnos': 'Alumnos',
    'docentes': 'Docentes',
    'cursos': 'Cursos',
    'grupos': 'Grupos',
    'inscripciones': 'Inscripciones',
    'pagos': 'Pagos',
    'asistencias': 'Asistencias',
    'evaluaciones': 'Evaluaciones',
    'calificaciones': 'Calificaciones',
}


def obtener_modelo_admin(tabla):

    nombre_modelo = MODELOS_ADMIN.get(tabla)

    if not nombre_modelo:
        return None

    return apps.get_model('bibliotecaapp', nombre_modelo)


# ============================================================
# INSERTAR
# ============================================================

@api_view(['POST'])
def insertar_admin(request, tabla):

    modelo = obtener_modelo_admin(tabla)

    if not modelo:
        return Response({
            'success': False,
            'mensaje': 'Tabla no permitida'
        }, status=400)

    try:

        datos = request.data.copy()

        # No permitir modificar el ID automático
        nombre_id = modelo._meta.pk.name
        datos.pop(nombre_id, None)

        # ====================================================
        # MANEJAR FOREIGN KEYS
        # ====================================================

        for campo in modelo._meta.fields:

            if campo.name not in datos:
                continue

            # Si es ForeignKey
            if campo.is_relation and campo.many_to_one:

                valor = datos[campo.name]

                if valor in ['', None]:
                    datos.pop(campo.name, None)
                    continue

                datos[campo.name + '_id'] = valor
                datos.pop(campo.name, None)

        objeto = modelo.objects.create(**datos)

        return Response({

            'success': True,

            'mensaje': 'Registro insertado correctamente',

            'id': getattr(objeto, nombre_id)

        }, status=201)

    except Exception as error:

        print("ERROR INSERTAR ADMIN:", error)

        return Response({

            'success': False,

            'mensaje': 'No se pudo insertar el registro',

            'error': str(error)

        }, status=400)


# ============================================================
# EDITAR
# ============================================================

@api_view(['PUT'])
def editar_admin(request, tabla, id):

    modelo = obtener_modelo_admin(tabla)

    if not modelo:
        return Response({

            'success': False,

            'mensaje': 'Tabla no permitida'

        }, status=400)

    try:

        nombre_id = modelo._meta.pk.name

        objeto = modelo.objects.filter(
            **{nombre_id: id}
        ).first()

        if not objeto:

            return Response({

                'success': False,

                'mensaje': 'Registro no encontrado'

            }, status=404)

        datos = request.data.copy()

        # ====================================================
        # NO MODIFICAR LA LLAVE PRIMARIA
        # ====================================================

        datos.pop(nombre_id, None)

        # ====================================================
        # ACTUALIZAR CAMPOS
        # ====================================================

        for campo, valor in datos.items():

            # Campo inexistente
            if not hasattr(objeto, campo):
                continue

            # =================================================
            # FOREIGN KEY
            # =================================================

            campo_modelo = modelo._meta.get_field(campo)

            if campo_modelo.is_relation and campo_modelo.many_to_one:

                if valor in ['', None]:
                    setattr(
                        objeto,
                        campo + '_id',
                        None
                    )

                else:

                    modelo_relacionado = campo_modelo.remote_field.model

                    existe = modelo_relacionado.objects.filter(
                        pk=valor
                    ).exists()

                    if not existe:

                        return Response({

                            'success': False,

                            'mensaje': (
                                f'El registro relacionado de '
                                f'{campo} no existe'
                            )

                        }, status=400)

                    setattr(
                        objeto,
                        campo + '_id',
                        valor
                    )

            # =================================================
            # CAMPO NORMAL
            # =================================================

            else:

                setattr(
                    objeto,
                    campo,
                    valor
                )

        objeto.save()

        return Response({

            'success': True,

            'mensaje': 'Registro actualizado correctamente'

        })

    except Exception as error:

        print("ERROR EDITAR ADMIN:", error)

        return Response({

            'success': False,

            'mensaje': 'No se pudo actualizar el registro',

            'error': str(error)

        }, status=400)


# ============================================================
# ELIMINAR
# ============================================================

@api_view(['DELETE'])
def eliminar_admin(request, tabla, id):

    modelo = obtener_modelo_admin(tabla)

    if not modelo:

        return Response({

            'success': False,

            'mensaje': 'Tabla no permitida'

        }, status=400)

    try:

        nombre_id = modelo._meta.pk.name

        objeto = modelo.objects.filter(
            **{nombre_id: id}
        ).first()

        if not objeto:

            return Response({

                'success': False,

                'mensaje': 'Registro no encontrado'

            }, status=404)

        objeto.delete()

        return Response({

            'success': True,

            'mensaje': 'Registro eliminado correctamente'

        })

    except Exception as error:

        print("ERROR ELIMINAR ADMIN:", error)

        return Response({

            'success': False,

            'mensaje': 'No se pudo eliminar el registro',

            'error': str(error)

        }, status=400)
