from django.apps import AppConfig


class BibliotecaappConfig(AppConfig):
    name = 'bibliotecaapp'
